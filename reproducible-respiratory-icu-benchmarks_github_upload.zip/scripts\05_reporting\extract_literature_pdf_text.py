from __future__ import annotations

import re
import hashlib
from pathlib import Path

import pandas as pd
from pypdf import PdfReader


PROJECT_ROOT = Path(__file__).resolve().parents[2]
PDF_ROOT = PROJECT_ROOT / "external_literature"
TEXT_ROOT = PDF_ROOT / "extracted_text"
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"

KEYWORDS = [
    "MIMIC",
    "eICU",
    "Amsterdam",
    "external validation",
    "validation cohort",
    "calibration",
    "Brier",
    "decision curve",
    "net benefit",
    "DCA",
    "missing",
    "complete case",
    "excluded",
    "ICD",
    "diagnosis",
    "procedure",
    "treatment",
    "mechanical ventilation",
    "invasive mechanical ventilation",
    "first 12",
    "first 24",
    "first 48",
    "prediction",
    "time window",
    "GitHub",
    "code",
    "data availability",
]


def clean_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def extract_pdf(path: Path) -> tuple[str, int]:
    reader = PdfReader(str(path))
    pages = []
    for page in reader.pages:
        try:
            pages.append(page.extract_text() or "")
        except Exception as exc:
            pages.append(f"\n[PAGE_EXTRACTION_ERROR: {exc}]\n")
    return clean_text("\n\n".join(pages)), len(reader.pages)


def keyword_contexts(text: str, keyword: str, window: int = 280) -> list[str]:
    contexts = []
    pattern = re.compile(re.escape(keyword), flags=re.IGNORECASE)
    for match in pattern.finditer(text):
        start = max(0, match.start() - window)
        end = min(len(text), match.end() + window)
        context = re.sub(r"\s+", " ", text[start:end]).strip()
        contexts.append(context)
        if len(contexts) >= 4:
            break
    return contexts


def safe_text_name(pdf: Path, index: int) -> str:
    stem = re.sub(r"[^A-Za-z0-9]+", "_", pdf.stem).strip("_").lower()
    digest = hashlib.md5(pdf.name.encode("utf-8")).hexdigest()[:8]
    return f"study_{index:02d}_{stem[:48]}_{digest}.txt"


def main() -> int:
    TEXT_ROOT.mkdir(parents=True, exist_ok=True)
    TABLE_ROOT.mkdir(parents=True, exist_ok=True)
    MANUSCRIPT_TABLE_ROOT.mkdir(parents=True, exist_ok=True)
    summary_rows = []
    context_rows = []
    for index, pdf in enumerate(sorted(PDF_ROOT.glob("*.pdf")), start=1):
        text, pages = extract_pdf(pdf)
        text_path = TEXT_ROOT / safe_text_name(pdf, index)
        text_path.write_text(text, encoding="utf-8")
        summary_rows.append(
            {
                "pdf_name": pdf.name,
                "text_file": text_path.name,
                "n_pages": pages,
                "n_chars": len(text),
                "extractable": len(text) >= 1000,
            }
        )
        for keyword in KEYWORDS:
            for rank, context in enumerate(keyword_contexts(text, keyword), start=1):
                context_rows.append(
                    {
                        "pdf_name": pdf.name,
                        "keyword": keyword,
                        "context_rank": rank,
                        "context": context,
                    }
                )
    outputs = {
        "copd_literature_pdf_text_extraction_summary.csv": pd.DataFrame(summary_rows),
        "copd_literature_pdf_keyword_contexts.csv": pd.DataFrame(context_rows),
    }
    for name, df in outputs.items():
        df.to_csv(TABLE_ROOT / name, index=False)
        df.to_csv(MANUSCRIPT_TABLE_ROOT / name, index=False)
        print(f"Wrote {TABLE_ROOT / name}")
    print(outputs["copd_literature_pdf_text_extraction_summary.csv"].to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
