# Reproducibility checklist

## Data access

- MIMIC-IV v3.1 access is available locally under PhysioNet credentialing.
- eICU-CRD v2.0 access is available locally under PhysioNet credentialing.
- Local database paths are configured in a non-committed path file.
- The public repository contains no restricted patient-level files.

## Environment

- The Python environment is created from `environment.yml` or `requirements.txt`.
- Required packages are installed.
- Seeds for model training and bootstrap runs are recorded.

## Cohorts and outcomes

- The 12-hour ICU landmark is set before feature extraction.
- COPD/AECOPD cohort definitions are generated using the documented rules.
- Mortality risk sets include patients alive at the 12-hour landmark.
- Ventilation risk sets exclude patients already invasively ventilated by the landmark.
- Endpoint notes are checked before interpreting MIMIC-IV to eICU results.

## Predictor rules

- Predictor provenance files are reviewed before model fitting.
- A0 uses predictors available at or before the 12-hour landmark.
- A1 future-window variables are used only as an audit layer.
- A3 diagnosis, administrative, treatment, and procedure proxies are handled separately from A0.
- A5 is reported as an ABG complete-case target-population comparison.
- A6 density-only features are reported as observation-process features.
- A7 is reported as a convenience benchmark, not as the 12-hour reference model.

## Modeling and evaluation

- Logistic regression and XGBoost are trained with fixed seeds.
- Models are trained in MIMIC-IV.
- eICU is used for external validation without retraining.
- AUROC, AUPRC, event rate, Brier score, calibration slope, integrated calibration error, and threshold-specific net benefit are reported where available.
- External recalibration outputs are generated for the prespecified settings.

## Uncertainty

- Bootstrap confidence intervals are generated at the stay level when only one ICU stay per patient is retained.
- A0-versus-audit contrasts use paired bootstrap resampling.
- Bootstrap seed and number of resamples are recorded.

## Literature audit

- The published-study audit is labelled as contextual, not as a PRISMA systematic review.
- Studies are classified using the documented extraction rules.
- No field-wide prevalence estimate is made from the contextual audit.

## Public release

- Raw databases are excluded.
- Patient-level extracts, matrices, and prediction files are excluded.
- Aggregate tables are included.
- Figure source data are checked for patient-level rows.
- Mock files are labelled as synthetic and are not derived from real patients.
