# Release checklist

Complete before publishing a GitHub release or archiving the repository.

- [ ] Confirm that no raw MIMIC-IV or eICU files are present.
- [ ] Confirm that no patient-level extracts are present.
- [ ] Confirm that no patient-level feature matrices are present.
- [ ] Confirm that no patient-level predictions are present.
- [ ] Confirm that no columns named `subject_id`, `hadm_id`, `stay_id`, `icu_stay_id`, `patientunitstayid`, or equivalent identifiers appear in public CSV files unless they are mock synthetic examples.
- [ ] Confirm that `dataset_paths.yaml` is not committed.
- [ ] Confirm that `dataset_paths_template.yaml` contains placeholders only.
- [ ] Confirm that aggregate outputs and figure source data contain no patient-level rows.
- [ ] Confirm that `README.md`, `LICENSE`, `CITATION.cff`, `analysis_manifest.yml`, `environment.yml`, and `requirements.txt` are present.
- [ ] Create a GitHub release tag, for example `v1.0.0`.
- [ ] Archive the release on Zenodo or OSF if the manuscript will report a DOI.
