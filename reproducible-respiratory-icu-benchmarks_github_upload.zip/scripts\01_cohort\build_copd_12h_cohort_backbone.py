from __future__ import annotations

import csv
import gzip
import re
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
from typing import Iterable

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_ROOT = PROJECT_ROOT.parent
MIMIC_ROOT = DATA_ROOT / "mimic-iv-3.1" / "mimic-iv-3.1"
EICU_ROOT = (
    DATA_ROOT
    / "eicu-collaborative-research-database-2.0"
    / "eicu-collaborative-research-database-2.0"
)
OUTPUT_ROOT = PROJECT_ROOT / "data_intermediate"
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"

LANDMARK_HOURS = 12
LANDMARK_MINUTES = LANDMARK_HOURS * 60

COPD_ICD9_PREFIXES = ("490", "491", "492", "496")
COPD_ICD10_PREFIXES = ("J40", "J41", "J42", "J43", "J44")
ACUTE_RESP_FAILURE_ICD9_PREFIXES = ("51881", "51882", "51884")
ACUTE_RESP_FAILURE_ICD10_PREFIXES = ("J96",)

COPD_TEXT_RE = re.compile(
    r"\b(copd|chronic obstructive|emphysema|chronic bronchitis|aecopd)\b",
    flags=re.IGNORECASE,
)
RESP_FAILURE_TEXT_RE = re.compile(
    r"\b(respiratory failure|acute respiratory failure|hypercapnic|hypoxemic)\b",
    flags=re.IGNORECASE,
)
RESP_TREATMENT_TEXT_RE = re.compile(
    r"\b(ventilat|intubat|extubat|bipap|cpap|non[- ]?invasive|niv|oxygen|bronchodilator|albuterol|ipratropium|steroid|prednisone|methylpred|antibiotic)\b",
    flags=re.IGNORECASE,
)


@dataclass
class FlowRow:
    dataset: str
    step: str
    n_stays: int


def read_csv_gz(path: Path, **kwargs) -> pd.DataFrame:
    return pd.read_csv(path, compression="gzip", **kwargs)


def write_rows(path: Path, rows: Iterable[dict]) -> None:
    rows = list(rows)
    if not rows:
        raise ValueError(f"No rows to write: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def norm_code(code: object) -> str:
    if pd.isna(code):
        return ""
    return str(code).strip().upper().replace(".", "")


def is_mimic_code_match(
    code: object,
    version: object,
    icd9_prefixes: tuple[str, ...],
    icd10_prefixes: tuple[str, ...],
) -> bool:
    code_norm = norm_code(code)
    if str(version).strip() == "10":
        return code_norm.startswith(icd10_prefixes)
    return code_norm.startswith(icd9_prefixes)


def eicu_code_text_has_prefix(text: object, prefixes: tuple[str, ...]) -> bool:
    if pd.isna(text):
        return False
    pieces = re.split(r"[,;|\s]+", str(text).upper())
    return any(norm_code(piece).startswith(prefixes) for piece in pieces if piece)


def parse_eicu_age(value: object) -> float | None:
    if pd.isna(value):
        return None
    text = str(value).strip()
    if text == "":
        return None
    if text.startswith(">"):
        return 90.0
    try:
        return float(text)
    except ValueError:
        return None


def build_mimic_backbone() -> tuple[pd.DataFrame, list[FlowRow]]:
    icustays = read_csv_gz(
        MIMIC_ROOT / "icu" / "icustays.csv.gz",
        usecols=[
            "subject_id",
            "hadm_id",
            "stay_id",
            "first_careunit",
            "last_careunit",
            "intime",
            "outtime",
            "los",
        ],
        parse_dates=["intime", "outtime"],
    )
    admissions = read_csv_gz(
        MIMIC_ROOT / "hosp" / "admissions.csv.gz",
        usecols=[
            "subject_id",
            "hadm_id",
            "admittime",
            "dischtime",
            "deathtime",
            "discharge_location",
            "hospital_expire_flag",
        ],
        parse_dates=["admittime", "dischtime", "deathtime"],
    )
    patients = read_csv_gz(
        MIMIC_ROOT / "hosp" / "patients.csv.gz",
        usecols=["subject_id", "gender", "anchor_age"],
    )

    flow = [FlowRow("MIMIC-IV", "raw_icu_stays", len(icustays))]
    df = icustays.merge(admissions, on=["subject_id", "hadm_id"], how="left")
    df = df.merge(patients, on="subject_id", how="left")
    flow.append(FlowRow("MIMIC-IV", "after_admission_patient_join", len(df)))

    df["age"] = pd.to_numeric(df["anchor_age"], errors="coerce")
    df = df[df["age"] >= 18].copy()
    flow.append(FlowRow("MIMIC-IV", "adult_age_ge_18", len(df)))

    df = df.sort_values(["subject_id", "intime", "stay_id"])
    df["patient_stay_number"] = df.groupby("subject_id").cumcount() + 1
    df_first = df[df["patient_stay_number"] == 1].copy()
    flow.append(FlowRow("MIMIC-IV", "first_icu_stay_per_patient", len(df_first)))

    df_first["landmark_time"] = df_first["intime"] + pd.to_timedelta(
        LANDMARK_HOURS, unit="h"
    )
    df_first["has_valid_times"] = (
        df_first["intime"].notna()
        & df_first["outtime"].notna()
        & df_first["dischtime"].notna()
    )
    df_first["survived_to_landmark"] = df_first["outtime"] > df_first["landmark_time"]
    df_first["death_time"] = df_first["deathtime"]
    df_first["death_before_or_at_landmark"] = (
        df_first["death_time"].notna()
        & (df_first["death_time"] <= df_first["landmark_time"])
    )
    df_first["eligible_12h_mortality"] = (
        df_first["has_valid_times"]
        & df_first["survived_to_landmark"]
        & ~df_first["death_before_or_at_landmark"]
        & df_first["hospital_expire_flag"].notna()
    )
    flow.append(
        FlowRow(
            "MIMIC-IV",
            "eligible_12h_mortality_landmark",
            int(df_first["eligible_12h_mortality"].sum()),
        )
    )

    out = pd.DataFrame(
        {
            "dataset": "MIMIC-IV",
            "patient_id": df_first["subject_id"].astype(str),
            "hospital_id": "",
            "hospital_admission_id": df_first["hadm_id"].astype(str),
            "icu_stay_id": df_first["stay_id"].astype(str),
            "age": df_first["age"],
            "sex": df_first["gender"],
            "icu_type": df_first["first_careunit"],
            "icu_admit_time": df_first["intime"],
            "icu_discharge_time": df_first["outtime"],
            "hospital_admit_time": df_first["admittime"],
            "hospital_discharge_time": df_first["dischtime"],
            "landmark_hours": LANDMARK_HOURS,
            "landmark_time": df_first["landmark_time"],
            "hospital_mortality": pd.to_numeric(
                df_first["hospital_expire_flag"], errors="coerce"
            ),
            "death_time": df_first["death_time"],
            "survived_to_landmark": df_first["survived_to_landmark"],
            "death_before_or_at_landmark": df_first["death_before_or_at_landmark"],
            "eligible_12h_mortality": df_first["eligible_12h_mortality"],
            "exclusion_reason": "eligible",
        }
    )
    out.loc[~df_first["has_valid_times"], "exclusion_reason"] = "invalid_or_missing_time"
    out.loc[
        df_first["has_valid_times"] & ~df_first["survived_to_landmark"],
        "exclusion_reason",
    ] = "icu_discharge_before_or_at_landmark"
    out.loc[
        df_first["death_before_or_at_landmark"], "exclusion_reason"
    ] = "death_before_or_at_landmark"
    out.loc[
        df_first["hospital_expire_flag"].isna(), "exclusion_reason"
    ] = "unknown_hospital_mortality"
    out.loc[out["eligible_12h_mortality"], "exclusion_reason"] = "eligible"
    return out, flow


def build_eicu_backbone() -> tuple[pd.DataFrame, list[FlowRow]]:
    patient = read_csv_gz(
        EICU_ROOT / "patient.csv.gz",
        usecols=[
            "patientunitstayid",
            "patienthealthsystemstayid",
            "gender",
            "age",
            "hospitalid",
            "hospitaladmitoffset",
            "hospitaldischargeoffset",
            "hospitaldischargestatus",
            "unittype",
            "unitdischargeoffset",
            "uniquepid",
        ],
    )
    flow = [FlowRow("eICU", "raw_icu_stays", len(patient))]
    df = patient.copy()
    df["age_numeric"] = df["age"].map(parse_eicu_age)
    df = df[df["age_numeric"] >= 18].copy()
    flow.append(FlowRow("eICU", "adult_age_ge_18", len(df)))

    df = df.sort_values(["uniquepid", "patientunitstayid"])
    df["patient_stay_number"] = df.groupby("uniquepid").cumcount() + 1
    df_first = df[df["patient_stay_number"] == 1].copy()
    flow.append(FlowRow("eICU", "first_icu_stay_per_patient", len(df_first)))

    df_first["has_valid_times"] = (
        df_first["unitdischargeoffset"].notna()
        & df_first["hospitaldischargeoffset"].notna()
    )
    df_first["survived_to_landmark"] = df_first["unitdischargeoffset"] > LANDMARK_MINUTES
    df_first["hospital_mortality"] = (
        df_first["hospitaldischargestatus"].astype(str).str.lower().eq("expired")
    ).astype("Int64")
    df_first.loc[
        df_first["hospitaldischargestatus"].isna(), "hospital_mortality"
    ] = pd.NA
    df_first["death_before_or_at_landmark"] = (
        df_first["hospital_mortality"].eq(1)
        & (df_first["hospitaldischargeoffset"] <= LANDMARK_MINUTES)
    )
    df_first["eligible_12h_mortality"] = (
        df_first["has_valid_times"]
        & df_first["survived_to_landmark"]
        & ~df_first["death_before_or_at_landmark"]
        & df_first["hospital_mortality"].notna()
    )
    flow.append(
        FlowRow(
            "eICU",
            "eligible_12h_mortality_landmark",
            int(df_first["eligible_12h_mortality"].sum()),
        )
    )

    base_time = pd.Timestamp("2000-01-01")
    icu_admit = pd.Series(base_time, index=df_first.index)
    out = pd.DataFrame(
        {
            "dataset": "eICU",
            "patient_id": df_first["uniquepid"].astype(str),
            "hospital_id": df_first["hospitalid"].astype(str),
            "hospital_admission_id": df_first["patienthealthsystemstayid"].astype(str),
            "icu_stay_id": df_first["patientunitstayid"].astype(str),
            "age": df_first["age_numeric"],
            "sex": df_first["gender"],
            "icu_type": df_first["unittype"],
            "icu_admit_time": icu_admit,
            "icu_discharge_time": icu_admit
            + pd.to_timedelta(df_first["unitdischargeoffset"], unit="m"),
            "hospital_admit_time": icu_admit
            + pd.to_timedelta(df_first["hospitaladmitoffset"], unit="m"),
            "hospital_discharge_time": icu_admit
            + pd.to_timedelta(df_first["hospitaldischargeoffset"], unit="m"),
            "landmark_hours": LANDMARK_HOURS,
            "landmark_time": icu_admit + timedelta(hours=LANDMARK_HOURS),
            "hospital_mortality": df_first["hospital_mortality"],
            "death_time": pd.NaT,
            "survived_to_landmark": df_first["survived_to_landmark"],
            "death_before_or_at_landmark": df_first["death_before_or_at_landmark"],
            "eligible_12h_mortality": df_first["eligible_12h_mortality"],
            "exclusion_reason": "eligible",
        }
    )
    out.loc[~df_first["has_valid_times"], "exclusion_reason"] = "invalid_or_missing_time"
    out.loc[
        df_first["has_valid_times"] & ~df_first["survived_to_landmark"],
        "exclusion_reason",
    ] = "icu_discharge_before_or_at_landmark"
    out.loc[
        df_first["death_before_or_at_landmark"], "exclusion_reason"
    ] = "death_before_or_at_landmark"
    out.loc[
        df_first["hospital_mortality"].isna(), "exclusion_reason"
    ] = "unknown_hospital_mortality"
    out.loc[out["eligible_12h_mortality"], "exclusion_reason"] = "eligible"
    return out, flow


def build_mimic_cohort_flags() -> pd.DataFrame:
    diagnoses = read_csv_gz(
        MIMIC_ROOT / "hosp" / "diagnoses_icd.csv.gz",
        usecols=["subject_id", "hadm_id", "icd_code", "icd_version"],
        dtype={"subject_id": str, "hadm_id": str, "icd_code": str, "icd_version": str},
    )
    diagnoses["is_copd_icd"] = diagnoses.apply(
        lambda row: is_mimic_code_match(
            row["icd_code"], row["icd_version"], COPD_ICD9_PREFIXES, COPD_ICD10_PREFIXES
        ),
        axis=1,
    )
    diagnoses["is_resp_failure_icd"] = diagnoses.apply(
        lambda row: is_mimic_code_match(
            row["icd_code"],
            row["icd_version"],
            ACUTE_RESP_FAILURE_ICD9_PREFIXES,
            ACUTE_RESP_FAILURE_ICD10_PREFIXES,
        ),
        axis=1,
    )
    flags = (
        diagnoses.groupby("hadm_id")
        .agg(
            c1_discharge_icd_copd=("is_copd_icd", "max"),
            has_acute_resp_failure_icd=("is_resp_failure_icd", "max"),
        )
        .reset_index()
        .rename(columns={"hadm_id": "hospital_admission_id"})
    )
    flags["c0_conservative_copd"] = False
    flags["c2_copd_acute_respiratory_failure"] = (
        flags["c1_discharge_icd_copd"] & flags["has_acute_resp_failure_icd"]
    )
    flags["c3_treatment_enriched_copd"] = False
    flags["c4_convenience_copd"] = (
        flags["c1_discharge_icd_copd"] | flags["c2_copd_acute_respiratory_failure"]
    )
    return flags[
        [
            "hospital_admission_id",
            "c0_conservative_copd",
            "c1_discharge_icd_copd",
            "c2_copd_acute_respiratory_failure",
            "c3_treatment_enriched_copd",
            "c4_convenience_copd",
        ]
    ]


def read_eicu_text_flags(
    filename: str,
    text_columns: list[str],
    id_column: str,
    pattern: re.Pattern,
    max_offset_column: str | None = None,
) -> set[str]:
    ids: set[str] = set()
    with gzip.open(
        EICU_ROOT / filename, "rt", encoding="utf-8", errors="replace", newline=""
    ) as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            if max_offset_column is not None:
                try:
                    offset = float(row.get(max_offset_column, ""))
                except ValueError:
                    continue
                if offset > LANDMARK_MINUTES:
                    continue
            text = " | ".join(row.get(col, "") for col in text_columns)
            if pattern.search(text):
                ids.add(str(row[id_column]))
    return ids


def build_eicu_cohort_flags() -> pd.DataFrame:
    diagnosis_copd: set[str] = set()
    diagnosis_resp_failure: set[str] = set()
    with gzip.open(
        EICU_ROOT / "diagnosis.csv.gz",
        "rt",
        encoding="utf-8",
        errors="replace",
        newline="",
    ) as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            stay_id = str(row["patientunitstayid"])
            text = " | ".join([row.get("diagnosisstring", ""), row.get("icd9code", "")])
            icd_text = row.get("icd9code", "")
            if COPD_TEXT_RE.search(text) or eicu_code_text_has_prefix(icd_text, COPD_ICD9_PREFIXES):
                diagnosis_copd.add(stay_id)
            if RESP_FAILURE_TEXT_RE.search(text):
                diagnosis_resp_failure.add(stay_id)

    admission_copd = read_eicu_text_flags(
        "admissionDx.csv.gz",
        ["admitdxpath", "admitdxname", "admitdxtext"],
        "patientunitstayid",
        COPD_TEXT_RE,
        max_offset_column="admitdxenteredoffset",
    )
    past_history_copd = read_eicu_text_flags(
        "pastHistory.csv.gz",
        ["pasthistorypath", "pasthistoryvalue", "pasthistoryvaluetext"],
        "patientunitstayid",
        COPD_TEXT_RE,
        max_offset_column="pasthistoryenteredoffset",
    )
    early_resp_treatment = read_eicu_text_flags(
        "treatment.csv.gz",
        ["treatmentstring"],
        "patientunitstayid",
        RESP_TREATMENT_TEXT_RE,
        max_offset_column="treatmentoffset",
    )

    all_ids = (
        diagnosis_copd
        | diagnosis_resp_failure
        | admission_copd
        | past_history_copd
        | early_resp_treatment
    )
    rows = []
    for stay_id in sorted(all_ids):
        c0 = stay_id in admission_copd or stay_id in past_history_copd
        c1 = stay_id in diagnosis_copd
        c2 = c1 and stay_id in diagnosis_resp_failure
        c3 = (c0 or c1) and stay_id in early_resp_treatment
        c4 = c0 or c1 or c2 or c3
        rows.append(
            {
                "icu_stay_id": stay_id,
                "c0_conservative_copd": c0,
                "c1_discharge_icd_copd": c1,
                "c2_copd_acute_respiratory_failure": c2,
                "c3_treatment_enriched_copd": c3,
                "c4_convenience_copd": c4,
            }
        )
    return pd.DataFrame(rows)


COHORT_COLUMNS = [
    "c0_conservative_copd",
    "c1_discharge_icd_copd",
    "c2_copd_acute_respiratory_failure",
    "c3_treatment_enriched_copd",
    "c4_convenience_copd",
]


def apply_cohort_flags(backbone: pd.DataFrame) -> pd.DataFrame:
    mimic = backbone[backbone["dataset"] == "MIMIC-IV"].copy()
    eicu = backbone[backbone["dataset"] == "eICU"].copy()

    mimic_flags = build_mimic_cohort_flags()
    eicu_flags = build_eicu_cohort_flags()

    mimic = mimic.merge(mimic_flags, on="hospital_admission_id", how="left")
    eicu = eicu.merge(eicu_flags, on="icu_stay_id", how="left")
    combined = pd.concat([mimic, eicu], ignore_index=True)
    for col in COHORT_COLUMNS:
        combined[col] = combined[col].fillna(False).astype(bool)
    return combined


def summarize_flow(flow: list[FlowRow]) -> list[dict]:
    return [
        {"dataset": row.dataset, "step": row.step, "n_stays": row.n_stays}
        for row in flow
    ]


def summarize_cohorts(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    eligible_all = df[df["eligible_12h_mortality"]].copy()
    for dataset, dataset_group in eligible_all.groupby("dataset", sort=False):
        for cohort_col in COHORT_COLUMNS:
            cohort = dataset_group[dataset_group[cohort_col]].copy()
            rows.append(
                {
                    "dataset": dataset,
                    "cohort_definition": cohort_col,
                    "n_eligible_12h_mortality": len(cohort),
                    "n_hospital_deaths_after_landmark": int(
                        pd.to_numeric(cohort["hospital_mortality"], errors="coerce")
                        .fillna(0)
                        .astype(int)
                        .sum()
                    ),
                    "event_rate_after_landmark": round(
                        float(
                            pd.to_numeric(
                                cohort["hospital_mortality"], errors="coerce"
                            ).mean()
                        ),
                        6,
                    )
                    if len(cohort)
                    else None,
                    "median_age": round(float(cohort["age"].median()), 2)
                    if len(cohort)
                    else None,
                    "female_pct": round(
                        float(
                            cohort["sex"]
                            .astype(str)
                            .str.lower()
                            .isin(["f", "female"])
                            .mean()
                        )
                        * 100,
                        2,
                    )
                    if len(cohort)
                    else None,
                }
            )
    return pd.DataFrame(rows)


def summarize_overlap(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    eligible_all = df[df["eligible_12h_mortality"]].copy()
    for dataset, dataset_group in eligible_all.groupby("dataset", sort=False):
        for left in COHORT_COLUMNS:
            for right in COHORT_COLUMNS:
                rows.append(
                    {
                        "dataset": dataset,
                        "left_cohort": left,
                        "right_cohort": right,
                        "n_overlap": int((dataset_group[left] & dataset_group[right]).sum()),
                    }
                )
    return pd.DataFrame(rows)


def main() -> int:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    TABLE_ROOT.mkdir(parents=True, exist_ok=True)
    MANUSCRIPT_TABLE_ROOT.mkdir(parents=True, exist_ok=True)

    mimic, mimic_flow = build_mimic_backbone()
    eicu, eicu_flow = build_eicu_backbone()
    backbone = pd.concat([mimic, eicu], ignore_index=True)
    with_flags = apply_cohort_flags(backbone)

    backbone_path = OUTPUT_ROOT / "copd_12h_backbone_with_cohort_flags.csv.gz"
    with_flags.to_csv(backbone_path, index=False, compression="gzip")

    flow = summarize_flow(mimic_flow + eicu_flow)
    write_rows(TABLE_ROOT / "cohort_flow_copd_12h_backbone.csv", flow)

    cohort_summary = summarize_cohorts(with_flags)
    cohort_summary.to_csv(TABLE_ROOT / "copd_12h_cohort_definition_summary.csv", index=False)
    cohort_summary.to_csv(
        MANUSCRIPT_TABLE_ROOT / "copd_12h_cohort_definition_summary.csv",
        index=False,
    )

    overlap = summarize_overlap(with_flags)
    overlap.to_csv(TABLE_ROOT / "copd_12h_cohort_overlap_long.csv", index=False)

    print(f"Wrote {backbone_path}")
    print(cohort_summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
