from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
INTERMEDIATE_ROOT = PROJECT_ROOT / "data_intermediate"
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"

SEED = 20260426
DCA_THRESHOLDS = {
    "mortality": [0.05, 0.10, 0.15, 0.20, 0.30],
    "ventilation": [0.005, 0.01, 0.02, 0.05, 0.10],
}


def sigmoid(z: np.ndarray) -> np.ndarray:
    z = np.asarray(z, dtype=float)
    return np.where(z >= 0, 1.0 / (1.0 + np.exp(-z)), np.exp(z) / (1.0 + np.exp(z)))


def logit(p: np.ndarray) -> np.ndarray:
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


def fit_logistic_l2(x: np.ndarray, y: np.ndarray, max_iter: int = 80, tol: float = 1e-8) -> np.ndarray:
    n, p = x.shape
    design = np.column_stack([np.ones(n), x])
    beta = np.zeros(p + 1)
    for _ in range(max_iter):
        pred = sigmoid(design @ beta)
        weight = np.clip(pred * (1 - pred), 1e-6, None)
        gradient = design.T @ (pred - y)
        hessian = (design.T * weight) @ design
        try:
            step = np.linalg.solve(hessian, gradient)
        except np.linalg.LinAlgError:
            step = np.linalg.lstsq(hessian, gradient, rcond=None)[0]
        beta = beta - step
        if float(np.max(np.abs(step))) < tol:
            break
    return beta


def fit_intercept_only_offset(logit_pred: np.ndarray, y: np.ndarray) -> float:
    target = float(np.mean(y))
    low, high = -100.0, 100.0
    for _ in range(200):
        mid = (low + high) / 2.0
        mean_pred = float(np.mean(sigmoid(mid + logit_pred)))
        if mean_pred < target:
            low = mid
        else:
            high = mid
        if abs(mean_pred - target) < 1e-10:
            break
    return float((low + high) / 2.0)


def rankdata_average(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(len(values), dtype=float)
    sorted_values = values[order]
    i = 0
    while i < len(values):
        j = i + 1
        while j < len(values) and sorted_values[j] == sorted_values[i]:
            j += 1
        ranks[order[i:j]] = (i + 1 + j) / 2.0
        i = j
    return ranks


def auroc(y: np.ndarray, pred: np.ndarray) -> float:
    y = y.astype(int)
    n_pos = int(y.sum())
    n_neg = len(y) - n_pos
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    ranks = rankdata_average(pred)
    return float((ranks[y == 1].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def auprc(y: np.ndarray, pred: np.ndarray) -> float:
    y = y.astype(int)
    n_pos = int(y.sum())
    if n_pos == 0:
        return float("nan")
    order = np.argsort(-pred, kind="mergesort")
    y_sorted = y[order]
    tp = np.cumsum(y_sorted)
    fp = np.cumsum(1 - y_sorted)
    recall = tp / n_pos
    precision = tp / np.maximum(tp + fp, 1)
    recall = np.r_[0.0, recall]
    precision = np.r_[precision[0] if len(precision) else 0.0, precision]
    return float(np.sum((recall[1:] - recall[:-1]) * precision[1:]))


def calibration_intercept_slope(y: np.ndarray, pred: np.ndarray) -> tuple[float, float]:
    if len(np.unique(y)) < 2:
        return float("nan"), float("nan")
    beta = fit_logistic_l2(logit(pred).reshape(-1, 1), y.astype(float))
    return float(beta[0]), float(beta[1])


def ici(y: np.ndarray, pred: np.ndarray, n_bins: int = 10) -> float:
    if len(y) == 0:
        return float("nan")
    frame = pd.DataFrame({"y": y, "pred": pred})
    try:
        frame["bin"] = pd.qcut(frame["pred"], q=n_bins, labels=False, duplicates="drop")
    except ValueError:
        frame["bin"] = 0
    grouped = frame.groupby("bin").agg(observed=("y", "mean"), predicted=("pred", "mean"), n=("y", "size"))
    grouped = grouped[grouped["n"] > 0]
    if grouped.empty:
        return float("nan")
    return float(np.average(np.abs(grouped["observed"] - grouped["predicted"]), weights=grouped["n"]))


def net_benefit(y: np.ndarray, pred: np.ndarray, threshold: float) -> float:
    treated = pred >= threshold
    tp = int(((y == 1) & treated).sum())
    fp = int(((y == 0) & treated).sum())
    n = len(y)
    return float(tp / n - fp / n * threshold / (1 - threshold))


def metric_row(y: np.ndarray, pred: np.ndarray) -> dict[str, float]:
    intercept, slope = calibration_intercept_slope(y, pred)
    prevalence = float(np.mean(y))
    ap = auprc(y, pred)
    return {
        "n": int(len(y)),
        "events": int(np.sum(y)),
        "event_rate": prevalence,
        "auroc": auroc(y, pred),
        "auprc": ap,
        "auprc_prevalence_ratio": ap / prevalence if prevalence > 0 else float("nan"),
        "brier": float(np.mean((y - pred) ** 2)),
        "mean_predicted_risk": float(np.mean(pred)),
        "calibration_intercept": intercept,
        "calibration_slope": slope,
        "ici_eavg": ici(y, pred),
    }


def parse_prediction_path(path: Path) -> tuple[str, str, str]:
    stem = path.name.replace("_logistic_predictions.csv.gz", "")
    match = re.match(r"copd_(mortality|ventilation)_(.+)_(A[0-9][A-Za-z0-9_]+)$", stem)
    if not match:
        raise ValueError(f"Unexpected prediction file name: {path.name}")
    task = match.group(1)
    rest = match.group(2)
    audit = match.group(3)
    known_cohorts = [
        "c1_discharge_icd_copd",
        "c2_copd_acute_respiratory_failure",
        "c4_convenience_copd",
    ]
    cohort = next((value for value in known_cohorts if rest.endswith(value)), rest)
    return task, cohort, audit


def split_external(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    external = df[df["split"].eq("external_valid")].copy()
    rng = np.random.default_rng(SEED)
    mask = rng.random(len(external)) < 0.5
    return external[mask].copy(), external[~mask].copy()


def evaluate_file(path: Path) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    task, cohort, audit = parse_prediction_path(path)
    df = pd.read_csv(path, compression="gzip", low_memory=False)
    recal, test = split_external(df)
    y_recal = recal["hospital_mortality"].astype(float).to_numpy()
    p_recal = recal["predicted_risk"].astype(float).to_numpy()
    y_test = test["hospital_mortality"].astype(float).to_numpy()
    p_test = test["predicted_risk"].astype(float).to_numpy()
    if len(y_recal) == 0 or len(y_test) == 0 or len(np.unique(y_recal)) < 2 or len(np.unique(y_test)) < 2:
        return [], []

    lp_recal = logit(p_recal)
    lp_test = logit(p_test)
    alpha = fit_intercept_only_offset(lp_recal, y_recal)
    beta = fit_logistic_l2(lp_recal.reshape(-1, 1), y_recal)

    predictions = {
        "original": p_test,
        "intercept_only_recalibrated": sigmoid(alpha + lp_test),
        "intercept_slope_recalibrated": sigmoid(beta[0] + beta[1] * lp_test),
    }

    metric_rows: list[dict[str, object]] = []
    dca_rows: list[dict[str, object]] = []
    for method, pred in predictions.items():
        row = {
            "task": task,
            "cohort_definition": cohort,
            "audit_variant": audit,
            "recalibration_method": method,
            "recalibration_n": len(recal),
            "test_n": len(test),
            "recalibration_intercept_alpha": alpha,
            "recalibration_slope_beta0": float(beta[0]),
            "recalibration_slope_beta1": float(beta[1]),
        }
        row.update(metric_row(y_test, pred))
        metric_rows.append(row)
        for threshold in DCA_THRESHOLDS[task]:
            dca_rows.append(
                {
                    "task": task,
                    "cohort_definition": cohort,
                    "audit_variant": audit,
                    "recalibration_method": method,
                    "threshold": threshold,
                    "net_benefit": net_benefit(y_test, pred, threshold),
                }
            )
    return metric_rows, dca_rows


def build_improvement_summary(metrics: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (task, cohort, audit), group in metrics.groupby(["task", "cohort_definition", "audit_variant"]):
        original = group[group["recalibration_method"].eq("original")]
        if original.empty:
            continue
        original = original.iloc[0]
        for _, row in group.iterrows():
            rows.append(
                {
                    "task": task,
                    "cohort_definition": cohort,
                    "audit_variant": audit,
                    "recalibration_method": row["recalibration_method"],
                    "delta_auroc_vs_original": row["auroc"] - original["auroc"],
                    "delta_brier_vs_original": row["brier"] - original["brier"],
                    "delta_ici_vs_original": row["ici_eavg"] - original["ici_eavg"],
                    "abs_slope_deviation": abs(1 - row["calibration_slope"]),
                    "delta_abs_slope_deviation_vs_original": abs(1 - row["calibration_slope"])
                    - abs(1 - original["calibration_slope"]),
                }
            )
    return pd.DataFrame(rows)


def main() -> int:
    metric_rows: list[dict[str, object]] = []
    dca_rows: list[dict[str, object]] = []
    for path in sorted(INTERMEDIATE_ROOT.glob("copd_*_logistic_predictions.csv.gz")):
        rows, dca = evaluate_file(path)
        metric_rows.extend(rows)
        dca_rows.extend(dca)

    metrics = pd.DataFrame(metric_rows)
    dca = pd.DataFrame(dca_rows)
    improvement = build_improvement_summary(metrics)

    outputs = {
        "copd_external_recalibration_metrics.csv": metrics,
        "copd_external_recalibration_dca.csv": dca,
        "copd_external_recalibration_improvement.csv": improvement,
    }
    for name, df in outputs.items():
        df.to_csv(TABLE_ROOT / name, index=False)
        df.to_csv(MANUSCRIPT_TABLE_ROOT / name, index=False)
        print(f"Wrote {TABLE_ROOT / name}")

    print("\nRecalibration metrics, headline subset:")
    subset = metrics[
        metrics["cohort_definition"].isin(
            ["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"]
        )
        & metrics["audit_variant"].isin(["A0_clean", "A1_future_window_24h", "A6_density_only"])
    ].copy()
    cols = [
        "task",
        "cohort_definition",
        "audit_variant",
        "recalibration_method",
        "test_n",
        "events",
        "auroc",
        "brier",
        "calibration_slope",
        "ici_eavg",
    ]
    print(subset[cols].round(4).to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
