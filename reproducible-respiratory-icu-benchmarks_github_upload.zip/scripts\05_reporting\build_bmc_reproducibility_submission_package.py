from __future__ import annotations

import hashlib
import platform
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
OUTPUT_TABLES = PROJECT_ROOT / "outputs" / "tables"
OUTPUT_FIGURES = PROJECT_ROOT / "outputs" / "figures"
OUTPUT_FIGURE_DATA = PROJECT_ROOT / "outputs" / "figure_data"
METADATA = PROJECT_ROOT / "metadata"
PROTOCOL = PROJECT_ROOT / "protocol"
PUBLIC_RELEASE = PROJECT_ROOT / "public_release"
SCRIPTS = PROJECT_ROOT / "scripts"
PACKAGE = PROJECT_ROOT / "submission_package_bmc_reproducibility"

PRIMARY_COHORTS = ["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"]
PRIMARY_AUDITS = [
    "A0_clean",
    "A0_respiratory_extended",
    "A1_respiratory_extended_24h",
    "A3a_diagnosis_only",
    "A3b_admin_only",
    "A3c_treatment_procedure_only",
    "A3_all_proxies",
    "A5_abg_complete_case",
    "A6_density_only",
    "A7_composite_convenience",
]


def ensure_dirs() -> None:
    for path in [
        PACKAGE,
        PACKAGE / "manuscript",
        PACKAGE / "tables",
        PACKAGE / "figures",
        PACKAGE / "source_data",
        PACKAGE / "supplementary",
        PACKAGE / "supplementary" / "tables",
        PACKAGE / "statements",
        PACKAGE / "journal_checklists",
        PACKAGE / "public_reproducibility_package",
        PACKAGE / "freeze",
    ]:
        path.mkdir(parents=True, exist_ok=True)


def read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path)


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.strip() + "\n", encoding="utf-8")
    print(f"Wrote {path}")


def write_csv(path: Path, df: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    print(f"Wrote {path}")


def fmt(value: float | int | str, digits: int = 3) -> str:
    if pd.isna(value):
        return "NA"
    if isinstance(value, str):
        return value
    return f"{float(value):.{digits}f}"


def pct(value: float | int | str) -> str:
    if pd.isna(value):
        return "NA"
    return f"{100 * float(value):.1f}%"


def safe_first(df: pd.DataFrame, value_col: str, default: str = "NA", digits: int = 4) -> str:
    if df.empty or value_col not in df.columns:
        return default
    return fmt(df.iloc[0][value_col], digits=digits)


def cohort_row(df: pd.DataFrame, dataset: str, cohort: str) -> pd.Series:
    rows = df[(df["dataset"] == dataset) & (df["cohort_definition"] == cohort)]
    if rows.empty:
        raise ValueError(f"Missing cohort row: {dataset} {cohort}")
    return rows.iloc[0]


def metric_value(task: str, cohort: str, model: str, audit: str, col: str) -> str:
    metrics = read_csv(OUTPUT_TABLES / "copd_model_family_external_metrics.csv")
    rows = metrics[
        (metrics["task"] == task)
        & (metrics["cohort_definition"] == cohort)
        & (metrics["model"] == model)
        & (metrics["audit_variant"] == audit)
    ]
    return safe_first(rows, col, digits=4)


def metric_delta(task: str, cohort: str, model: str, base_audit: str, audit: str, col: str) -> str:
    metrics = read_csv(OUTPUT_TABLES / "copd_model_family_external_metrics.csv")
    base = metrics[
        (metrics["task"] == task)
        & (metrics["cohort_definition"] == cohort)
        & (metrics["model"] == model)
        & (metrics["audit_variant"] == base_audit)
    ]
    variant = metrics[
        (metrics["task"] == task)
        & (metrics["cohort_definition"] == cohort)
        & (metrics["model"] == model)
        & (metrics["audit_variant"] == audit)
    ]
    if base.empty or variant.empty or col not in base.columns or col not in variant.columns:
        return "NA"
    return fmt(float(variant.iloc[0][col]) - float(base.iloc[0][col]), digits=4)


def dca_value(task: str, cohort: str, model: str, audit: str, threshold_col: str) -> str:
    dca = read_csv(OUTPUT_TABLES / "copd_model_family_external_dca_wide.csv")
    rows = dca[
        (dca["task"] == task)
        & (dca["cohort_definition"] == cohort)
        & (dca["model"] == model)
        & (dca["audit_variant"] == audit)
    ]
    return safe_first(rows, threshold_col, digits=5)


def recalibration_value(
    task: str,
    cohort: str,
    model: str,
    audit: str,
    recalibration_method: str,
    col: str,
) -> str:
    recal = read_csv(OUTPUT_TABLES / "copd_model_family_external_recalibration_metrics.csv")
    rows = recal[
        (recal["task"] == task)
        & (recal["cohort_definition"] == cohort)
        & (recal["model"] == model)
        & (recal["audit_variant"] == audit)
        & (recal["recalibration_method"] == recalibration_method)
    ]
    return safe_first(rows, col, digits=4)


def matrix_feature_count(task: str, audit: str, cohort: str) -> str:
    summary = read_csv(OUTPUT_TABLES / "copd_model_matrix_manifest.csv")
    rows = summary[(summary["task"] == task) & (summary["audit_variant"] == audit)]
    if rows.empty:
        return "NA"
    if "n_columns" not in rows.columns or pd.isna(rows.iloc[0]["n_columns"]):
        return "reported in matrix manifest"
    # Exclude non-predictor columns approximately by reporting total matrix columns as a transparent manifest count.
    return str(int(rows.iloc[0]["n_columns"]))


def paired_delta_text(task: str, cohort: str, audit: str = "A1_respiratory_extended_24h") -> str:
    boot = read_csv(OUTPUT_TABLES / "copd_key_bootstrap_auroc_delta_results.csv")
    rows = boot[
        (boot["task"] == task)
        & (boot["cohort_definition"] == cohort)
        & (boot["audit_variant"] == audit)
    ]
    if rows.empty:
        return "NA"
    row = rows.iloc[0]
    return (
        f"{fmt(row['delta_estimate'], 5)} "
        f"(95% CI {fmt(row['ci_lower'], 5)} to {fmt(row['ci_upper'], 5)})"
    )


def literature_count(domain: str, classification: str) -> str:
    lit = read_csv(OUTPUT_TABLES / "copd_literature_scoping_audit_summary_counts.csv")
    rows = lit[(lit["audit_domain"] == domain) & (lit["classification"] == classification)]
    if rows.empty:
        return "0"
    return str(int(rows.iloc[0]["n_studies"]))


def headline_values() -> dict[str, str]:
    mortality = read_csv(OUTPUT_TABLES / "copd_12h_cohort_definition_summary_updated.csv")
    ventilation = read_csv(OUTPUT_TABLES / "copd_12h_ventilation_outcome_summary.csv")
    a5 = read_csv(OUTPUT_TABLES / "copd_a5_abg_target_population_shift.csv")

    m_c1_mimic = cohort_row(mortality, "MIMIC-IV", "c1_discharge_icd_copd")
    m_c1_eicu = cohort_row(mortality, "eICU", "c1_discharge_icd_copd")
    v_c1_mimic = cohort_row(ventilation, "MIMIC-IV", "c1_discharge_icd_copd")
    v_c1_eicu = cohort_row(ventilation, "eICU", "c1_discharge_icd_copd")

    a5_mimic_c1_outcome = a5[
        (a5["task"] == "mortality")
        & (a5["dataset"] == "MIMIC-IV")
        & (a5["cohort_definition"] == "c1_discharge_icd_copd")
        & (a5["variable"] == "task_outcome")
    ].iloc[0]
    a5_mimic_c1_vent = a5[
        (a5["task"] == "mortality")
        & (a5["dataset"] == "MIMIC-IV")
        & (a5["cohort_definition"] == "c1_discharge_icd_copd")
        & (a5["variable"] == "baseline_invasive_vent")
    ].iloc[0]

    return {
        "mortality_c1_mimic": (
            f"{int(m_c1_mimic['n_eligible_12h_mortality'])} stays, "
            f"{int(m_c1_mimic['n_hospital_deaths_after_landmark'])} deaths "
            f"({pct(m_c1_mimic['event_rate_after_landmark'])})"
        ),
        "mortality_c1_eicu": (
            f"{int(m_c1_eicu['n_eligible_12h_mortality'])} stays, "
            f"{int(m_c1_eicu['n_hospital_deaths_after_landmark'])} deaths "
            f"({pct(m_c1_eicu['event_rate_after_landmark'])})"
        ),
        "vent_c1_mimic": (
            f"{int(v_c1_mimic['n_eligible_12h_new_invasive_vent'])} stays, "
            f"{int(v_c1_mimic['n_new_invasive_vent_12_48h'])} events "
            f"({pct(v_c1_mimic['event_rate_new_invasive_vent_12_48h'])})"
        ),
        "vent_c1_eicu": (
            f"{int(v_c1_eicu['n_eligible_12h_new_invasive_vent'])} stays, "
            f"{int(v_c1_eicu['n_new_invasive_vent_12_48h'])} events "
            f"({pct(v_c1_eicu['event_rate_new_invasive_vent_12_48h'])})"
        ),
        "mort_c1_xgb_a0_clean": metric_value("mortality", "c1_discharge_icd_copd", "xgboost", "A0_clean", "auroc"),
        "mort_c1_xgb_a0_resp": metric_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A0_respiratory_extended", "auroc"
        ),
        "mort_c1_xgb_a1": metric_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A1_respiratory_extended_24h", "auroc"
        ),
        "mort_c2_xgb_a0_clean": metric_value(
            "mortality", "c2_copd_acute_respiratory_failure", "xgboost", "A0_clean", "auroc"
        ),
        "mort_c2_xgb_a0_resp": metric_value(
            "mortality",
            "c2_copd_acute_respiratory_failure",
            "xgboost",
            "A0_respiratory_extended",
            "auroc",
        ),
        "mort_c2_xgb_a1": metric_value(
            "mortality",
            "c2_copd_acute_respiratory_failure",
            "xgboost",
            "A1_respiratory_extended_24h",
            "auroc",
        ),
        "vent_c1_xgb_a0_clean": metric_value("ventilation", "c1_discharge_icd_copd", "xgboost", "A0_clean", "auroc"),
        "vent_c1_xgb_a0_resp": metric_value(
            "ventilation", "c1_discharge_icd_copd", "xgboost", "A0_respiratory_extended", "auroc"
        ),
        "vent_c1_xgb_a1": metric_value(
            "ventilation", "c1_discharge_icd_copd", "xgboost", "A1_respiratory_extended_24h", "auroc"
        ),
        "vent_c2_xgb_a0_clean": metric_value(
            "ventilation", "c2_copd_acute_respiratory_failure", "xgboost", "A0_clean", "auroc"
        ),
        "vent_c2_xgb_a0_resp": metric_value(
            "ventilation",
            "c2_copd_acute_respiratory_failure",
            "xgboost",
            "A0_respiratory_extended",
            "auroc",
        ),
        "vent_c2_xgb_a1": metric_value(
            "ventilation",
            "c2_copd_acute_respiratory_failure",
            "xgboost",
            "A1_respiratory_extended_24h",
            "auroc",
        ),
        "mort_c1_lr_a0_resp": metric_value(
            "mortality", "c1_discharge_icd_copd", "logistic", "A0_respiratory_extended", "auroc"
        ),
        "mort_c1_lr_a1": metric_value(
            "mortality", "c1_discharge_icd_copd", "logistic", "A1_respiratory_extended_24h", "auroc"
        ),
        "vent_c1_lr_a0_resp": metric_value(
            "ventilation", "c1_discharge_icd_copd", "logistic", "A0_respiratory_extended", "auroc"
        ),
        "vent_c1_lr_a1": metric_value(
            "ventilation", "c1_discharge_icd_copd", "logistic", "A1_respiratory_extended_24h", "auroc"
        ),
        "mort_c1_lr_delta_a1": metric_delta(
            "mortality",
            "c1_discharge_icd_copd",
            "logistic",
            "A0_respiratory_extended",
            "A1_respiratory_extended_24h",
            "auroc",
        ),
        "vent_c1_lr_delta_a1": metric_delta(
            "ventilation",
            "c1_discharge_icd_copd",
            "logistic",
            "A0_respiratory_extended",
            "A1_respiratory_extended_24h",
            "auroc",
        ),
        "delta_mort_c1": paired_delta_text("mortality", "c1_discharge_icd_copd"),
        "delta_mort_c2": paired_delta_text("mortality", "c2_copd_acute_respiratory_failure"),
        "delta_vent_c1": paired_delta_text("ventilation", "c1_discharge_icd_copd"),
        "delta_vent_c2": paired_delta_text("ventilation", "c2_copd_acute_respiratory_failure"),
        "a5_mimic_c1_selected_n": str(int(a5_mimic_c1_outcome["selected_n"])),
        "a5_mimic_c1_full_n": str(int(a5_mimic_c1_outcome["full_n"])),
        "a5_mimic_c1_full_mortality": pct(a5_mimic_c1_outcome["full_mean"]),
        "a5_mimic_c1_selected_mortality": pct(a5_mimic_c1_outcome["selected_mean"]),
        "a5_mimic_c1_full_vent": pct(a5_mimic_c1_vent["full_mean"]),
        "a5_mimic_c1_selected_vent": pct(a5_mimic_c1_vent["selected_mean"]),
        "mort_c1_a0_resp_slope": metric_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A0_respiratory_extended", "calibration_slope"
        ),
        "mort_c1_a0_resp_brier": metric_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A0_respiratory_extended", "brier"
        ),
        "mort_c1_a0_resp_ici": metric_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A0_respiratory_extended", "ici_eavg"
        ),
        "mort_c1_a1_slope": metric_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A1_respiratory_extended_24h", "calibration_slope"
        ),
        "mort_c1_a1_brier": metric_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A1_respiratory_extended_24h", "brier"
        ),
        "mort_c1_a1_ici": metric_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A1_respiratory_extended_24h", "ici_eavg"
        ),
        "mort_c1_a7_slope": metric_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A7_composite_convenience", "calibration_slope"
        ),
        "mort_c1_a7_auroc": metric_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A7_composite_convenience", "auroc"
        ),
        "mort_c1_a7_brier": metric_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A7_composite_convenience", "brier"
        ),
        "mort_c1_a7_ici": metric_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A7_composite_convenience", "ici_eavg"
        ),
        "mort_c1_a0_resp_recal_brier": recalibration_value(
            "mortality",
            "c1_discharge_icd_copd",
            "xgboost",
            "A0_respiratory_extended",
            "intercept_slope_recalibrated",
            "brier",
        ),
        "mort_c1_a0_resp_recal_ici": recalibration_value(
            "mortality",
            "c1_discharge_icd_copd",
            "xgboost",
            "A0_respiratory_extended",
            "intercept_slope_recalibrated",
            "ici_eavg",
        ),
        "mort_c1_a7_recal_brier": recalibration_value(
            "mortality",
            "c1_discharge_icd_copd",
            "xgboost",
            "A7_composite_convenience",
            "intercept_slope_recalibrated",
            "brier",
        ),
        "mort_c1_a7_recal_ici": recalibration_value(
            "mortality",
            "c1_discharge_icd_copd",
            "xgboost",
            "A7_composite_convenience",
            "intercept_slope_recalibrated",
            "ici_eavg",
        ),
        "mort_c1_a0_resp_nb_10": dca_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A0_respiratory_extended", "nb_t0.1"
        ),
        "mort_c1_a7_nb_10": dca_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A7_composite_convenience", "nb_t0.1"
        ),
        "mort_c1_a0_resp_nb_20": dca_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A0_respiratory_extended", "nb_t0.2"
        ),
        "mort_c1_a7_nb_20": dca_value(
            "mortality", "c1_discharge_icd_copd", "xgboost", "A7_composite_convenience", "nb_t0.2"
        ),
        "vent_c1_a0_resp_nb_01": dca_value(
            "ventilation", "c1_discharge_icd_copd", "xgboost", "A0_respiratory_extended", "nb_t0.01"
        ),
        "vent_c1_a1_nb_01": dca_value(
            "ventilation", "c1_discharge_icd_copd", "xgboost", "A1_respiratory_extended_24h", "nb_t0.01"
        ),
        "vent_c1_a0_resp_nb_05": dca_value(
            "ventilation", "c1_discharge_icd_copd", "xgboost", "A0_respiratory_extended", "nb_t0.05"
        ),
        "vent_c1_a1_nb_05": dca_value(
            "ventilation", "c1_discharge_icd_copd", "xgboost", "A1_respiratory_extended_24h", "nb_t0.05"
        ),
        "a0_clean_feature_count": matrix_feature_count("mortality", "A0_clean", "c1_discharge_icd_copd"),
        "a0_resp_feature_count": matrix_feature_count("mortality", "A0_respiratory_extended", "c1_discharge_icd_copd"),
        "a1_resp_feature_count": matrix_feature_count("mortality", "A1_respiratory_extended_24h", "c1_discharge_icd_copd"),
        "a6_feature_count": matrix_feature_count("mortality", "A6_density_only", "c1_discharge_icd_copd"),
        "lit_a1_high": literature_count("a1_future_window_risk", "high_risk_present"),
        "lit_a3b_high": literature_count("a3b_admin_discharge_coding_risk", "high_risk_present"),
        "lit_a3c_high": literature_count("a3c_treatment_procedure_proxy_risk", "high_risk_present"),
        "lit_a5_high": literature_count("a5_complete_case_or_required_test_selection_risk", "high_risk_present"),
        "lit_external": literature_count("external_validation", "reported_independent_or_multidatabase"),
    }


def make_table1() -> pd.DataFrame:
    mortality = read_csv(OUTPUT_TABLES / "copd_12h_cohort_definition_summary_updated.csv")
    ventilation = read_csv(OUTPUT_TABLES / "copd_12h_ventilation_outcome_summary.csv")
    rows: list[dict[str, object]] = []
    for _, row in mortality[mortality["cohort_definition"].isin(PRIMARY_COHORTS)].iterrows():
        rows.append(
            {
                "task": "in_hospital_mortality_after_12h_landmark",
                "dataset": row["dataset"],
                "cohort_definition": row["cohort_definition"],
                "risk_set_n": int(row["n_eligible_12h_mortality"]),
                "events": int(row["n_hospital_deaths_after_landmark"]),
                "event_rate": round(float(row["event_rate_after_landmark"]), 5),
                "no_skill_auprc": round(float(row["event_rate_after_landmark"]), 5),
                "early_respiratory_treatment_pct": row["early_resp_treatment_pct"],
                "baseline_invasive_ventilation_pct": row["invasive_vent_by_12h_pct"],
                "endpoint_harmonization_note": "Mortality is comparatively harmonized but still reflects database discharge and ICU-stay linkage rules.",
            }
        )
    for _, row in ventilation[ventilation["cohort_definition"].isin(PRIMARY_COHORTS)].iterrows():
        rows.append(
            {
                "task": "new_invasive_ventilation_12_to_48h",
                "dataset": row["dataset"],
                "cohort_definition": row["cohort_definition"],
                "risk_set_n": int(row["n_eligible_12h_new_invasive_vent"]),
                "events": int(row["n_new_invasive_vent_12_48h"]),
                "event_rate": round(float(row["event_rate_new_invasive_vent_12_48h"]), 5),
                "no_skill_auprc": round(float(row["event_rate_new_invasive_vent_12_48h"]), 5),
                "early_respiratory_treatment_pct": "",
                "baseline_invasive_ventilation_pct": "",
                "endpoint_harmonization_note": "Ventilation has larger source-table and prevalence differences; eICU low event rate is an endpoint-equivalence caveat.",
            }
        )
    out = pd.DataFrame(rows)
    write_csv(PACKAGE / "tables" / "table1_cohort_endpoint_reconstruction.csv", out)
    return out


def make_table2() -> pd.DataFrame:
    df = read_csv(OUTPUT_TABLES / "respiratory_audit_taxonomy_expanded.csv")
    object_map = {
        "A0": "time-legal reference specification",
        "A1": "decision-time legality and predictor-window transparency",
        "A3a": "time-ambiguous diagnostic provenance",
        "A3b": "administrative and discharge-code provenance",
        "A3c": "task-specific treatment and procedure admissibility",
        "A5": "target-population stability under required-test selection",
        "A6": "observation-process dependence",
        "A7": "composite convenience-benchmark stress test",
    }
    out = df.copy()
    out["reproducibility_object"] = out["audit_layer"].map(object_map).fillna("benchmark design feature")
    cols = [
        "audit_layer",
        "short_name",
        "reproducibility_object",
        "definition",
        "failure_mechanism",
        "example_predictor_class",
        "detectability",
        "expected_metric_artifact",
        "reporting_requirement",
        "corrective_action",
    ]
    out = out[cols]
    write_csv(PACKAGE / "tables" / "table2_benchmark_reproducibility_audit_taxonomy.csv", out)
    return out


def make_box1() -> pd.DataFrame:
    rows = [
        {
            "item": 1,
            "minimum_transparency_requirement": "Decision-time statement",
            "operational_content": "State the clinical decision point, landmark, and intended use before feature extraction.",
            "release_material": "task specifications and cohort flow table",
        },
        {
            "item": 2,
            "minimum_transparency_requirement": "Cohort logic and code lists",
            "operational_content": "Report phenotype source tables, diagnosis-code lists, text rules, first-stay handling, and whether cohort-defining codes are post-hoc administrative fields.",
            "release_material": "cohort definition taxonomy, code-list notes, and cohort flow table",
        },
        {
            "item": 3,
            "minimum_transparency_requirement": "Endpoint ascertainment and harmonization",
            "operational_content": "Describe endpoint source tables, database-specific differences, event-rate baselines, and known operational non-equivalence before interpreting external validation.",
            "release_material": "endpoint harmonization notes and no-skill AUPRC baselines",
        },
        {
            "item": 4,
            "minimum_transparency_requirement": "Predictor acquisition window",
            "operational_content": "Report the allowed time window for each predictor class and flag any window crossing the landmark.",
            "release_material": "predictor provenance table and audit taxonomy",
        },
        {
            "item": 5,
            "minimum_transparency_requirement": "Variable-level provenance",
            "operational_content": "Identify whether variables come from monitoring, laboratory testing, medication, procedure, diagnosis, or discharge coding.",
            "release_material": "variable dictionary and A3 provenance appendix",
        },
        {
            "item": 6,
            "minimum_transparency_requirement": "Task-specific predictor admissibility",
            "operational_content": "Separate legal early treatment information from downstream or outcome-defining treatment and procedure proxies.",
            "release_material": "A3c subtype table",
        },
        {
            "item": 7,
            "minimum_transparency_requirement": "Cohort and required-test selection accounting",
            "operational_content": "Report how ABG or other required-test filters alter sample size, event rate, and baseline severity.",
            "release_material": "A5 target-population shift table",
        },
        {
            "item": 8,
            "minimum_transparency_requirement": "Measurement-process feature reporting",
            "operational_content": "Identify counts, missingness, charting frequency, and recency features separately from physiologic values.",
            "release_material": "A6 density definitions and density-only model results",
        },
        {
            "item": 9,
            "minimum_transparency_requirement": "Full performance reporting",
            "operational_content": "Report discrimination, calibration, prevalence-referenced AUPRC, threshold-specific DCA, and uncertainty.",
            "release_material": "aggregate metrics, DCA tables, recalibration tables, and bootstrap outputs",
        },
        {
            "item": 10,
            "minimum_transparency_requirement": "Open reproducibility package",
            "operational_content": "Release code, configs, dictionaries, mock schemas, aggregate outputs, figure source data, and explicit restricted-data exclusions.",
            "release_material": "public reproducibility package and release checklist",
        },
    ]
    out = pd.DataFrame(rows)
    write_csv(PACKAGE / "tables" / "box1_minimum_transparency_requirements.csv", out)
    return out


def make_table3_reproducibility_layers() -> pd.DataFrame:
    rows = [
        {
            "reproducibility_layer": "cohort logic",
            "publicly_reconstructable": "yes",
            "materials_provided": "protocol, task specifications, cohort flow, ICD/text-code rules, and inclusion-exclusion aggregate tables",
            "limitations": "Credentialed users must rebuild patient-level cohorts locally under data-use agreements.",
        },
        {
            "reproducibility_layer": "endpoint definition",
            "publicly_reconstructable": "yes_with_caveats",
            "materials_provided": "endpoint harmonization notes and task-specific source summaries",
            "limitations": "MIMIC-IV and eICU invasive-ventilation endpoints are not operationally identical.",
        },
        {
            "reproducibility_layer": "decision time and predictor windows",
            "publicly_reconstructable": "yes",
            "materials_provided": "12-hour landmark task cards, audit taxonomy, and predictor provenance rules",
            "limitations": "Row-level timestamp verification requires local restricted data.",
        },
        {
            "reproducibility_layer": "predictor sets",
            "publicly_reconstructable": "yes",
            "materials_provided": "A0-A7 taxonomy, A3 variable-level provenance appendix, A3c subtype table, and A6 density definitions",
            "limitations": "Patient-level feature values are not redistributed.",
        },
        {
            "reproducibility_layer": "model training",
            "publicly_reconstructable": "yes",
            "materials_provided": "analysis scripts, fixed seeds, software requirements, and audit configurations",
            "limitations": "Exact retraining requires local access to MIMIC-IV feature matrices.",
        },
        {
            "reproducibility_layer": "patient-level predictions",
            "publicly_reconstructable": "no",
            "materials_provided": "schema and synthetic mock predictions only",
            "limitations": "Restricted by MIMIC-IV and eICU data-use agreements.",
        },
        {
            "reproducibility_layer": "restricted-data release boundary",
            "publicly_reconstructable": "yes",
            "materials_provided": "public release safety checks, identifier exclusion rules, and data/code availability statements",
            "limitations": "Public materials support benchmark inspection and reruns by credentialed users, not unrestricted patient-level replication.",
        },
        {
            "reproducibility_layer": "aggregate outputs",
            "publicly_reconstructable": "yes",
            "materials_provided": "aggregate CSV tables, figure source data, and checksum manifest",
            "limitations": "Aggregate outputs do not allow patient reidentification or individual-level error analysis.",
        },
        {
            "reproducibility_layer": "contextual literature audit",
            "publicly_reconstructable": "yes",
            "materials_provided": "extraction template, compact audit table, and boundary statements",
            "limitations": "This is a contextual scoping audit and not a PRISMA systematic review.",
        },
        {
            "reproducibility_layer": "software environment",
            "publicly_reconstructable": "yes",
            "materials_provided": "requirements.txt, environment.yml, and freeze software snapshot",
            "limitations": "Local database software and operating-system differences may affect extraction runtimes.",
        },
    ]
    out = pd.DataFrame(rows)
    write_csv(PACKAGE / "tables" / "table3_reproducibility_layers_and_public_materials.csv", out)
    return out


def make_table4_external_performance() -> pd.DataFrame:
    df = read_csv(OUTPUT_TABLES / "copd_model_family_external_metrics.csv")
    out = df[
        df["cohort_definition"].isin(PRIMARY_COHORTS)
        & df["audit_variant"].isin(PRIMARY_AUDITS)
    ].copy()
    cols = [
        "task",
        "cohort_definition",
        "model",
        "audit_variant",
        "n",
        "events",
        "event_rate",
        "auroc",
        "auprc_prevalence_ratio",
        "brier",
        "calibration_slope",
        "ici_eavg",
    ]
    out = out[cols].sort_values(["task", "cohort_definition", "model", "audit_variant"])
    write_csv(PACKAGE / "tables" / "table4_external_model_performance.csv", out)
    return out


def make_table5_bootstrap() -> pd.DataFrame:
    out = read_csv(OUTPUT_TABLES / "copd_key_bootstrap_auroc_delta_results.csv")
    write_csv(PACKAGE / "tables" / "table5_key_paired_bootstrap_auroc_deltas.csv", out)
    return out


def make_table6_a5() -> pd.DataFrame:
    df = read_csv(OUTPUT_TABLES / "copd_a5_abg_target_population_shift.csv")
    out = df[
        df["cohort_definition"].isin(PRIMARY_COHORTS)
        & df["variable"].isin(
            ["age", "female", "task_outcome", "baseline_invasive_vent", "early_resp_treatment"]
        )
    ].copy()
    write_csv(PACKAGE / "tables" / "table6_a5_required_test_target_population_shift.csv", out)
    return out


def make_table7_literature() -> pd.DataFrame:
    out = read_csv(OUTPUT_TABLES / "copd_literature_scoping_audit_summary_counts.csv")
    write_csv(PACKAGE / "tables" / "table7_contextual_literature_audit_summary.csv", out)
    return out


def make_table8_a3c_subtypes() -> pd.DataFrame:
    out = read_csv(OUTPUT_TABLES / "copd_a3c_task_specific_admissibility_subtypes.csv")
    write_csv(PACKAGE / "tables" / "table8_a3c_task_specific_admissibility_subtypes.csv", out)
    return out


def make_supplementary_cohort_mapping() -> pd.DataFrame:
    rows = [
        {
            "cohort": "C1 broad COPD/AECOPD",
            "database": "MIMIC-IV",
            "source_table": "hosp/diagnoses_icd",
            "code_or_string_rule": "ICD-9 prefixes 490, 491, 492, 496; ICD-10 prefixes J40, J41, J42, J43, J44",
            "harmonization_caveat": "Administrative discharge diagnosis evidence; post-hoc phenotype source, not an A0 predictor.",
        },
        {
            "cohort": "C1 broad COPD/AECOPD",
            "database": "eICU",
            "source_table": "diagnosis",
            "code_or_string_rule": "COPD-relevant diagnosis strings and ICD-9-style diagnosis-code text",
            "harmonization_caveat": "Diagnosis text/code structure differs from MIMIC-IV ICD discharge coding; harmonized administrative respiratory cohort, not identical phenotype.",
        },
        {
            "cohort": "C2 COPD plus acute respiratory failure",
            "database": "MIMIC-IV",
            "source_table": "hosp/diagnoses_icd",
            "code_or_string_rule": "C1 plus ICD-9 prefixes 51881, 51882, 51884 or ICD-10 prefix J96",
            "harmonization_caveat": "COPD plus acute respiratory failure administrative respiratory cohort using post-hoc diagnosis evidence.",
        },
        {
            "cohort": "C2 COPD plus acute respiratory failure",
            "database": "eICU",
            "source_table": "diagnosis",
            "code_or_string_rule": "C1 plus acute respiratory failure diagnosis text",
            "harmonization_caveat": "Text-based respiratory failure evidence is not structurally identical to MIMIC-IV ICD coding.",
        },
    ]
    out = pd.DataFrame(rows)
    write_csv(PACKAGE / "supplementary" / "tables" / "supplementary_cohort_code_string_mapping.csv", out)
    write_csv(PACKAGE / "tables" / "supplementary_cohort_code_string_mapping.csv", out)
    return out


def copy_supporting_tables() -> None:
    files = [
        "copd_a3_variable_level_provenance_appendix.csv",
        "copd_a3c_task_specific_admissibility_subtypes.csv",
        "copd_cohort_main_vs_supplementary_roles.csv",
        "copd_endpoint_harmonization_and_event_rate_caveats.csv",
        "copd_literature_scoping_audit_boundary_statements.csv",
        "copd_literature_scoping_audit_compact.csv",
        "copd_literature_scoping_audit_fulltext.csv",
        "copd_literature_scoping_audit_summary_counts.csv",
        "copd_model_family_external_dca_wide.csv",
        "copd_model_family_external_recalibration_metrics.csv",
        "copd_bootstrap_external_metric_ci.csv",
        "copd_bootstrap_paired_delta_ci.csv",
        "copd_bootstrap_run_metadata.csv",
    ]
    for name in files:
        src = OUTPUT_TABLES / name
        if src.exists():
            shutil.copy2(src, PACKAGE / "supplementary" / "tables" / name)
            print(f"Copied supplementary table {name}")


def generate_figure1_svg() -> None:
    svg = """<svg xmlns="http://www.w3.org/2000/svg" width="1300" height="760" viewBox="0 0 1300 760">
<defs>
<style>
.title{font:700 28px Arial,sans-serif;fill:#102a43}
.label{font:700 18px Arial,sans-serif;fill:#102a43}
.text{font:14px Arial,sans-serif;fill:#243b53}
.small{font:12px Arial,sans-serif;fill:#334e68}
.box{fill:#f0f7ff;stroke:#2f80ed;stroke-width:2;rx:16}
.risk{fill:#fff4e6;stroke:#f2994a;stroke-width:2;rx:16}
.open{fill:#ecfdf3;stroke:#27ae60;stroke-width:2;rx:16}
.bad{fill:#fff0f0;stroke:#eb5757;stroke-width:2;rx:16}
.arrow{stroke:#52616b;stroke-width:2;marker-end:url(#arrow)}
</style>
<marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto">
<path d="M0,0 L0,6 L9,3 z" fill="#52616b"/>
</marker>
</defs>
<text x="55" y="50" class="title">Reproducibility audit map for respiratory ICU prediction benchmarks</text>
<rect x="55" y="95" width="210" height="100" class="open"/>
<text x="75" y="125" class="label">Open ICU data</text>
<text x="75" y="153" class="text">MIMIC-IV and eICU access</text>
<text x="75" y="174" class="small">Necessary but not sufficient</text>
<line x1="265" y1="145" x2="330" y2="145" class="arrow"/>
<rect x="330" y="95" width="230" height="100" class="box"/>
<text x="350" y="125" class="label">Task reconstruction</text>
<text x="350" y="153" class="text">Cohort, endpoint, landmark</text>
<text x="350" y="174" class="small">Must be auditable before modeling</text>
<line x1="560" y1="145" x2="625" y2="145" class="arrow"/>
<rect x="625" y="95" width="250" height="100" class="box"/>
<text x="645" y="125" class="label">Admissible predictors</text>
<text x="645" y="153" class="text">Pre-landmark physiology and labs</text>
<text x="645" y="174" class="small">A0 time-legal reference</text>
<line x1="875" y1="145" x2="940" y2="145" class="arrow"/>
<rect x="940" y="95" width="280" height="100" class="open"/>
<text x="960" y="125" class="label">Reproducibility package</text>
<text x="960" y="153" class="text">Code, dictionaries, schemas</text>
<text x="960" y="174" class="small">Aggregate outputs and figure data</text>
<rect x="75" y="265" width="250" height="115" class="risk"/>
<text x="95" y="295" class="label">A1 window opacity</text>
<text x="95" y="323" class="text">Future respiratory trajectory</text>
<text x="95" y="344" class="small">Decision-time irreproducibility</text>
<line x1="200" y1="265" x2="430" y2="195" class="arrow"/>
<rect x="365" y="265" width="250" height="115" class="risk"/>
<text x="385" y="295" class="label">A3 provenance opacity</text>
<text x="385" y="323" class="text">Diagnosis, coding, treatment</text>
<text x="385" y="344" class="small">Proxy-variable ambiguity</text>
<line x1="490" y1="265" x2="730" y2="195" class="arrow"/>
<rect x="655" y="265" width="250" height="115" class="risk"/>
<text x="675" y="295" class="label">A5 selection opacity</text>
<text x="675" y="323" class="text">ABG required-test filtering</text>
<text x="675" y="344" class="small">Target-population shift</text>
<line x1="780" y1="265" x2="750" y2="195" class="arrow"/>
<rect x="945" y="265" width="250" height="115" class="risk"/>
<text x="965" y="295" class="label">A6 observation process</text>
<text x="965" y="323" class="text">Counts, missingness, frequency</text>
<text x="965" y="344" class="small">Site-dependent signal</text>
<line x1="1070" y1="265" x2="780" y2="195" class="arrow"/>
<rect x="200" y="455" width="285" height="115" class="bad"/>
<text x="220" y="485" class="label">A7 convenience benchmark</text>
<text x="220" y="513" class="text">Stacked future, proxy, and process channels</text>
<text x="220" y="534" class="small">Can perform while remaining inadmissible</text>
<line x1="343" y1="455" x2="750" y2="195" class="arrow"/>
<rect x="530" y="455" width="285" height="115" class="box"/>
<text x="550" y="485" class="label">External validation</text>
<text x="550" y="513" class="text">MIMIC-IV to eICU transfer</text>
<text x="550" y="534" class="small">Requires endpoint harmonization</text>
<line x1="672" y1="455" x2="750" y2="195" class="arrow"/>
<rect x="860" y="455" width="285" height="115" class="box"/>
<text x="880" y="485" class="label">Interpretability of claims</text>
<text x="880" y="513" class="text">AUROC plus calibration and DCA</text>
<text x="880" y="534" class="small">Performance is not admissibility</text>
<line x1="1002" y1="455" x2="1080" y2="195" class="arrow"/>
<text x="70" y="655" class="text">Audit target: independent investigators can reconstruct the same target population, endpoint, decision time, admissible predictors, and cross-database interpretation from reported materials.</text>
</svg>"""
    write_text(PACKAGE / "figures" / "figure1_reproducibility_audit_map.svg", svg)
    source = pd.DataFrame(
        [
            {"component": "open ICU data", "audit_meaning": "data access alone is insufficient"},
            {"component": "task reconstruction", "audit_meaning": "cohort, endpoint, and landmark must be specified"},
            {"component": "A1 window opacity", "audit_meaning": "future-window predictors violate decision-time legality"},
            {"component": "A3 provenance opacity", "audit_meaning": "diagnosis, coding, and treatment proxies require source audit"},
            {"component": "A5 selection opacity", "audit_meaning": "required-test filtering can change target population"},
            {"component": "A6 observation process", "audit_meaning": "measurement frequency and missingness encode care process"},
            {"component": "A7 convenience benchmark", "audit_meaning": "external performance does not establish admissibility"},
            {"component": "reproducibility package", "audit_meaning": "open code, metadata, schemas, aggregate outputs, and figure data"},
        ]
    )
    write_csv(PACKAGE / "source_data" / "figure1_reproducibility_audit_map_source.csv", source)


def copy_figures_and_source_data() -> None:
    generate_figure1_svg()
    figure_aliases = {
        "figure_1_failure_phenotype_map.svg": "figure2_failure_phenotype_map.svg",
        "figure_2_internal_external_auroc_gap.svg": "figure3_internal_external_auroc_gap.svg",
        "figure_3_a5_abg_target_population_shift.svg": "figure4_abg_complete_case_target_population_shift.svg",
        "figure_4_threshold_specific_dca.svg": "figure5_threshold_specific_decision_curve.svg",
        "figure_5_respiratory_feature_completeness.svg": "figure6_respiratory_feature_completeness.svg",
        "figure_6_published_benchmark_scoping_audit_matrix.svg": "figure7_published_benchmark_scoping_audit_matrix.svg",
        "figure_0_predictor_admissibility_diagram.svg": "supplementary_figure_predictor_admissibility_detail.svg",
    }
    for src_name, dst_name in figure_aliases.items():
        src = OUTPUT_FIGURES / src_name
        if src.exists():
            shutil.copy2(src, PACKAGE / "figures" / dst_name)
            print(f"Copied figure {src_name} -> {dst_name}")
    for path in sorted(OUTPUT_FIGURE_DATA.glob("*.csv")):
        shutil.copy2(path, PACKAGE / "source_data" / path.name)
        print(f"Copied figure source data {path.name}")


def main_manuscript_text(v: dict[str, str]) -> str:
    return f"""
# Toward reproducible respiratory ICU prediction benchmarks: a COPD/AECOPD audit of predictor admissibility, leakage, and target-population shift across MIMIC-IV and eICU

## Abstract

### Background
Open clinical AI benchmarks are often considered reproducible when data access, model code, and evaluation scripts are available. This definition is incomplete when the benchmark task itself is not transparently specified. Reproducibility also requires that independent investigators can reconstruct the same target population, endpoint, decision time, admissible predictor set, and cross-database interpretation. Respiratory ICU prediction is a demanding stress test because respiratory measurements, ABG testing, treatment escalation, diagnosis coding, and observation frequency are tightly coupled to care processes.

### Methods
We developed and applied a benchmark reproducibility audit framework for COPD/AECOPD respiratory ICU prediction using MIMIC-IV for development and internal validation and eICU-CRD for external validation. Two 12-hour landmark tasks were evaluated: in-hospital mortality after the landmark and new invasive mechanical ventilation from 12 to 48 hours among patients not invasively ventilated by 12 hours. A time-legal reference benchmark was compared with prespecified audit layers for future-window respiratory information, time-ambiguous diagnosis descriptors, administrative or discharge coding proxies, task-specific treatment and procedure proxies, arterial blood gas complete-case selection, measurement-density features, and a composite convenience benchmark. Discrimination, prevalence-aware precision-recall performance, calibration, threshold-specific decision-curve net benefit, external recalibration, and 1000-resample paired bootstrap intervals were evaluated. We also performed a contextual scoping audit of published COPD/AECOPD and respiratory ICU prediction benchmarks.

### Results
For the broad COPD mortality cohort, MIMIC-IV contained {v['mortality_c1_mimic']} and eICU contained {v['mortality_c1_eicu']}. For new invasive ventilation, MIMIC-IV contained {v['vent_c1_mimic']} whereas eICU contained {v['vent_c1_eicu']}, exposing a major cross-database endpoint-prevalence difference. Compared with the time-legal respiratory-extended reference benchmark, future respiratory trajectory features increased external AUROC from {v['mort_c1_xgb_a0_resp']} to {v['mort_c1_xgb_a1']} in broad-cohort mortality and from {v['mort_c2_xgb_a0_resp']} to {v['mort_c2_xgb_a1']} in the COPD plus acute respiratory failure mortality cohort. For new invasive ventilation, external AUROC increased from {v['vent_c1_xgb_a0_resp']} to {v['vent_c1_xgb_a1']} in the broad cohort and from {v['vent_c2_xgb_a0_resp']} to {v['vent_c2_xgb_a1']} in the COPD plus acute respiratory failure cohort. Paired bootstrap AUROC deltas for future respiratory trajectories were {v['delta_mort_c1']} and {v['delta_mort_c2']} for the mortality cohorts, compared with {v['delta_vent_c1']} and {v['delta_vent_c2']} for the ventilation cohorts. In MIMIC-IV broad-cohort mortality, ABG complete-case filtering reduced the risk set from {v['a5_mimic_c1_full_n']} to {v['a5_mimic_c1_selected_n']}, increased mortality from {v['a5_mimic_c1_full_mortality']} to {v['a5_mimic_c1_selected_mortality']}, and increased baseline invasive ventilation from {v['a5_mimic_c1_full_vent']} to {v['a5_mimic_c1_selected_vent']}. In 12 audited published benchmarks, high-risk treatment or procedure proxy features were identified in {v['lit_a3c_high']} studies and high-risk complete-case or required-test selection in {v['lit_a5_high']} studies.

### Conclusions
Open ICU data and shared code do not by themselves make a clinical AI benchmark reproducible. Respiratory ICU benchmarks require auditable cohort construction, endpoint harmonization, landmark-time legality, predictor provenance, target-population stability, calibration, threshold-specific utility, and explicit restricted-data release boundaries. External AUROC retention does not establish benchmark admissibility.

## Keywords
clinical AI; reproducibility; open science; ICU; MIMIC-IV; eICU; COPD; benchmark; leakage; predictor provenance; calibration; decision curve analysis

## Introduction

In clinical AI, reproducibility is frequently operationalized as access to data, code, and model specifications. These elements are necessary, but they are not sufficient when the benchmark task itself is opaque. A prediction benchmark is reproducible only if independent investigators can reconstruct not only the analytic code, but also the same target population, endpoint, decision time, admissible predictor set, and cross-database interpretation from the reported materials.

Open ICU databases make this issue especially important. Electronic health record data are not passive measurements of biology; they are generated by care pathways, monitoring intensity, testing decisions, documentation systems, discharge coding, and institutional practice. Two studies can use the same public database and still define different prediction problems if their landmark, predictor windows, cohort filters, or endpoint definitions differ. Conversely, a model can be externally validated and still be methodologically inadmissible if it relies on predictors unavailable at the stated decision point.

Existing reporting and reproducibility practices for clinical AI often emphasize access to code, model specifications, and evaluation scripts. In EHR benchmarks, however, the more fundamental reproducibility unit is the prediction task itself. A benchmark cannot be independently reconstructed if cohort logic, endpoint ascertainment, predictor time windows, variable provenance, required-test filters, and endpoint harmonization are not reported at sufficient granularity. This gap is especially problematic for external validation studies, where apparent transportability may reflect differences in endpoint construction or care-process documentation rather than model robustness.

Respiratory ICU prediction is a demanding stress-test domain for benchmark reproducibility. In COPD and acute respiratory failure, oxygenation variables, ABG testing, non-invasive ventilation, intubation, bronchodilator and steroid treatment, respiratory therapy documentation, and discharge diagnoses are clinically meaningful but temporally complex. Some early treatment signals can be valid predictors for mortality. The same variables can become downstream proxies or outcome-defining features for a ventilation-initiation task. Cross-database validation further requires endpoint harmonization because ventilation documentation and event prevalence can differ between databases.

We therefore developed and empirically applied a benchmark reproducibility audit framework for respiratory ICU prediction. The study had three objectives: to operationalize audit layers for decision-time legality, predictor provenance, target-population stability, observation-process dependence, and endpoint harmonization; to quantify how these layers alter discrimination, calibration, decision utility, and external validation from MIMIC-IV to eICU; and to derive minimum reporting and release elements for reproducible respiratory ICU prediction benchmarks.

## Methods

### Operational definition of benchmark reproducibility

We defined a reproducible clinical AI benchmark as one for which independent investigators can reconstruct not only the analytic code, but also the same target population, endpoint, decision time, admissible predictor set, and cross-database interpretation from the reported materials. This definition separates computational repeatability from benchmark-level reproducibility. Re-running code is insufficient if cohort construction, endpoint ascertainment, predictor windows, proxy variables, or required-test selection are not auditable.

### Data sources

MIMIC-IV v3.1 was used for model development, internal validation, and controlled audit-variant construction. eICU Collaborative Research Database v2.0 was used for external validation. Patient-level data were accessed locally under the applicable credentialing and data-use agreements. Patient-level source data, feature matrices, and predictions were not redistributed.

### Prediction tasks

The primary decision time was 12 hours after ICU admission. The first task was in-hospital mortality after the landmark among eligible COPD/AECOPD ICU stays. The second task was new invasive mechanical ventilation from 12 to 48 hours among patients who were alive and not invasively ventilated at or before the 12-hour landmark.

### Cohort definitions

The main analyses used two cohorts. C1 was a broad COPD/AECOPD cohort defined using hospital administrative diagnosis evidence. In MIMIC-IV, C1 used discharge diagnosis codes from `diagnoses_icd`: ICD-9 prefixes 490, 491, 492, and 496, and ICD-10 prefixes J40, J41, J42, J43, and J44. In eICU, C1 used COPD-relevant diagnosis strings and ICD-9-style diagnosis-code text from the `diagnosis` table. C2 was the COPD plus acute respiratory failure cohort: in MIMIC-IV, C2 required C1 plus ICD-9 prefixes 51881, 51882, or 51884, or ICD-10 prefix J96; in eICU, C2 required C1 plus acute respiratory failure diagnosis text. Because MIMIC-IV and eICU encode diagnostic evidence through different structures, C1 and C2 should be interpreted as harmonized administrative respiratory cohorts rather than identical disease phenotypes. Database-specific code lists, string rules, and mapping decisions are reported in the supplementary cohort mapping table and public metadata files. Cohort-defining diagnosis fields were treated as post-hoc phenotype sources and were not included as A0 predictors. Only the first ICU stay per patient was included in each database. Treatment-enriched and permissive convenience cohorts were retained as supplementary sensitivity or stress-test cohorts because their definitions can encode care pathways, treatment decisions, and post-hoc phenotype information.

### Endpoint harmonization across MIMIC-IV and eICU

Endpoint harmonization was treated as a reproducibility component rather than a post-hoc limitation. In-hospital mortality is comparatively more harmonized across the two databases but remains dependent on database-specific admission, stay, and discharge linkage. New invasive ventilation is more fragile because MIMIC-IV and eICU derive ventilation signals from different source structures and documentation patterns. Therefore, lower eICU ventilation event rates were interpreted as an endpoint-equivalence and transportability caveat, not as a pure model-failure result.

### Benchmark reproducibility audit framework

A0 was the time-legal reference benchmark. It used predictors measured or known at or before the 12-hour landmark and excluded explicit post-landmark and administrative proxy variables. A0 was clean with respect to landmark-time availability, but it was not assumed to be free of observation-process effects.

The A0 feature families included demographics, ICU-unit descriptors, pre-landmark vital signs, laboratory values, and time-stamped respiratory physiology available from 0 to 12 hours. Time-varying variables were summarized within prespecified windows using numeric value summaries where available, measurement counts, and missingness indicators. Model training used median imputation estimated from the MIMIC-IV training split for numeric variables, binary indicators for boolean fields, and the numeric encoded feature matrices documented in the model-matrix manifest. The exact feature-generation rules, source tables, timestamp rules, and feature lists for each audit variant are provided in the supplementary predictor-provenance tables and the public feature-manifest files. The manifest records matrix dimensions for each task and audit variant; for mortality, the A0 clean matrix contained {v['a0_clean_feature_count']} columns and the A6 density-only matrix contained {v['a6_feature_count']} columns before predictor-column exclusion rules were applied during model fitting.

A1 evaluated future-window leakage by adding 12-to-24-hour respiratory values or trajectories that were unavailable at the 12-hour decision point. A1 features were intentionally inadmissible for the 12-hour prediction task and were included only to quantify performance inflation from post-landmark information. For mortality this represents future clinical trajectory leakage. For new invasive ventilation it additionally represents outcome-proximal feature contamination because respiratory deterioration and support variables lie close to the event definition.

A3 evaluated predictor provenance. A3a included time-ambiguous diagnostic descriptors whose 12-hour availability could not be verified. A3b included administrative or discharge coding proxies such as ICD, DRG, or discharge diagnosis fields. A3c included treatment and procedure proxies. A3c was not treated as a uniform blacklist: early treatment-intensity indicators such as bronchodilators, steroids, antibiotics, and oxygen therapy were separated from downstream respiratory escalation proxies and outcome-defining respiratory support proxies such as intubation or invasive ventilation.

A5 evaluated required-test selection using ABG complete-case filtering. This audit was interpreted as a target-population and estimand shift analysis rather than a simple performance analysis. Multiple imputation was not the target of this audit layer because the estimand under required ABG availability differs from the estimand in the full eligible cohort.

A6 evaluated observation-process dependence through measurement-density-only features, including measurement counts, missingness, variable-observation breadth, and recency. A6 was not defined as laboratory values themselves, but as explicit summaries of whether and how often measurements occurred.

A7 evaluated a composite convenience benchmark that combined future-window, proxy, and measurement-process channels. A7 was not interpreted as a deployable model even if external discrimination or probability metrics were favorable.

### Modeling and evaluation

Logistic regression and XGBoost were trained in MIMIC-IV and externally validated in eICU without retraining. MIMIC-IV stays were randomly split into 70% training and 30% internal validation sets using a fixed seed. Logistic regression used L2-penalized maximum likelihood with fixed preprocessing. XGBoost used a fixed hyperparameter configuration rather than task-specific hyperparameter search, because the aim was to stress-test benchmark design rather than optimize a deployable model. Metrics included AUROC, prevalence-referenced AUPRC ratio, Brier score, calibration slope, integrated calibration error, and threshold-specific decision-curve net benefit. AUPRC ratios were used descriptively to contextualize AUPRC relative to the no-skill event-rate baseline, not as a replacement for formal transportability metrics. External recalibration was evaluated using intercept-only and intercept-plus-slope recalibration.

Because only one ICU stay per patient was included, uncertainty was estimated with 1000-resample stay-level bootstrap intervals in the external validation sets. A0-versus-audit contrasts used paired bootstrap resampling to preserve within-risk-set comparisons.

### Contextual audit of published respiratory ICU benchmarks

We audited 12 representative COPD/AECOPD and respiratory ICU prediction benchmark studies for reproducibility-relevant design features: prediction-time clarity, predictor-window auditability, future-window risk, diagnosis or administrative proxy risk, treatment/procedure proxy risk, required-test or complete-case selection, measurement-process features, external validation, calibration reporting, decision-curve reporting, code availability, and variable-dictionary availability. This audit was contextual and illustrative. It was not a PRISMA systematic review and was not used to estimate field-wide prevalence.

### Open reproducibility materials

The public repository accompanying this manuscript contains the protocol, task specifications, statistical analysis plan, audit taxonomy, predictor provenance rules, A3c admissibility subtypes, endpoint harmonization notes, contextual literature audit sheets, model evaluation tables, figure source data, mock schemas, synthetic examples, run manifests, software environment files, and restricted-data exclusion rules. Restricted patient-level data, patient-level feature matrices, and patient-level predictions are excluded.

## Results

### Benchmark reconstruction exposed cross-database endpoint non-equivalence

For broad-cohort mortality, MIMIC-IV contained {v['mortality_c1_mimic']} and eICU contained {v['mortality_c1_eicu']}. For broad-cohort new invasive ventilation, MIMIC-IV contained {v['vent_c1_mimic']} while eICU contained {v['vent_c1_eicu']}. This difference shows that cross-database replication of a clinically named respiratory endpoint requires endpoint harmonization before external performance is interpreted.

### Time-window transparency determined whether respiratory prediction was reproducible

Future respiratory trajectories produced the strongest contamination signature. In XGBoost external validation, the A1 respiratory future-window audit increased mortality AUROC from {v['mort_c1_xgb_a0_resp']} to {v['mort_c1_xgb_a1']} in C1 and from {v['mort_c2_xgb_a0_resp']} to {v['mort_c2_xgb_a1']} in C2. The paired bootstrap AUROC deltas were {v['delta_mort_c1']} and {v['delta_mort_c2']}, respectively.

The same audit had a larger task-specific impact on new invasive ventilation. AUROC increased from {v['vent_c1_xgb_a0_resp']} to {v['vent_c1_xgb_a1']} in C1 and from {v['vent_c2_xgb_a0_resp']} to {v['vent_c2_xgb_a1']} in C2, with paired bootstrap AUROC deltas of {v['delta_vent_c1']} and {v['delta_vent_c2']}. This pattern indicates that future respiratory trajectories can dominate apparent model performance when the endpoint is respiratory escalation.

The future-window signal was not limited to one model family, although its magnitude differed by model. In the broad cohort, logistic regression AUROC changed from {v['mort_c1_lr_a0_resp']} to {v['mort_c1_lr_a1']} for mortality and from {v['vent_c1_lr_a0_resp']} to {v['vent_c1_lr_a1']} for new invasive ventilation when future respiratory trajectories were added. The ventilation gain was therefore visible in both logistic regression and XGBoost, whereas the mortality effect was model dependent.

### Required-test selection changed the target population before model fitting

ABG complete-case filtering changed the benchmark population. In MIMIC-IV broad-cohort mortality, the risk set decreased from {v['a5_mimic_c1_full_n']} to {v['a5_mimic_c1_selected_n']}; mortality increased from {v['a5_mimic_c1_full_mortality']} to {v['a5_mimic_c1_selected_mortality']}; and baseline invasive ventilation increased from {v['a5_mimic_c1_full_vent']} to {v['a5_mimic_c1_selected_vent']}. Required ABG availability therefore changed the target estimand before model fitting.

### Observation-process features carried site-dependent signal

Measurement-density-only models carried limited but non-trivial signal. They were generally weaker than time-admissible clinical models and did not consistently improve external performance when evaluated alone. Their role is therefore not primarily to maximize AUROC, but to confound benchmark interpretation when measurement counts, missingness, recency, and charting frequency are mixed with clinical predictors without reporting the observation-process channel.

### Calibration, recalibration, and threshold-specific decision utility

Higher discrimination did not guarantee better probability performance. In broad-cohort mortality, the XGBoost A0 respiratory-extended reference had external calibration slope {v['mort_c1_a0_resp_slope']}, Brier score {v['mort_c1_a0_resp_brier']}, and integrated calibration error {v['mort_c1_a0_resp_ici']}. The A1 respiratory future-window model increased AUROC but had calibration slope {v['mort_c1_a1_slope']}, Brier score {v['mort_c1_a1_brier']}, and integrated calibration error {v['mort_c1_a1_ici']}. The A7 composite convenience model had external AUROC {v['mort_c1_a7_auroc']}, Brier score {v['mort_c1_a7_brier']}, calibration slope {v['mort_c1_a7_slope']}, and integrated calibration error {v['mort_c1_a7_ici']}, illustrating that favorable aggregate metrics and admissibility must be interpreted separately.

External recalibration improved probability errors without changing predictor legality. For broad-cohort mortality, intercept-plus-slope recalibration reduced the A0 respiratory-extended Brier score from {v['mort_c1_a0_resp_brier']} to {v['mort_c1_a0_resp_recal_brier']} and integrated calibration error from {v['mort_c1_a0_resp_ici']} to {v['mort_c1_a0_resp_recal_ici']}. The corresponding A7 values changed from Brier score {v['mort_c1_a7_brier']} to {v['mort_c1_a7_recal_brier']} and integrated calibration error {v['mort_c1_a7_ici']} to {v['mort_c1_a7_recal_ici']}. These improvements support the distinction between recalibrating probabilities and validating predictor admissibility.

The apparent probability advantage of A7 was not interpreted as clinical validity because A7 used information channels that were unavailable or inadmissible at the 12-hour decision point. Calibration can assess probability alignment conditional on a predictor set, but it cannot certify that the predictor set is clinically admissible.

Decision-curve analysis showed threshold-dependent utility. In broad-cohort mortality, XGBoost A7 had higher external net benefit than the A0 respiratory-extended reference at 10% risk threshold ({v['mort_c1_a7_nb_10']} versus {v['mort_c1_a0_resp_nb_10']}) and 20% threshold ({v['mort_c1_a7_nb_20']} versus {v['mort_c1_a0_resp_nb_20']}). This apparent utility was not interpreted as deployable clinical benefit because A7 includes inadmissible channels. For new invasive ventilation, eICU event prevalence was low and net benefit was concentrated at very low thresholds; in C1, A0 respiratory-extended and A1 respiratory future-window models had net benefit {v['vent_c1_a0_resp_nb_01']} and {v['vent_c1_a1_nb_01']} at 1%, but {v['vent_c1_a0_resp_nb_05']} and {v['vent_c1_a1_nb_05']} at 5%. These DCA results were interpreted descriptively and threshold-specifically, not as evidence of deployment readiness. Negative net benefit at higher thresholds indicates that the model would perform worse than the default strategy at those thresholds under the specified harm-benefit exchange.

### External performance did not establish benchmark admissibility

The A7 composite convenience benchmark did not universally fail on all external metrics. In some settings it retained external AUROC or produced favorable aggregate probability and net-benefit metrics. This result separates statistical performance from benchmark admissibility. A benchmark can externally validate while still being clinically non-actionable if its predictors are unavailable, outcome-proximal, generated by downstream care, or dependent on site-specific measurement processes.

### Published benchmarks incompletely documented the same reproducibility-relevant risks

The contextual scoping audit of 12 published respiratory ICU benchmarks found high-risk future-window design features in {v['lit_a1_high']} studies, high-risk administrative or discharge coding proxies in {v['lit_a3b_high']} studies, high-risk treatment/procedure proxy features in {v['lit_a3c_high']} studies, and high-risk complete-case or required-test selection in {v['lit_a5_high']} studies. Independent or multidatabase external validation was reported in {v['lit_external']} studies. These findings show that the targeted risks are visible in representative published practice or insufficiently auditable from published reports.

## Discussion

### Principal findings

This study shows that reproducibility of clinical AI benchmarks can fail even when public ICU data are available and external validation is performed. The observed failures occurred at three levels: task-specification failure through endpoint and predictor-window ambiguity; population-definition failure through required-test selection; and interpretive failure when external AUROC was treated as sufficient evidence of benchmark validity.

### Reproducibility beyond code availability

Code availability enables computational reruns, but it does not guarantee that the benchmark represents the same clinical question. Reproducible clinical AI requires a decision-time statement, predictor acquisition windows, variable-level provenance, task-specific admissibility rules, cohort and required-test selection accounting, endpoint harmonization, calibration and decision-utility reporting, and clear restricted-data boundaries. Otherwise, shared code can faithfully reproduce an invalid or non-actionable benchmark.

We therefore distinguish computational reproducibility, which concerns whether the same code can reproduce the same numbers, from benchmark reproducibility, which concerns whether the same clinical prediction problem can be reconstructed and interpreted. The latter is the relevant unit for open clinical AI benchmarks because two reproducible codebases can still encode different cohorts, endpoints, predictor windows, or target populations.

### Why open ICU benchmarks are especially vulnerable

ICU EHR data are generated by clinical workflows. ABG measurement is more likely in unstable or ventilated patients; intubation and ventilation records can be downstream treatment events; discharge codes can summarize events that occurred after the prediction time; and measurement frequency reflects care intensity as well as physiology. These properties make open ICU benchmarks valuable but also highly sensitive to undocumented design choices.

### Implications for reporting and benchmark release

A respiratory ICU benchmark release should be considered incomplete without an auditable task card, endpoint harmonization statement, predictor provenance dictionary, A3 treatment/procedure admissibility rules, A5 target-population shift table, measurement-density definitions, complete performance reporting beyond AUROC, and a public reproducibility package containing code, mock schemas, aggregate outputs, figure source data, and restricted-data exclusions.

### Limitations

The empirical validation used MIMIC-IV and eICU only. International transport to AmsterdamUMCdb, HiRID, or other ICU databases was not evaluated. The 12-hour landmark was chosen as a plausible early ICU decision point, but admissibility patterns may differ at 6 hours, 24 hours, or treatment-specific decision points. COPD/AECOPD respiratory prediction was used as a stress-test domain, and the observed magnitudes should not be assumed to quantify benchmark reproducibility failures in all ICU tasks. The eICU ventilation endpoint had a low event rate and may not be operationally equivalent to the MIMIC-IV ventilation endpoint. The contextual literature audit was not systematic and does not estimate field-wide prevalence. Decision-curve analyses were threshold-specific, but bootstrap confidence intervals for net benefit were not the primary uncertainty target. Because patient-level data and predictions cannot be redistributed under data-use agreements, reproducibility is supported through code, mock schemas, aggregate outputs, figure source data, and audit metadata rather than unrestricted replication from raw patient-level files.

## Conclusions

Public ICU data and shared code establish only part of clinical AI reproducibility. In respiratory ICU prediction, benchmark reproducibility also requires that the clinical task itself be auditable: the target population, endpoint, decision time, predictor provenance, required-test selection, observation process, and cross-database harmonization must be explicitly reported. This cross-database audit across MIMIC-IV and eICU shows that future respiratory trajectories, required ABG testing, and convenience predictor channels can alter apparent performance or target estimands, and that external AUROC retention does not establish decision-time admissibility.
"""


def supplementary_text() -> str:
    return """
# Supplementary Information

## Supplementary Methods

### Cohort roles
C1 and C2 are the primary cohorts because both can be evaluated in MIMIC-IV and eICU with interpretable external validation. C3 treatment-enriched COPD and C4 convenience COPD are supplementary stress-test cohorts only. They are not treated as equal primary target populations because their definitions can encode treatment pathways and permissive phenotype information.

### A3 treatment and procedure subtype rules
A3c was separated into early treatment-intensity indicators, downstream respiratory escalation proxies, outcome-defining respiratory support proxies, downstream procedure or diagnostic proxies, and non-respiratory treatment-escalation proxies. Bronchodilators, steroids, antibiotics, and oxygen therapy can be legal predictors in some mortality designs when timestamped before the landmark. NIV, intubation, and invasive ventilation are high-risk or outcome-defining for new-ventilation tasks.

### A6 measurement-density definitions
A6 uses observation-process summaries rather than laboratory values themselves. Features include total measurement counts, unique observed variable counts, missingness counts, and recency or charting-frequency summaries where available.

### Endpoint harmonization
Mortality is treated as comparatively harmonized. New invasive ventilation is treated as endpoint-fragile because source tables, documentation intensity, and event prevalence differ substantially between MIMIC-IV and eICU.

### Contextual literature audit boundary
The literature audit is a contextual scoping audit. It is not a PRISMA systematic review, does not use dual independent screening, and does not estimate prevalence of reporting or design risks across all respiratory ICU prediction studies.

## Supplementary Tables
The supplementary table directory contains the A3 variable-level provenance appendix, A3c subtype table, main-versus-supplementary cohort role table, endpoint harmonization notes, threshold-specific DCA table, recalibration table, bootstrap metric confidence intervals, paired bootstrap deltas, bootstrap run metadata, and contextual literature audit files.

## Supplementary Figures
The supplementary figure candidates include the detailed predictor admissibility diagram and respiratory feature completeness figure if the main text is limited to fewer figures.
"""


def box1_markdown() -> str:
    df = make_box1()
    lines = ["# Box 1. Minimum transparency requirements for reproducible ICU prediction benchmarks", ""]
    for _, row in df.iterrows():
        lines.append(f"{int(row['item'])}. **{row['minimum_transparency_requirement']}**")
        lines.append(f"   {row['operational_content']}")
        lines.append(f"   Public material: {row['release_material']}.")
        lines.append("")
    return "\n".join(lines)


def figure_legends() -> str:
    return """
# Figure Legends

## Figure 1. Reproducibility audit map for respiratory ICU prediction benchmarks
Conceptual map showing why open ICU data and runnable code are insufficient without auditable cohort construction, endpoint definition, landmark-time legality, predictor provenance, target-population stability, external validation interpretation, and open non-patient-level materials.

## Figure 2. Failure phenotype map across audit variants and model families
Audit variants are positioned by internal-external AUROC optimism gap and external calibration-slope deviation. The figure separates relatively transportable benchmarks, discrimination optimism, probability unreliability, and pseudo-performance collapse.

## Figure 3. Internal-external AUROC gap by task, model family, and audit variant
Comparison of internal and external discrimination for mortality and new invasive ventilation. The figure highlights that the highest internal performance is not the same as reproducible benchmark interpretation.

## Figure 4. ABG complete-case selection as target-population shift
Full risk sets and ABG complete-case selected sets are compared for event rate, baseline invasive ventilation, and early respiratory treatment. Required-test filtering changes the target population before model fitting.

## Figure 5. Threshold-specific decision-curve net benefit
External net benefit is reported at task-appropriate thresholds. Mortality thresholds and ventilation thresholds are interpreted separately because event rates and clinical action thresholds differ.

## Figure 6. Respiratory feature completeness across MIMIC-IV and eICU
Completeness of respiratory-specific variables in the pre-landmark feature window. Cross-database differences motivate explicit reporting of measurement availability and observation-process features.

## Figure 7. Contextual scoping audit of published respiratory ICU benchmarks
Matrix of reproducibility-relevant design and reporting risks in representative published respiratory ICU prediction studies. The audit is contextual and not a systematic review.
"""


def table_legends() -> str:
    return """
# Table Legends

## Table 1. Cohort and endpoint reconstruction
Risk-set sizes, event counts, event rates, no-skill AUPRC baselines, and endpoint-harmonization notes for mortality and new invasive ventilation in MIMIC-IV and eICU.

## Table 2. Benchmark reproducibility audit taxonomy
Definitions, reproducibility objects, failure mechanisms, detectability, expected metric artifacts, reporting requirements, and corrective actions for the A0-A7 audit layers.

## Table 3. Reproducibility layers and public materials
Public reconstructability of cohort logic, endpoint definitions, predictor sets, model training, patient-level results, aggregate outputs, contextual literature audit, and software environment.

## Table 4. External model performance
External discrimination, prevalence-referenced AUPRC ratio, Brier score, calibration slope, and integrated calibration error by task, cohort, model family, and audit variant.

## Table 5. Key paired bootstrap AUROC deltas
1000-resample paired bootstrap deltas comparing audit variants with the corresponding reference benchmark.

## Table 6. Required-test target-population shift
Full risk-set versus ABG complete-case comparisons for age, sex, event rate, baseline invasive ventilation, and early respiratory treatment.

## Table 7. Contextual literature audit summary
Counts of audited published benchmarks by reproducibility-relevant risk domain and reporting classification.

## Table 8. A3c task-specific admissibility subtypes
Subtype definitions and examples separating early treatment-intensity indicators from downstream respiratory escalation, outcome-defining respiratory support, procedure or diagnostic proxies, and non-respiratory escalation proxies.
"""


def cover_letter() -> str:
    return """
Dear Editors,

We submit the manuscript "Toward reproducible respiratory ICU prediction benchmarks: a COPD/AECOPD audit of predictor admissibility, leakage, and target-population shift across MIMIC-IV and eICU" for consideration in BMC Medical Research Methodology, for the Collection on reproducibility, transparency, and open science.

Our manuscript addresses a limitation in current open clinical AI research: public data access and shared code do not by themselves make a benchmark reproducible if the underlying decision time, predictor provenance, cohort selection, and endpoint harmonization remain insufficiently transparent.

Using COPD/AECOPD respiratory ICU prediction as an empirically demanding use case, we show that benchmark reproducibility can fail through future-window leakage, proxy-variable ambiguity, complete-case target-population shift, measurement-process dependence, and cross-database endpoint non-equivalence, even when external AUROC appears acceptable. The study does not present another COPD prediction model. It presents an operational audit framework for deciding whether a clinical AI benchmark is reproducible and interpretable before performance claims are accepted.

The manuscript directly addresses the Collection themes of reproducibility in study design and reporting, open code and materials, and transparency in clinical research practice. The accompanying public repository contains an audit taxonomy, predictor-provenance files, endpoint-harmonization notes, contextual scoping audit materials, aggregate output tables, figure source data, mock schemas, and an explicit public reproducibility package that excludes restricted patient-level MIMIC-IV and eICU data. Repository: [URL]; release: [tag]; archived DOI or commit hash: [DOI or hash].

The work is original, is not under consideration elsewhere, and all authors will approve the submitted version. Patient-level MIMIC-IV and eICU-CRD data are not redistributed and remain available only to credentialed users under the corresponding data-use agreements.

Sincerely,

[Corresponding author name]
"""


def statements() -> dict[str, str]:
    return {
        "data_availability_statement_bmc.md": """
# Data Availability Statement

Patient-level MIMIC-IV and eICU-CRD data were not redistributed. MIMIC-IV v3.1 and eICU Collaborative Research Database v2.0 are available to credentialed users through PhysioNet under the corresponding data-use agreements. The submission package provides aggregate cohort counts, endpoint harmonization notes, variable-level provenance tables, audit taxonomy files, contextual literature audit tables, figure source data, mock schemas, and synthetic examples. These materials are sufficient to inspect the benchmark logic and to reproduce the analytic workflow after credentialed users configure local database access.
""",
        "code_availability_statement_bmc.md": """
# Code Availability Statement

The public repository accompanying this manuscript contains analysis scripts, audit configurations, cohort and predictor dictionaries, public-release schemas, synthetic mock inputs, aggregate output tables, figure source data, and a checksum-based freeze manifest. Repository: [URL]; release: [tag]; archived DOI or commit hash: [DOI or hash]. Raw MIMIC-IV and eICU files, patient-level intermediate extracts, feature matrices, and patient-level predictions are excluded from public release.
""",
        "ethics_and_data_use_statement_bmc.md": """
# Ethics and Data Use Statement

This study used deidentified public ICU databases. Access to MIMIC-IV and eICU-CRD requires credentialing and compliance with the relevant PhysioNet data-use agreements. The analysis did not attempt to reidentify individuals. No patient-level data are redistributed in the manuscript package or public reproducibility package.
""",
        "competing_interests_placeholder.md": """
# Competing Interests

The authors declare no competing interests. Replace this placeholder if any author has relevant financial or non-financial competing interests.
""",
        "author_contributions_placeholder.md": """
# Author Contributions

[Author initials] conceived the study. [Author initials] designed the reproducibility audit framework. [Author initials] performed cohort construction, feature extraction, model training, evaluation, bootstrap analysis, contextual literature audit, and figure generation. [Author initials] interpreted the results and drafted the manuscript. All authors reviewed and approved the submitted manuscript.
""",
        "funding_placeholder.md": """
# Funding

[Insert funding information or state that no specific funding was received.]
""",
    }


def guidance_alignment_text() -> str:
    return """
# Relationship to Reporting, Bias-Assessment, and Trustworthy-AI Guidance

The framework is complementary to TRIPOD+AI, PROBAST+AI, and FUTURE-AI. It does not replace reporting or risk-of-bias guidance. It operationalizes a benchmark-level reproducibility layer before performance claims are interpreted.

| Audit dimension | Related guidance dimension | Added operational value |
|---|---|---|
| Landmark-time predictor admissibility | TRIPOD+AI reporting of predictors, timing, and outcome | Moves from reporting variables to judging whether each variable is usable at the prediction time |
| A1 future-window leakage | PROBAST+AI predictor and analysis domains | Identifies post-landmark predictor contamination |
| A3 proxy leakage | PROBAST+AI predictor and applicability domains | Separates time-ambiguous diagnosis, administrative coding, and treatment/procedure proxies |
| A5 complete-case selection | PROBAST+AI participants and missing-data domains | Reframes required-test filtering as target-population and estimand shift |
| A6 measurement density | FUTURE-AI robustness, reliability, and monitoring principles | Treats the EHR observation process as an auditable information channel |
| Calibration and DCA | TRIPOD+AI performance reporting | Adds probability reliability and clinical utility to benchmark interpretation |
| Failure phenotype map | FUTURE-AI lifecycle trustworthiness | Provides pre-deployment risk signatures for benchmark interpretation |
"""


def bmc_public_readme() -> str:
    return """
# Public Reproducibility Package

This package supports the BMC Medical Research Methodology submission on reproducible respiratory ICU prediction benchmarks.

## Core Principle

Open ICU data and shared code are necessary but insufficient for benchmark reproducibility. The prediction problem itself must be auditable: cohort construction, endpoint definition, landmark time, predictor provenance, target-population selection, cross-database endpoint harmonization, performance reporting, and release boundaries must be explicit.

## Included

- Protocol and statistical analysis plan.
- Audit taxonomy and predictor-provenance metadata.
- Endpoint harmonization notes.
- A3c task-specific admissibility subtype table.
- Contextual scoping audit extraction tables.
- Aggregate model-performance tables.
- Figure source data and SVG figures.
- Mock schemas and synthetic example inputs.
- Analysis scripts and run-order manifest.
- Freeze checksums and software environment snapshot.

## Excluded

- Raw MIMIC-IV and eICU-CRD data.
- Patient-level intermediate extracts.
- Patient-level feature matrices.
- Patient-level predictions.
- Any row-level data derived from restricted clinical databases.

Credentialed users must obtain MIMIC-IV and eICU-CRD through PhysioNet and configure local data paths before running cohort extraction and model-training scripts.
"""


def submission_readiness_checklist() -> str:
    return """
# BMC Submission Readiness Checklist

## Blocking Item Before Formal Submission

- A public GitHub, OSF, or Zenodo-backed repository must be created from `public_reproducibility_package/`.
- Insert the repository URL, release tag, commit hash, and DOI if available into:
  - `statements/code_availability_statement_bmc.md`
  - `manuscript/cover_letter_bmc_mrm.md`
  - the final manuscript data/code availability section

## Required Repository Contents

- `README.md`
- `analysis_manifest.yml`
- `requirements.txt` or `environment.yml`
- protocol files
- audit taxonomy files
- predictor provenance files
- endpoint harmonization notes
- A3c admissibility subtype table
- contextual scoping audit extraction tables
- aggregate output tables
- figure source data
- mock schemas and synthetic examples
- restricted-data exclusion statement

## Restricted Materials That Must Not Be Uploaded

- Raw MIMIC-IV files
- Raw eICU files
- Patient-level intermediate extracts
- Patient-level feature matrices
- Patient-level predictions
- Any row-level table containing patient or ICU stay identifiers from restricted databases
"""


def analysis_manifest_yml() -> str:
    return """
project: copd_respiratory_icu_benchmark_reproducibility_audit
target_journal: BMC Medical Research Methodology
collection: Reproducibility, transparency, and open science
primary_databases:
  - MIMIC-IV v3.1
  - eICU Collaborative Research Database v2.0
restricted_data_policy:
  public_release_allowed:
    - code
    - protocol
    - metadata dictionaries
    - aggregate outputs
    - figure source data without patient identifiers
    - synthetic mock examples
  public_release_excluded:
    - raw clinical databases
    - patient-level extracts
    - patient-level feature matrices
    - patient-level predictions
run_order:
  - scripts/00_environment/check_readiness.py
  - scripts/00_environment/scan_respiratory_source_feasibility.py
  - scripts/01_cohort/build_copd_12h_cohort_backbone.py
  - scripts/02_outcomes/build_respiratory_ventilation_outcomes.py
  - scripts/03_features/build_copd_model_matrices_from_icu_audit_features.py
  - scripts/03_features/build_respiratory_specific_feature_extension.py
  - scripts/04_models/train_copd_logistic_audit.py
  - scripts/04_models/train_copd_xgboost_audit.py
  - scripts/05_reporting/build_copd_logistic_result_summaries.py
  - scripts/05_reporting/build_model_family_summary.py
  - scripts/05_reporting/build_model_family_dca.py
  - scripts/05_reporting/build_model_family_recalibration_analysis.py
  - scripts/05_reporting/build_bootstrap_uncertainty.py --n-bootstrap 1000
  - scripts/05_reporting/extract_literature_pdf_text.py
  - scripts/05_reporting/build_literature_scoping_audit.py
  - scripts/05_reporting/build_figure_assets.py
  - scripts/05_reporting/build_submission_hardening_assets.py
  - scripts/05_reporting/build_bmc_reproducibility_submission_package.py
"""


def copy_public_reproducibility_package() -> None:
    dest = PACKAGE / "public_reproducibility_package"
    for src_file in [PROJECT_ROOT / "requirements.txt", PROJECT_ROOT / "environment.yml"]:
        if src_file.exists():
            shutil.copy2(src_file, dest / src_file.name)
    for folder_name, src_dir in [
        ("protocol", PROTOCOL),
        ("scripts", SCRIPTS),
        ("public_release_base", PUBLIC_RELEASE),
    ]:
        if src_dir.exists():
            shutil.copytree(src_dir, dest / folder_name, dirs_exist_ok=True)

    metadata_dest = dest / "metadata"
    metadata_dest.mkdir(parents=True, exist_ok=True)
    metadata_files = [
        "a3_proxy_classification_rules.csv",
        "a6_respiratory_measurement_density_definitions.csv",
        "benchmark_audit_recipe_checklist.csv",
        "copd_a3c_task_specific_admissibility_subtypes.csv",
        "copd_cohort_definition_taxonomy.csv",
        "copd_cohort_main_vs_supplementary_roles.csv",
        "copd_literature_scoping_audit_boundary_statements.csv",
        "expected_outputs_manifest.csv",
        "guidance_mapping_tripod_probast_future_ai.csv",
        "predictor_provenance_availability_table.csv",
        "respiratory_audit_taxonomy.csv",
        "respiratory_audit_taxonomy_expanded.csv",
        "scoping_audit_extraction_template.csv",
        "scoping_literature_candidate_list.csv",
    ]
    for name in metadata_files:
        src = METADATA / name
        if src.exists():
            shutil.copy2(src, metadata_dest / name)

    aggregate_dest = dest / "aggregate_outputs" / "tables"
    aggregate_dest.mkdir(parents=True, exist_ok=True)
    aggregate_files = [
        "copd_12h_cohort_definition_summary_updated.csv",
        "copd_12h_ventilation_outcome_summary.csv",
        "copd_a5_abg_target_population_shift.csv",
        "copd_endpoint_harmonization_and_event_rate_caveats.csv",
        "copd_key_bootstrap_auroc_delta_results.csv",
        "copd_model_family_external_metrics.csv",
        "copd_model_family_external_dca_wide.csv",
        "copd_model_family_external_recalibration_metrics.csv",
        "copd_literature_scoping_audit_compact.csv",
        "copd_literature_scoping_audit_fulltext.csv",
        "copd_literature_scoping_audit_summary_counts.csv",
        "respiratory_audit_taxonomy_expanded.csv",
    ]
    for name in aggregate_files:
        src = OUTPUT_TABLES / name
        if src.exists():
            shutil.copy2(src, aggregate_dest / name)
    cohort_mapping = PACKAGE / "supplementary" / "tables" / "supplementary_cohort_code_string_mapping.csv"
    if cohort_mapping.exists():
        shutil.copy2(cohort_mapping, aggregate_dest / cohort_mapping.name)

    fig_dest = dest / "figures"
    fig_dest.mkdir(parents=True, exist_ok=True)
    for path in sorted((PACKAGE / "figures").glob("*.svg")):
        shutil.copy2(path, fig_dest / path.name)

    figure_data_dest = dest / "figure_source_data"
    figure_data_dest.mkdir(parents=True, exist_ok=True)
    for path in sorted((PACKAGE / "source_data").glob("*.csv")):
        shutil.copy2(path, figure_data_dest / path.name)

    write_text(dest / "README.md", bmc_public_readme())
    write_text(dest / "analysis_manifest.yml", analysis_manifest_yml())
    write_text(dest / "SUBMISSION_READINESS_CHECKLIST.md", submission_readiness_checklist())
    write_csv(dest / "reproducibility_layers_and_public_materials.csv", make_table3_reproducibility_layers())
    write_csv(dest / "box1_minimum_transparency_requirements.csv", make_box1())
    write_text(dest / "dataset_paths_template.yaml", "mimic_iv_root: /path/to/mimic-iv-3.1\neicu_root: /path/to/eicu-collaborative-research-database-2.0\n")
    public_release_safety_check(dest)


def public_release_safety_check(dest: Path) -> None:
    restricted_exact = {"subject_id", "hadm_id", "stay_id", "icustay_id", "patientunitstayid"}
    rows = []
    for path in sorted(dest.rglob("*.csv")):
        try:
            df = pd.read_csv(path, nrows=0)
            cols = set(df.columns)
        except Exception as exc:  # pragma: no cover - diagnostic path
            rows.append(
                {
                    "path": str(path.relative_to(dest)),
                    "readable": False,
                    "restricted_identifier_columns": "",
                    "public_release_flag": "review",
                    "note": str(exc),
                }
            )
            continue
        hits = sorted(cols & restricted_exact)
        rows.append(
            {
                "path": str(path.relative_to(dest)),
                "readable": True,
                "restricted_identifier_columns": ";".join(hits),
                "public_release_flag": "review" if hits else "ok",
                "note": "Exact restricted identifier column found" if hits else "No exact restricted identifier column in header",
            }
        )
    write_csv(dest / "public_release_safety_checks.csv", pd.DataFrame(rows))


def package_readme() -> str:
    return """
# BMC Reproducibility Submission Package

This package reframes the COPD/AECOPD respiratory ICU audit for BMC Medical Research Methodology and the Collection on reproducibility, transparency, and open science.

## Core Positioning

Open ICU data and shared code do not automatically make clinical AI benchmarks reproducible. Reproducibility also requires auditable cohort construction, endpoint definition, predictor provenance, landmark-time legality, target-population stability, calibration and utility reporting, and endpoint harmonization.

## Contents

- `manuscript/`: BMC-oriented main manuscript draft, cover letter, Box 1, and figure/table legends.
- `tables/`: main manuscript table candidates generated from aggregate analysis outputs.
- `figures/`: BMC-ordered SVG figure files.
- `source_data/`: figure source-data CSV files.
- `supplementary/`: supplementary information draft and supporting aggregate tables.
- `statements/`: data availability, code availability, ethics/data-use, author-contribution, funding, and competing-interest placeholders.
- `journal_checklists/`: relationship to TRIPOD+AI, PROBAST+AI, and FUTURE-AI.
- `public_reproducibility_package/`: local safe-to-publish package skeleton with code, schemas, metadata, aggregate outputs, and restricted-data exclusions.
- `freeze/`: checksum-based snapshot and output consistency audit.

## Manual actions before submission

1. Mirror `public_reproducibility_package/` to GitHub or OSF and insert the URL, release tag, commit hash, or DOI into the code availability statement.
2. Replace author, affiliation, contribution, funding, and competing-interest placeholders.
3. Convert markdown files into BMC submission format.
4. Check figure resolution and journal layout requirements.
5. Reconfirm that no patient-level data are included in the public repository.
"""


def hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def freeze_audit() -> None:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    run_id = "bmc_reproducibility_freeze_20260511"
    roots = [
        PACKAGE / "manuscript",
        PACKAGE / "tables",
        PACKAGE / "figures",
        PACKAGE / "source_data",
        PACKAGE / "supplementary",
        PACKAGE / "statements",
        PACKAGE / "journal_checklists",
        PACKAGE / "public_reproducibility_package",
        OUTPUT_TABLES,
        OUTPUT_FIGURES,
        OUTPUT_FIGURE_DATA,
        METADATA,
        PROTOCOL,
    ]
    rows = []
    for root in roots:
        if not root.exists():
            continue
        for path in sorted(root.rglob("*")):
            if path.is_file():
                rows.append(
                    {
                        "run_id": run_id,
                        "path": str(path.relative_to(PROJECT_ROOT)),
                        "size_bytes": path.stat().st_size,
                        "sha256": hash_file(path),
                    }
                )
    write_csv(PACKAGE / "freeze" / "output_file_checksums.csv", pd.DataFrame(rows).sort_values("path"))

    script_rows = []
    for path in sorted(SCRIPTS.rglob("*.py")):
        script_rows.append(
            {
                "run_id": run_id,
                "path": str(path.relative_to(PROJECT_ROOT)),
                "size_bytes": path.stat().st_size,
                "sha256": hash_file(path),
            }
        )
    write_csv(PACKAGE / "freeze" / "script_version_checksums.csv", pd.DataFrame(script_rows))

    env = pd.DataFrame(
        [
            {
                "run_id": run_id,
                "freeze_time_utc": now,
                "python": sys.version.replace("\n", " "),
                "platform": platform.platform(),
                "pandas": pd.__version__,
            }
        ]
    )
    write_csv(PACKAGE / "freeze" / "software_environment.csv", env)

    manifest = pd.DataFrame(
        [
            {
                "run_id": run_id,
                "freeze_time_utc": now,
                "package": str(PACKAGE.relative_to(PROJECT_ROOT)),
                "status": "local_submission_package_created",
                "note": "Online repository DOI or commit hash must be inserted after public mirroring.",
            }
        ]
    )
    write_csv(PACKAGE / "freeze" / "analysis_freeze_manifest.csv", manifest)

    required = [
        PACKAGE / "manuscript" / "main_manuscript_draft_bmc.md",
        PACKAGE / "manuscript" / "cover_letter_bmc_mrm.md",
        PACKAGE / "manuscript" / "box1_minimum_transparency_requirements.md",
        PACKAGE / "supplementary" / "supplementary_information_bmc.md",
        PACKAGE / "tables" / "table1_cohort_endpoint_reconstruction.csv",
        PACKAGE / "tables" / "table2_benchmark_reproducibility_audit_taxonomy.csv",
        PACKAGE / "tables" / "table3_reproducibility_layers_and_public_materials.csv",
        PACKAGE / "tables" / "box1_minimum_transparency_requirements.csv",
        PACKAGE / "statements" / "data_availability_statement_bmc.md",
        PACKAGE / "statements" / "code_availability_statement_bmc.md",
        PACKAGE / "public_reproducibility_package" / "README.md",
        PACKAGE / "public_reproducibility_package" / "analysis_manifest.yml",
    ]
    audit = pd.DataFrame(
        [
            {
                "artifact": str(path.relative_to(PROJECT_ROOT)),
                "exists": path.exists(),
                "size_bytes": path.stat().st_size if path.exists() else 0,
            }
            for path in required
        ]
    )
    write_csv(PACKAGE / "freeze" / "manuscript_output_consistency_audit.csv", audit)
    flags = audit[~audit["exists"] | (audit["size_bytes"] <= 0)].copy()
    write_csv(PACKAGE / "freeze" / "manuscript_output_consistency_flags.csv", flags)


def package_manifest() -> None:
    rows = []
    for path in sorted(PACKAGE.rglob("*")):
        if path.is_file():
            rows.append(
                {
                    "path": str(path.relative_to(PACKAGE)),
                    "size_bytes": path.stat().st_size,
                    "category": path.relative_to(PACKAGE).parts[0],
                }
            )
    write_csv(PACKAGE / "submission_package_bmc_manifest.csv", pd.DataFrame(rows))


def main() -> int:
    ensure_dirs()
    make_table1()
    make_table2()
    make_box1()
    make_table3_reproducibility_layers()
    make_table4_external_performance()
    make_table5_bootstrap()
    make_table6_a5()
    make_table7_literature()
    make_table8_a3c_subtypes()
    make_supplementary_cohort_mapping()
    copy_supporting_tables()
    copy_figures_and_source_data()

    v = headline_values()
    write_text(PACKAGE / "manuscript" / "main_manuscript_draft_bmc.md", main_manuscript_text(v))
    write_text(PACKAGE / "supplementary" / "supplementary_information_bmc.md", supplementary_text())
    write_text(PACKAGE / "manuscript" / "box1_minimum_transparency_requirements.md", box1_markdown())
    write_text(PACKAGE / "manuscript" / "figure_legends_bmc.md", figure_legends())
    write_text(PACKAGE / "manuscript" / "table_legends_bmc.md", table_legends())
    write_text(PACKAGE / "manuscript" / "cover_letter_bmc_mrm.md", cover_letter())
    for name, content in statements().items():
        write_text(PACKAGE / "statements" / name, content)
    write_text(PACKAGE / "journal_checklists" / "tripod_probast_future_ai_bmc_mapping.md", guidance_alignment_text())
    write_text(PACKAGE / "README.md", package_readme())
    copy_public_reproducibility_package()
    freeze_audit()
    package_manifest()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
