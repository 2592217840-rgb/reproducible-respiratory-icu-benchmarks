from __future__ import annotations

import gzip
import importlib.util
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
MIMIC_ROOT = (PROJECT_ROOT / "../mimic-iv-3.1/mimic-iv-3.1").resolve()
EICU_ROOT = (
    PROJECT_ROOT
    / "../eicu-collaborative-research-database-2.0/eicu-collaborative-research-database-2.0"
).resolve()


REQUIRED_MIMIC_FILES = [
    "hosp/admissions.csv.gz",
    "hosp/patients.csv.gz",
    "hosp/diagnoses_icd.csv.gz",
    "hosp/d_icd_diagnoses.csv.gz",
    "hosp/drgcodes.csv.gz",
    "hosp/prescriptions.csv.gz",
    "hosp/labevents.csv.gz",
    "icu/icustays.csv.gz",
    "icu/chartevents.csv.gz",
    "icu/d_items.csv.gz",
    "icu/inputevents.csv.gz",
    "icu/procedureevents.csv.gz",
]

REQUIRED_EICU_FILES = [
    "patient.csv.gz",
    "diagnosis.csv.gz",
    "admissionDx.csv.gz",
    "pastHistory.csv.gz",
    "lab.csv.gz",
    "medication.csv.gz",
    "treatment.csv.gz",
    "respiratoryCare.csv.gz",
    "respiratoryCharting.csv.gz",
    "nurseCharting.csv.gz",
    "vitalPeriodic.csv.gz",
    "vitalAperiodic.csv.gz",
]

PYTHON_PACKAGES = [
    "pandas",
    "numpy",
    "sklearn",
    "matplotlib",
    "seaborn",
]


def status(ok: bool) -> str:
    return "OK" if ok else "MISSING"


def file_header(path: Path) -> str:
    try:
        with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
            return handle.readline().strip()
    except Exception as exc:
        return f"HEADER_READ_FAILED: {exc}"


def check_files(root: Path, files: list[str]) -> list[tuple[str, bool, str]]:
    rows = []
    for rel in files:
        path = root / rel
        exists = path.exists()
        rows.append((rel, exists, file_header(path) if exists else ""))
    return rows


def check_packages() -> list[tuple[str, bool]]:
    return [(package, importlib.util.find_spec(package) is not None) for package in PYTHON_PACKAGES]


def print_section(title: str) -> None:
    print("")
    print(f"== {title} ==")


def main() -> int:
    print("COPD respiratory bias audit readiness check")
    print(f"Python: {sys.version.split()[0]}")
    print(f"Project root: {PROJECT_ROOT}")
    print(f"MIMIC root: {MIMIC_ROOT}")
    print(f"eICU root: {EICU_ROOT}")

    print_section("Python packages")
    package_rows = check_packages()
    for package, ok in package_rows:
        print(f"{status(ok):8} {package}")

    print_section("MIMIC-IV required files")
    mimic_rows = check_files(MIMIC_ROOT, REQUIRED_MIMIC_FILES)
    for rel, ok, header in mimic_rows:
        print(f"{status(ok):8} {rel}")
        if ok:
            print(f"         header: {header[:180]}")

    print_section("eICU required files")
    eicu_rows = check_files(EICU_ROOT, REQUIRED_EICU_FILES)
    for rel, ok, header in eicu_rows:
        print(f"{status(ok):8} {rel}")
        if ok:
            print(f"         header: {header[:180]}")

    missing_files = [rel for rel, ok, _ in mimic_rows + eicu_rows if not ok]
    missing_packages = [package for package, ok in package_rows if not ok]

    print_section("Summary")
    if missing_files:
        print("Missing files:")
        for rel in missing_files:
            print(f"- {rel}")
    else:
        print("All required starter files are present.")

    if missing_packages:
        print("Missing recommended packages:")
        for package in missing_packages:
            print(f"- {package}")
    else:
        print("All recommended Python packages are importable.")

    return 1 if missing_files else 0


if __name__ == "__main__":
    raise SystemExit(main())
