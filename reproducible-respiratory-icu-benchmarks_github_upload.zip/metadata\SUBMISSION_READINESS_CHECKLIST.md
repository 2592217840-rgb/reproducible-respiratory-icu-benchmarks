# BMC submission readiness checklist

## Repository details to add before submission

- Create a public GitHub, OSF, or Zenodo-backed repository from `public_reproducibility_package/`.
- Insert the repository URL, release tag, commit hash, and DOI if available into:
  - `statements/code_availability_statement_bmc.md`
  - `manuscript/cover_letter_bmc_mrm.md`
  - the final manuscript data/code availability section

## Repository contents

- `README.md`
- `analysis_manifest.yml`
- `requirements.txt` or `environment.yml`
- protocol files
- audit taxonomy files
- predictor provenance files
- endpoint harmonization notes
- A3c admissibility subtype table
- contextual scoping audit extraction tables
- aggregate output tables
- figure source data
- mock schemas and synthetic examples
- restricted-data exclusion statement

## Restricted materials excluded from upload

- Raw MIMIC-IV files
- Raw eICU files
- Patient-level intermediate extracts
- Patient-level feature matrices
- Patient-level predictions
- Any row-level table containing patient or ICU stay identifiers from restricted databases
