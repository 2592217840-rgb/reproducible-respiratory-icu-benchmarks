from __future__ import annotations

from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"


def round_float(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in out.columns:
        if pd.api.types.is_float_dtype(out[col]):
            out[col] = out[col].round(4)
    return out


def build_delta(metrics: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (task, cohort, model, split), group in metrics.groupby(
        ["task", "cohort_definition", "model", "split"], sort=False
    ):
        base = group[group["audit_variant"].eq("A0_clean")]
        if base.empty:
            continue
        base = base.iloc[0]
        for _, row in group.iterrows():
            rows.append(
                {
                    "task": task,
                    "cohort_definition": cohort,
                    "model": model,
                    "split": split,
                    "audit_variant": row["audit_variant"],
                    "delta_auroc_vs_A0": row["auroc"] - base["auroc"],
                    "delta_auprc_ratio_vs_A0": row["auprc_prevalence_ratio"] - base["auprc_prevalence_ratio"],
                    "delta_brier_vs_A0": row["brier"] - base["brier"],
                    "delta_calibration_slope_vs_A0": row["calibration_slope"] - base["calibration_slope"],
                }
            )
    return pd.DataFrame(rows)


def build_failure_map(metrics: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (task, cohort, model, audit), group in metrics.groupby(
        ["task", "cohort_definition", "model", "audit_variant"], sort=False
    ):
        internal = group[group["split"].eq("internal_valid")]
        external = group[group["split"].eq("external_valid")]
        if internal.empty or external.empty:
            continue
        internal = internal.iloc[0]
        external = external.iloc[0]
        gap = internal["auroc"] - external["auroc"]
        slope_dev = abs(1 - external["calibration_slope"])
        if gap < 0.08 and slope_dev < 0.5:
            phenotype = "relatively_transportable"
        elif gap >= 0.08 and slope_dev < 0.5:
            phenotype = "discrimination_optimism"
        elif gap < 0.08 and slope_dev >= 0.5:
            phenotype = "probability_failure"
        else:
            phenotype = "pseudo_performance_collapse"
        rows.append(
            {
                "task": task,
                "cohort_definition": cohort,
                "model": model,
                "audit_variant": audit,
                "internal_auroc": internal["auroc"],
                "external_auroc": external["auroc"],
                "internal_external_auroc_gap": gap,
                "external_calibration_slope": external["calibration_slope"],
                "external_calibration_slope_deviation": slope_dev,
                "external_brier": external["brier"],
                "external_ici_eavg": external["ici_eavg"],
                "failure_phenotype": phenotype,
            }
        )
    return pd.DataFrame(rows)


def main() -> int:
    logistic = pd.read_csv(TABLE_ROOT / "copd_logistic_audit_metrics.csv")
    xgb = pd.read_csv(TABLE_ROOT / "copd_xgboost_audit_metrics.csv")
    logistic["model"] = "logistic"
    xgb["model"] = "xgboost"
    combined = pd.concat([logistic, xgb], ignore_index=True, sort=False)
    combined = combined[
        combined["audit_variant"].isin(
            [
                "A0_clean",
                "A0_respiratory_extended",
                "A1_future_window_24h",
                "A1_respiratory_extended_24h",
                "A3_all_proxies",
                "A5_abg_complete_case",
                "A6_density_only",
                "A7_composite_convenience",
            ]
        )
    ].copy()
    external = combined[combined["split"].eq("external_valid")].copy()
    external_core = external[
        [
            "task",
            "cohort_definition",
            "model",
            "audit_variant",
            "n",
            "events",
            "event_rate",
            "auroc",
            "auprc_prevalence_ratio",
            "brier",
            "calibration_slope",
            "ici_eavg",
        ]
    ].sort_values(["task", "cohort_definition", "model", "audit_variant"])
    delta = build_delta(combined)
    failure = build_failure_map(combined)
    outputs = {
        "copd_model_family_external_metrics.csv": round_float(external_core),
        "copd_model_family_delta_vs_A0.csv": round_float(delta),
        "copd_model_family_failure_phenotype.csv": round_float(failure),
    }
    for name, df in outputs.items():
        df.to_csv(TABLE_ROOT / name, index=False)
        df.to_csv(MANUSCRIPT_TABLE_ROOT / name, index=False)
        print(f"Wrote {TABLE_ROOT / name}")
    print("\nModel-family external metrics, selected:")
    selected = external_core[
        external_core["cohort_definition"].isin(
            ["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"]
        )
        & external_core["audit_variant"].isin(["A0_clean", "A3_all_proxies", "A7_composite_convenience"])
    ]
    print(round_float(selected).to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
