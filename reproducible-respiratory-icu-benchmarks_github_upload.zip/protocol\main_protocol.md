# Main protocol

## Working Title

Toward reproducible respiratory ICU prediction benchmarks in COPD/AECOPD: auditing predictor admissibility, leakage, and target-population shift across MIMIC-IV and eICU.

## Rationale

COPD/AECOPD ICU prediction is sensitive to how the benchmark is specified. Cohort definitions may rely on ICD codes, discharge diagnosis, admission diagnosis strings, or treatment-defined respiratory phenotypes. Candidate predictors may include post-landmark ABG trajectories, later ventilation procedures, NIV or intubation signals, systemic steroids, antibiotics, bronchodilator orders, or acute respiratory failure codes. Respiratory measurement intensity can also carry signal because ABG ordering, SpO2 charting, respiratory-rate charting, ventilator documentation, and oxygen-flow documentation reflect both illness severity and care processes.

This study treats benchmark design choices as the exposure and model performance, calibration, decision-curve net benefit, and external validation as outcomes. The analysis compares prespecified audit variants with a 12-hour time-legal reference benchmark.

## Study Objective

To evaluate how predictor timing, predictor provenance, required-test selection, measurement density, and endpoint harmonization affect COPD/AECOPD respiratory ICU prediction benchmarks using MIMIC-IV for development and eICU-CRD for external validation.

## Primary Estimand

For each task, COPD cohort definition, model family, and validation dataset:

```text
design_delta = metric_audit_variant - metric_A0_respiratory_clean_reference
```

Positive deltas in discrimination may indicate apparent performance inflation. Calibration, Brier score, and decision-curve deltas are interpreted as reliability and utility distortion. External validation results are interpreted comparatively against A0 under the same design, not as proof that a single design mechanism causally explains all cross-database performance differences.

## Databases

- MIMIC-IV v3.1: development, internal validation, and controlled audit variants.
- eICU-CRD v2.0: external validation and transportability audit.

MIMIC-IV-ED and MIMIC-CXR are not part of this analysis.

## Population

Adult ICU stays with COPD/AECOPD-related cohort membership under at least one pre-specified cohort definition. The unit of analysis is ICU stay. The primary analysis will use the first ICU stay per hospitalization where this can be harmonized across databases.

## COPD/AECOPD Cohort Definition Audit

COPD/AECOPD cohort membership is itself an audit target. The study will construct multiple cohort definitions:

- `C0_conservative_copd`: early or baseline COPD evidence where available.
- `C1_discharge_icd_copd`: discharge/admin ICD-defined COPD/AECOPD.
- `C2_copd_acute_respiratory_failure`: COPD plus acute respiratory failure coding.
- `C3_treatment_enriched_copd`: COPD plus early respiratory treatment evidence.
- `C4_convenience_copd`: a permissive literature-style COPD/AECOPD definition.

The goal is not to claim a single perfect COPD phenotype. The goal is to show how cohort-definition choices change sample size, event rate, apparent performance, calibration, and external transportability.

The main analysis will focus on `C1_discharge_icd_copd` and
`C2_copd_acute_respiratory_failure`. `C3_treatment_enriched_copd` and
`C4_convenience_copd` are supplementary sensitivity cohorts.
They are not presented as equal primary cohorts because treatment-enriched
and permissive convenience definitions can themselves encode care pathways,
site practice, and post-hoc phenotype information.

## Main Prediction Time

Primary landmark:

- 12 hours after ICU admission.

Sensitivity landmarks:

- 6 hours after ICU admission.
- 24 hours after ICU admission.

For A0, predictors must be timestamped at or before the landmark or must represent baseline/admission-time facts plausibly available at the prediction time.

## Audit Variants

- `A0_respiratory_clean_reference`: strict landmark-aligned predictors only.
- `A1_future_respiratory_trajectory`: post-landmark 12-24h respiratory trajectory features.
- `A3a_time_ambiguous_diagnosis`: diagnosis descriptors with uncertain prediction-time availability.
- `A3b_admin_discharge_coding`: ICD, DRG, discharge diagnosis, and acute respiratory failure coding proxies.
- `A3c_treatment_procedure_proxy`: NIV, intubation, ventilation, bronchodilator, steroid, antibiotic, oxygen therapy, and respiratory therapy proxies.
- `A5_abg_complete_case_selection`: cohort restricted to complete ABG/core respiratory labs.
- `A6_respiratory_measurement_density`: explicit observation-process summaries.
- `A7_composite_convenience`: A1 + A3 + A6.

`A3c` is not treated as a uniform exclusion category. Treatment/procedure
features are separated into downstream procedure proxies, outcome-defining
respiratory support proxies, and early treatment-intensity indicators.
Pre-landmark bronchodilator, steroid, or antibiotic treatment may be clinically
admissible in some mortality settings, but it still reflects clinician judgment
and treatment intensity and should be analyzed separately from outcome-defining
respiratory support proxies such as intubation or invasive ventilation.

## Model Families

- Penalized logistic regression as the interpretable reference model.
- XGBoost as the flexible machine-learning model.
- Density-only logistic model to evaluate respiratory measurement-process transportability.

Results are reported across model families where available.

## Primary Metrics

- AUROC.
- AUPRC.
- Event rate and prevalence-referenced AUPRC ratio.
- Brier score.
- Calibration intercept.
- Calibration slope.
- Integrated calibration index / Eavg.
- Threshold-specific decision-curve net benefit.
- Internal-external AUROC gap.
- Failure phenotype map.

## Interpretation

Model performance is interpreted together with cohort definition, predictor availability, treatment/procedure proxy handling, ABG complete-case selection, measurement-density features, and endpoint harmonization.
