from __future__ import annotations

from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"


def ensure_dirs() -> None:
    TABLE_ROOT.mkdir(parents=True, exist_ok=True)
    MANUSCRIPT_TABLE_ROOT.mkdir(parents=True, exist_ok=True)


def round_cols(df: pd.DataFrame, digits: int = 4) -> pd.DataFrame:
    out = df.copy()
    for col in out.columns:
        if pd.api.types.is_float_dtype(out[col]):
            out[col] = out[col].round(digits)
    return out


def build_external_core(metrics: pd.DataFrame) -> pd.DataFrame:
    external = metrics[metrics["split"].eq("external_valid")].copy()
    cols = [
        "task",
        "cohort_definition",
        "audit_variant",
        "n",
        "events",
        "event_rate",
        "auroc",
        "auprc",
        "auprc_prevalence_ratio",
        "brier",
        "calibration_intercept",
        "calibration_slope",
        "ici_eavg",
        "mean_predicted_risk",
    ]
    return round_cols(external[cols].sort_values(["task", "cohort_definition", "audit_variant"]))


def build_failure_phenotype(metrics: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (task, cohort, audit), group in metrics.groupby(
        ["task", "cohort_definition", "audit_variant"], sort=False
    ):
        internal = group[group["split"].eq("internal_valid")]
        external = group[group["split"].eq("external_valid")]
        if internal.empty or external.empty:
            continue
        internal = internal.iloc[0]
        external = external.iloc[0]
        auroc_gap = internal["auroc"] - external["auroc"]
        slope_dev = abs(1 - external["calibration_slope"])
        if auroc_gap < 0.08 and slope_dev < 0.5:
            phenotype = "relatively_transportable"
        elif auroc_gap >= 0.08 and slope_dev < 0.5:
            phenotype = "discrimination_optimism"
        elif auroc_gap < 0.08 and slope_dev >= 0.5:
            phenotype = "probability_failure"
        else:
            phenotype = "pseudo_performance_collapse"
        rows.append(
            {
                "task": task,
                "cohort_definition": cohort,
                "audit_variant": audit,
                "internal_auroc": internal["auroc"],
                "external_auroc": external["auroc"],
                "internal_external_auroc_gap": auroc_gap,
                "external_calibration_slope": external["calibration_slope"],
                "external_calibration_slope_deviation": slope_dev,
                "external_brier": external["brier"],
                "external_ici_eavg": external["ici_eavg"],
                "failure_phenotype": phenotype,
            }
        )
    return round_cols(pd.DataFrame(rows).sort_values(["task", "cohort_definition", "audit_variant"]))


def build_dca_wide(dca: pd.DataFrame) -> pd.DataFrame:
    external = dca[dca["split"].eq("external_valid")].copy()
    external["threshold_label"] = external["threshold"].map(lambda x: f"nb_t{x:g}")
    wide = external.pivot_table(
        index=["task", "cohort_definition", "audit_variant"],
        columns="threshold_label",
        values="net_benefit_model",
        aggfunc="first",
    ).reset_index()
    treat_all = external.pivot_table(
        index=["task", "cohort_definition"],
        columns="threshold_label",
        values="net_benefit_treat_all",
        aggfunc="first",
    ).reset_index()
    treat_all.insert(2, "audit_variant", "treat_all")
    treat_none = treat_all.copy()
    for col in treat_none.columns:
        if col.startswith("nb_t"):
            treat_none[col] = 0.0
    treat_none["audit_variant"] = "treat_none"
    out = pd.concat([wide, treat_all, treat_none], ignore_index=True, sort=False)
    return round_cols(out.sort_values(["task", "cohort_definition", "audit_variant"]))


def build_headline_results(metrics: pd.DataFrame) -> pd.DataFrame:
    external = metrics[metrics["split"].eq("external_valid")].copy()
    keep = external[
        external["cohort_definition"].isin(
            ["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"]
        )
        & external["audit_variant"].isin(["A0_clean", "A1_future_window_24h", "A5_abg_complete_case", "A6_density_only"])
    ].copy()
    keep = keep[
        [
            "task",
            "cohort_definition",
            "audit_variant",
            "n",
            "events",
            "event_rate",
            "auroc",
            "auprc_prevalence_ratio",
            "brier",
            "calibration_slope",
            "ici_eavg",
        ]
    ]
    return round_cols(keep.sort_values(["task", "cohort_definition", "audit_variant"]))


def main() -> int:
    ensure_dirs()
    metrics = pd.read_csv(TABLE_ROOT / "copd_logistic_audit_metrics.csv")
    dca = pd.read_csv(TABLE_ROOT / "copd_logistic_threshold_dca.csv")

    outputs = {
        "copd_external_validation_core_metrics.csv": build_external_core(metrics),
        "copd_failure_phenotype_map.csv": build_failure_phenotype(metrics),
        "copd_external_threshold_dca_wide.csv": build_dca_wide(dca),
        "copd_headline_logistic_results.csv": build_headline_results(metrics),
    }
    for name, df in outputs.items():
        df.to_csv(TABLE_ROOT / name, index=False)
        df.to_csv(MANUSCRIPT_TABLE_ROOT / name, index=False)
        print(f"Wrote {TABLE_ROOT / name}")
    print("\nHeadline results:")
    print(outputs["copd_headline_logistic_results.csv"].to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
