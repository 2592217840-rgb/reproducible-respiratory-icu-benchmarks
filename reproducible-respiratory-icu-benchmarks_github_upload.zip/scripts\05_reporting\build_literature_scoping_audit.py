from __future__ import annotations

from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"
METADATA_ROOT = PROJECT_ROOT / "metadata"


SCOPING_AUDIT = [
    {
        "study_id": "S01_Chen_2024_ARDS",
        "short_citation": "Chen et al., 2024",
        "title": "A novel clinical prediction model for in-hospital mortality in sepsis patients complicated by ARDS: A MIMIC IV database and external validation study",
        "clinical_scope": "Sepsis with ARDS",
        "task": "In-hospital mortality",
        "database_sources": "MIMIC-IV + tertiary-hospital external validation cohort",
        "prediction_time_reported": "Partly addressed: predictors were described as collected upon ICU admission, with ICU stay <24 h excluded.",
        "predictor_window_auditable": "Partly auditable",
        "a1_future_window_risk": "Potential risk / unclear: admission-time phrasing is favorable, but the exact timestamp rule for all labs, treatments, urine output, vasoactive medications, and RRT requires replication-level audit.",
        "a3a_time_ambiguous_diagnosis_risk": "Potential risk: sepsis and ARDS cohort definitions depend on clinical diagnoses and criteria, but diagnostic descriptors are not emphasized as predictors.",
        "a3b_admin_discharge_coding_risk": "Unclear / insufficiently reported: administrative-code predictor use is not prominent, but full predictor provenance is not fully auditable from the paper alone.",
        "a3c_treatment_procedure_proxy_risk": "High-risk design feature present: vasoactive medication use and RRT appear among candidate/final predictors and can encode treatment trajectory.",
        "a5_complete_case_or_required_test_selection_risk": "High-risk design feature present: ICU stay <24 h exclusion, variables with >20% missingness removed, and external validation patients required complete information.",
        "a6_measurement_process_features_or_missingness_risk": "Potential risk: missingness-driven variable exclusion and multiple imputation are reported, but explicit measurement-density features are not reported.",
        "external_validation": "External different hospital cohort",
        "calibration_reported": "Calibration plot reported",
        "dca_or_decision_utility_reported": "DCA reported",
        "code_or_variable_dictionary_available": "Not clearly available",
        "overall_auditability": "Partly auditable",
        "benchmark_governance_note": "Shows that external validation and DCA can coexist with unresolved predictor-provenance and treatment-proxy questions.",
    },
    {
        "study_id": "S02_Fu_2024_AECOPD_IMV",
        "short_citation": "Fu et al., 2024",
        "title": "An enhanced machine learning-based prognostic prediction model for patients with AECOPD on invasive mechanical ventilation",
        "clinical_scope": "AECOPD receiving invasive mechanical ventilation",
        "task": "Prognosis / invasive mechanical ventilation outcome",
        "database_sources": "Single clinical cohort",
        "prediction_time_reported": "Unclear / insufficiently reported for benchmark reproduction: cohort is defined after IMV exposure.",
        "predictor_window_auditable": "Insufficiently auditable",
        "a1_future_window_risk": "High-risk design feature possible: the model is built among patients already receiving IMV, so timing of predictor availability relative to the prognostic decision requires careful clarification.",
        "a3a_time_ambiguous_diagnosis_risk": "Potential risk: AECOPD diagnosis and respiratory failure context are clinically defined, but time-stamped diagnosis availability is not the main focus.",
        "a3b_admin_discharge_coding_risk": "Not assessable from public-database coding rules because this is not primarily a MIMIC/eICU administrative-code study.",
        "a3c_treatment_procedure_proxy_risk": "High-risk design feature present: cohort and prediction context are defined by IMV, and treatment-path variables may be tightly coupled to outcome.",
        "a5_complete_case_or_required_test_selection_risk": "Potential risk / unclear: inclusion and exclusion criteria are reported, but complete predictor availability and missingness selection are not fully auditable from the PDF text.",
        "a6_measurement_process_features_or_missingness_risk": "Unclear / insufficiently reported: no explicit observation-density audit is reported.",
        "external_validation": "No independent public ICU external validation identified",
        "calibration_reported": "Not prominent",
        "dca_or_decision_utility_reported": "Not prominent",
        "code_or_variable_dictionary_available": "Code availability reported",
        "overall_auditability": "Insufficiently auditable",
        "benchmark_governance_note": "Useful COPD context paper, but less suitable as a public-database benchmark because landmark timing and feature provenance are difficult to reconstruct.",
    },
    {
        "study_id": "S03_Jiang_2026_AECOPD_IMV",
        "short_citation": "Jiang et al., 2026",
        "title": "Construction and validation of a machine learning-based risk prediction model for invasive mechanical ventilation in AECOPD patients complicated with respiratory failure",
        "clinical_scope": "AECOPD with respiratory failure",
        "task": "Invasive mechanical ventilation after ICU admission",
        "database_sources": "MIMIC-IV + external clinical cohort",
        "prediction_time_reported": "Partly addressed: first ICU admission, exclusion of patients already intubated at ICU admission, and first values within 24 h after ICU admission are reported.",
        "predictor_window_auditable": "Partly auditable",
        "a1_future_window_risk": "High-risk design feature present: first-24 h predictors are used for an IMV prediction task after ICU admission, so they may include outcome-proximal respiratory deterioration before the intervention.",
        "a3a_time_ambiguous_diagnosis_risk": "Potential risk: AECOPD with respiratory failure identified by ICD-9/ICD-10 codes; prospective availability at an early decision point is not the same as administrative phenotype definition.",
        "a3b_admin_discharge_coding_risk": "High-risk design feature present for cohort definition: ICD-based AECOPD/respiratory-failure identification is used.",
        "a3c_treatment_procedure_proxy_risk": "High-risk design feature present: medication records are included, and the outcome is a treatment/procedure initiation.",
        "a5_complete_case_or_required_test_selection_risk": "High-risk design feature present: ICU LOS <24 h and >5% missing key data exclusions are reported.",
        "a6_measurement_process_features_or_missingness_risk": "Potential risk: missingness thresholds and multiple imputation are reported, but explicit measurement-density variables are not audited.",
        "external_validation": "External different hospital cohort",
        "calibration_reported": "Calibration plot reported",
        "dca_or_decision_utility_reported": "DCA reported",
        "code_or_variable_dictionary_available": "Partial / not fully reproducible",
        "overall_auditability": "Partly auditable",
        "benchmark_governance_note": "Strong contextual comparator for our ventilation task because the reported first-24 h window illustrates outcome-proximal leakage risk.",
    },
    {
        "study_id": "S04_Wang_2026_ARF",
        "short_citation": "Wang et al., 2026",
        "title": "Construction and validation of a prognostic nomogram for predicting short-term mortality in acute respiratory failure patients: a retrospective cohort study based on the MIMIC-IV database",
        "clinical_scope": "Acute respiratory failure",
        "task": "Short-term mortality",
        "database_sources": "MIMIC-IV",
        "prediction_time_reported": "Partly addressed: first-24 h vital/laboratory summaries are reported.",
        "predictor_window_auditable": "Partly auditable",
        "a1_future_window_risk": "Potential risk: first-24 h predictors are legal only for a 24 h decision point and would be inadmissible for admission or 12 h landmark claims.",
        "a3a_time_ambiguous_diagnosis_risk": "Potential risk: acute respiratory failure main diagnosis is used for cohort definition.",
        "a3b_admin_discharge_coding_risk": "High-risk design feature present for cohort definition: International Classification of Diseases diagnostic codes are used.",
        "a3c_treatment_procedure_proxy_risk": "High-risk design feature present: treatment measures are included as predictors.",
        "a5_complete_case_or_required_test_selection_risk": "High-risk design feature present: variables with >20% missingness are excluded and remaining missing data are imputed.",
        "a6_measurement_process_features_or_missingness_risk": "Potential risk: missingness-driven variable selection is reported, but explicit measurement-density signals are not audited.",
        "external_validation": "Internal split validation only",
        "calibration_reported": "Calibration plot reported",
        "dca_or_decision_utility_reported": "DCA reported",
        "code_or_variable_dictionary_available": "Not clearly available",
        "overall_auditability": "Partly auditable",
        "benchmark_governance_note": "Good example of common MIMIC-only respiratory mortality modeling with calibration/DCA but without independent database transport.",
    },
    {
        "study_id": "S05_Chen_2025_Pneumonia",
        "short_citation": "Chen et al., 2025",
        "title": "Development and multi-database validation of interpretable machine learning models for predicting in-hospital mortality in pneumonia patients",
        "clinical_scope": "Pneumonia",
        "task": "In-hospital mortality",
        "database_sources": "MIMIC-IV + MIMIC-III + eICU + FAHZU",
        "prediction_time_reported": "Partly addressed: first-24 h variables and ICU LOS >=24 h are reported.",
        "predictor_window_auditable": "Partly auditable",
        "a1_future_window_risk": "Potential risk: first-24 h variables are legal for a 24 h decision point but not for an earlier landmark.",
        "a3a_time_ambiguous_diagnosis_risk": "Potential risk: pneumonia is defined using ICD codes, which does not establish prospective bedside availability.",
        "a3b_admin_discharge_coding_risk": "High-risk design feature present for cohort definition: ICD-9/ICD-10 pneumonia codes are used.",
        "a3c_treatment_procedure_proxy_risk": "Unclear / insufficiently reported: treatment proxy predictors are not the central reported feature set.",
        "a5_complete_case_or_required_test_selection_risk": "High-risk design feature present: patients with missing essential clinical data and variables with >20% missingness are excluded.",
        "a6_measurement_process_features_or_missingness_risk": "Potential risk: multiple imputation and model-specific complete-case handling are reported, without explicit measurement-process auditing.",
        "external_validation": "Multi-database external validation",
        "calibration_reported": "Not clearly reported in the main text extraction",
        "dca_or_decision_utility_reported": "DCA reported",
        "code_or_variable_dictionary_available": "Not clearly available",
        "overall_auditability": "Partly auditable",
        "benchmark_governance_note": "Strong multi-database respiratory comparator but still illustrates ICD cohort definition and missingness-selection issues.",
    },
    {
        "study_id": "S06_Zappala_2025_Weaning",
        "short_citation": "Zappala et al., 2025",
        "title": "Development and validation of a machine learning model for real-time prediction of invasive mechanical ventilation weaning readiness",
        "clinical_scope": "Invasive mechanical ventilation",
        "task": "Real-time weaning readiness",
        "database_sources": "MIMIC-IV + AmsterdamUMCdb",
        "prediction_time_reported": "Clearly addressed as a real-time/dynamic IMV weaning-readiness task using ICU admission-to-discharge data with validity windows.",
        "predictor_window_auditable": "Clearly addressed / dynamic task",
        "a1_future_window_risk": "Clearly addressed for a dynamic real-time task; not directly comparable to a fixed 12 h landmark task.",
        "a3a_time_ambiguous_diagnosis_risk": "Low / not prominent from reviewed text.",
        "a3b_admin_discharge_coding_risk": "Low / not prominent from reviewed text.",
        "a3c_treatment_procedure_proxy_risk": "Task-inherent treatment context: ventilation and weaning data are central to the target decision, so admissibility depends on real-time availability.",
        "a5_complete_case_or_required_test_selection_risk": "High-risk design feature present: IMV duration <24 h and ECMO exclusions are reported.",
        "a6_measurement_process_features_or_missingness_risk": "Potential risk: forward-validity windows for vitals, labs, and sedation scores define observation-process handling.",
        "external_validation": "External international ICU database",
        "calibration_reported": "Calibration reported",
        "dca_or_decision_utility_reported": "Not prominent",
        "code_or_variable_dictionary_available": "Partial / not fully reproducible",
        "overall_auditability": "Partly auditable",
        "benchmark_governance_note": "A useful contrast case: dynamic prediction can be temporally valid, but it should not be interpreted as fixed early landmark prediction.",
    },
    {
        "study_id": "S07_Zhang_2025_AECOPD_Mortality",
        "short_citation": "Zhang et al., 2025",
        "title": "Development and validation of a machine learning-based model to predict the risk of hospitalization death in hospitalized patients with AECOPD",
        "clinical_scope": "Hospitalized AECOPD",
        "task": "Hospitalization death",
        "database_sources": "Two tertiary hospital cohorts",
        "prediction_time_reported": "Unclear / insufficiently reported: a fixed landmark prediction time is not clearly operationalized in the extracted text.",
        "predictor_window_auditable": "Insufficiently auditable",
        "a1_future_window_risk": "Potential risk / unclear: without an explicit predictor time window, temporal admissibility cannot be fully audited.",
        "a3a_time_ambiguous_diagnosis_risk": "Potential risk: AECOPD clinical diagnosis context, but not a public administrative-code benchmark.",
        "a3b_admin_discharge_coding_risk": "Unclear / insufficiently reported.",
        "a3c_treatment_procedure_proxy_risk": "Potential risk: hospitalization predictors may include care-path features depending on extraction timing.",
        "a5_complete_case_or_required_test_selection_risk": "Potential risk: derivation/validation cohort selection is reported, but full target-population effects are not auditable from the paper alone.",
        "a6_measurement_process_features_or_missingness_risk": "Potential risk: Brier/calibration/DCA are reported, but observation-process dependence is not audited.",
        "external_validation": "No independent external validation; paper notes lack of external validation",
        "calibration_reported": "Calibration plot and Brier score reported",
        "dca_or_decision_utility_reported": "DCA reported",
        "code_or_variable_dictionary_available": "Not clearly available",
        "overall_auditability": "Insufficiently auditable",
        "benchmark_governance_note": "Supports the need for explicit landmark and predictor-window reporting in AECOPD ML studies.",
    },
    {
        "study_id": "S08_Wu_2025_COPD_Delirium",
        "short_citation": "Wu et al., 2025",
        "title": "Enhanced machine learning predictive modeling for delirium in elderly ICU patients with COPD and respiratory failure: a retrospective study based on MIMIC-IV",
        "clinical_scope": "Elderly ICU patients with COPD and respiratory failure",
        "task": "Delirium prediction",
        "database_sources": "MIMIC-IV",
        "prediction_time_reported": "Partly addressed: variables within 24 h of ICU admission are reported; delirium timing requires careful audit.",
        "predictor_window_auditable": "Partly auditable",
        "a1_future_window_risk": "High-risk design feature possible: predictors within 24 h are used for delirium in the early ICU period, and some predictors may be outcome-proximal.",
        "a3a_time_ambiguous_diagnosis_risk": "Potential risk: COPD and respiratory failure cohort definition depends on diagnostic coding/clinical phenotype.",
        "a3b_admin_discharge_coding_risk": "Potential risk: ICD-based cohort construction is likely and needs provenance audit.",
        "a3c_treatment_procedure_proxy_risk": "High-risk design feature present: mechanical ventilation and sedation are reported among important predictors.",
        "a5_complete_case_or_required_test_selection_risk": "Potential risk / unclear: missingness handling is reported but full target-population impact is not audited.",
        "a6_measurement_process_features_or_missingness_risk": "Potential risk: first-day vital/lab availability and missingness are handled, but density signals are not audited.",
        "external_validation": "MIMIC-only validation",
        "calibration_reported": "Not prominent",
        "dca_or_decision_utility_reported": "DCA reported",
        "code_or_variable_dictionary_available": "Partial / unclear",
        "overall_auditability": "Partly auditable",
        "benchmark_governance_note": "Direct COPD respiratory example where treatment proxies may dominate model explanation.",
    },
    {
        "study_id": "S09_Huang_2023_MV_AKI",
        "short_citation": "Huang et al., 2023",
        "title": "Internal and external validation of machine learning-assisted prediction models for mechanical ventilation-associated severe acute kidney injury",
        "clinical_scope": "Patients receiving invasive mechanical ventilation",
        "task": "Severe AKI after the first 12 h of mechanical ventilation",
        "database_sources": "MIMIC-IV + eICU",
        "prediction_time_reported": "Clearly addressed: information before ICU admission and during the first 12 h after MV initiation is used.",
        "predictor_window_auditable": "Clearly addressed",
        "a1_future_window_risk": "Clearly addressed for the stated 12 h MV landmark; AKI-specific label-proximal risk would arise if post-landmark creatinine features were added.",
        "a3a_time_ambiguous_diagnosis_risk": "Low / not prominent as predictor risk.",
        "a3b_admin_discharge_coding_risk": "Low / not prominent as predictor risk.",
        "a3c_treatment_procedure_proxy_risk": "Task-inherent treatment context: MV defines the risk set; ventilator parameters are time-legal within the 12 h MV window.",
        "a5_complete_case_or_required_test_selection_risk": "High-risk design feature present: adequate serum creatinine staging and sufficient data collection are required; many patients are excluded for insufficient data.",
        "a6_measurement_process_features_or_missingness_risk": "Potential risk: SCr measurement adequacy and high-missingness exclusions alter the benchmark population.",
        "external_validation": "External public ICU database",
        "calibration_reported": "Calibration slope and calibration-in-the-large reported",
        "dca_or_decision_utility_reported": "Not prominent",
        "code_or_variable_dictionary_available": "Partial / online tool reported, extraction code unclear",
        "overall_auditability": "Clearly auditable",
        "benchmark_governance_note": "A strong example of explicit landmarking and external validation, with remaining target-population risk from required creatinine data.",
    },
    {
        "study_id": "S10_Li_2024_Pneumonia",
        "short_citation": "Li et al., 2024",
        "title": "Interpretable mortality prediction model for ICU patients with pneumonia using Shapley additive explanation method",
        "clinical_scope": "ICU pneumonia",
        "task": "Hospital mortality",
        "database_sources": "eICU-CRD",
        "prediction_time_reported": "Partly addressed: first 24 h ICU admission records are used.",
        "predictor_window_auditable": "Partly auditable",
        "a1_future_window_risk": "Potential risk: first-24 h records are legal only for a 24 h decision point and not for earlier prediction claims.",
        "a3a_time_ambiguous_diagnosis_risk": "Potential risk: pneumonia filtering uses ICD-9-CM codes and database diagnosis fields.",
        "a3b_admin_discharge_coding_risk": "High-risk design feature present for cohort definition: ICD-9-CM pneumonia codes are used.",
        "a3c_treatment_procedure_proxy_risk": "Potential risk: treatment information is available in the source database, but final predictor provenance needs audit.",
        "a5_complete_case_or_required_test_selection_risk": "High-risk design feature present: short hospital stay, missing gender, and missingness-related feature exclusions are reported.",
        "a6_measurement_process_features_or_missingness_risk": "Potential risk: missing data imputation is reported, but density/frequency signals are not audited.",
        "external_validation": "Internal split validation only",
        "calibration_reported": "Not prominent",
        "dca_or_decision_utility_reported": "Not prominent",
        "code_or_variable_dictionary_available": "Not clearly available",
        "overall_auditability": "Partly auditable",
        "benchmark_governance_note": "Respiratory infection comparator showing common first-24 h and ICD-cohort patterns without independent transport validation.",
    },
    {
        "study_id": "S11_Guo_2025_COPD_Mortality",
        "short_citation": "Guo et al., 2025",
        "title": "Nomogram model of mortality risk in patients with chronic obstructive pulmonary disease in intensive care unit: based on MIMIC-IV database and external validation study",
        "clinical_scope": "ICU COPD",
        "task": "Short-term mortality",
        "database_sources": "MIMIC-IV + eICU",
        "prediction_time_reported": "Unclear / insufficiently reported: cohort and candidate predictors are described, but a fixed landmark and timestamp rule for all treatment variables are not fully auditable.",
        "predictor_window_auditable": "Insufficiently auditable",
        "a1_future_window_risk": "High-risk design feature possible: treatment variables including mechanical ventilation duration may be measured after the intended prediction time.",
        "a3a_time_ambiguous_diagnosis_risk": "Potential risk: COPD diagnosis is defined by ICD-9/ICD-10 codes.",
        "a3b_admin_discharge_coding_risk": "High-risk design feature present for cohort definition: ICD-9/ICD-10 COPD codes are used.",
        "a3c_treatment_procedure_proxy_risk": "High-risk design feature present: treatment information includes mechanical ventilation and mechanical ventilation duration.",
        "a5_complete_case_or_required_test_selection_risk": "High-risk design feature present: variables with >20% missingness are excluded.",
        "a6_measurement_process_features_or_missingness_risk": "Potential risk: missingness-driven feature exclusion and imputation are reported, but observation-process signals are not audited.",
        "external_validation": "External public ICU database",
        "calibration_reported": "Calibration plot reported",
        "dca_or_decision_utility_reported": "DCA reported",
        "code_or_variable_dictionary_available": "Not clearly available",
        "overall_auditability": "Partly auditable",
        "benchmark_governance_note": "Closest published COPD comparator; it strongly motivates our treatment-proxy and landmark-admissibility audit.",
    },
    {
        "study_id": "S12_Wang_2025_HRR_COPD",
        "short_citation": "Wang et al., 2025",
        "title": "Unveiling the prognostic power of HRR in ICU-admitted COPD patients: a MIMIC-IV database study",
        "clinical_scope": "ICU COPD",
        "task": "Hospital mortality association / prediction",
        "database_sources": "MIMIC-IV",
        "prediction_time_reported": "Partly addressed: ICU stay >24 h and laboratory data requirements are reported, but a prediction landmark is not fully operationalized.",
        "predictor_window_auditable": "Partly auditable",
        "a1_future_window_risk": "Potential risk / unclear: timing of HRR and covariates relative to prediction is not fully described as a landmark model.",
        "a3a_time_ambiguous_diagnosis_risk": "Potential risk: COPD is defined using ICD-10 code J44.9.",
        "a3b_admin_discharge_coding_risk": "High-risk design feature present for cohort definition: ICD-10 COPD code is used.",
        "a3c_treatment_procedure_proxy_risk": "High-risk design feature present in covariate adjustment: antibiotics, glucocorticoids, ventilation methods, and other treatments are considered.",
        "a5_complete_case_or_required_test_selection_risk": "High-risk design feature present: inadequate laboratory data and ICU stay <24 h are exclusion criteria.",
        "a6_measurement_process_features_or_missingness_risk": "Potential risk: indicators are omitted because of missing values; explicit density signals are not audited.",
        "external_validation": "Absent",
        "calibration_reported": "Not prominent",
        "dca_or_decision_utility_reported": "DCA reported",
        "code_or_variable_dictionary_available": "Not clearly available",
        "overall_auditability": "Partly auditable",
        "benchmark_governance_note": "COPD-specific biomarker study illustrating target-population shifts caused by required labs and ICU-duration exclusions.",
    },
]


EVIDENCE_NOTES = [
    ("S01_Chen_2024_ARDS", "Time window", "ICU stay <24 h exclusion and ICU-admission variables are reported; selected predictors include pH, urine output, vasoactive medications, and RRT.", "study_01_a_novel_clinical_prediction_model_for_in_hospita_f791e5ec.txt", "rg lines around 117-145, 287-296, 363-396"),
    ("S02_Fu_2024_AECOPD_IMV", "Code availability", "The paper reports public availability of original code, but benchmark timing remains difficult to reconstruct for a public-database audit.", "study_02_an_enhanced_machine_learning_based_prognostic_pr_c45d4c88.txt", "rg lines around 1170-1174"),
    ("S03_Jiang_2026_AECOPD_IMV", "A1/A5 risk", "Patients already intubated at ICU admission are excluded; first values within 24 h after ICU admission and >5% missing-key-data exclusion are reported.", "study_03_construction_and_validation_of_a_machine_learnin_3ef99031.txt", "rg lines around 159-194"),
    ("S04_Wang_2026_ARF", "First-24 h design", "Vital signs use first-24 h means and labs use worst values in the first 24 h after ICU admission; missingness thresholds and DCA/calibration are reported.", "study_04_construction_and_validation_of_a_prognostic_nomo_71a499bd.txt", "rg lines around 104-135, 383-384"),
    ("S05_Chen_2025_Pneumonia", "Multi-database validation", "MIMIC-IV training and MIMIC-III/eICU/FAHZU external validation are reported; cohort definition uses ICD codes and missingness exclusions.", "study_05_development_and_multi_database_validation_of_int_843128e8.txt", "rg lines around 177-237, 369-377"),
    ("S06_Zappala_2025_Weaning", "Dynamic prediction", "IMV >24 h inclusion, AmsterdamUMCdb/MIMIC-IV validation, and forward validity windows for variables are reported.", "study_06_development_and_validation_of_a_machine_learning_1f0961d2.txt", "rg lines around 43-48, 135-173"),
    ("S07_Zhang_2025_AECOPD_Mortality", "Reporting gap", "Calibration, Brier, and DCA are reported, but the paper notes lack of external validation and the fixed prediction landmark is not fully operationalized.", "study_07_development_and_validation_of_a_machine_learning_a41d0682.txt", "rg lines around 189-231, 400"),
    ("S08_Wu_2025_COPD_Delirium", "Treatment proxy", "Variables within 24 h of ICU admission are used; mechanical ventilation and sedation are among important predictors.", "study_08_enhanced_machine_learning_predictive_modeling_fo_4d85a4b7.txt", "rg lines around 158-176, 370-396"),
    ("S09_Huang_2023_MV_AKI", "Landmark and target selection", "Predictors use information before ICU admission and the first 12 h after MV; SCr data adequacy and insufficient data exclusions are reported.", "study_09_internal_and_external_validation_of_machine_lear_2e86cc88.txt", "rg lines around 21-24, 88-113, 177-182"),
    ("S10_Li_2024_Pneumonia", "ICD and missingness", "First 24 h ICU records and ICD-9-CM pneumonia filtering are reported; missing data handling and feature exclusions are described.", "study_10_interpretable_mortality_prediction_model_for_icu_b6b38b56.txt", "rg lines around 30, 95-136"),
    ("S11_Guo_2025_COPD_Mortality", "Treatment proxy", "COPD is defined using ICD-9/ICD-10 codes; candidate predictors include mechanical ventilation and mechanical ventilation duration.", "study_11_nomogram_model_of_mortality_risk_in_patients_wit_65170c98.txt", "rg lines around 150-186, 214-215, 405-409"),
    ("S12_Wang_2025_HRR_COPD", "Lab-required target shift", "COPD is defined using ICD-10 J44.9; ICU stay >24 h and inadequate laboratory data exclusions are reported; treatments are considered.", "study_12_unveiling_the_prognostic_power_of_hrr_in_icu_adm_3bc0079c.txt", "rg lines around 94-106, 414"),
]


def classify(value: str) -> str:
    value_lower = value.lower()
    if "high-risk" in value_lower:
        return "high_risk_present"
    if "unclear" in value_lower or "insufficient" in value_lower or "not assessable" in value_lower:
        return "unclear_or_insufficient"
    if "potential risk" in value_lower or "task-inherent" in value_lower:
        return "potential_or_context_dependent"
    if "clearly addressed" in value_lower or value_lower.startswith("low"):
        return "clearly_addressed_or_low"
    if "absent" in value_lower or "not prominent" in value_lower:
        return "not_prominent_or_absent"
    return "descriptive"


def build_compact(full: pd.DataFrame) -> pd.DataFrame:
    cols = [
        "study_id",
        "short_citation",
        "clinical_scope",
        "task",
        "database_sources",
        "predictor_window_auditable",
        "a1_future_window_risk",
        "a3b_admin_discharge_coding_risk",
        "a3c_treatment_procedure_proxy_risk",
        "a5_complete_case_or_required_test_selection_risk",
        "a6_measurement_process_features_or_missingness_risk",
        "external_validation",
        "calibration_reported",
        "dca_or_decision_utility_reported",
        "overall_auditability",
    ]
    return full[cols].copy()


def build_summary_counts(full: pd.DataFrame) -> pd.DataFrame:
    risk_cols = [
        "a1_future_window_risk",
        "a3a_time_ambiguous_diagnosis_risk",
        "a3b_admin_discharge_coding_risk",
        "a3c_treatment_procedure_proxy_risk",
        "a5_complete_case_or_required_test_selection_risk",
        "a6_measurement_process_features_or_missingness_risk",
    ]
    rows = []
    for col in risk_cols:
        classified = full[col].map(classify)
        counts = classified.value_counts().to_dict()
        for category, n in sorted(counts.items()):
            rows.append({"audit_domain": col, "classification": category, "n_studies": int(n)})
    external_present = full["external_validation"].str.contains("External|Multi-database", case=False, regex=True).sum()
    calibration_present = full["calibration_reported"].str.contains("Calibration", case=False, regex=True).sum()
    dca_present = full["dca_or_decision_utility_reported"].str.contains("DCA", case=False, regex=True).sum()
    rows.extend(
        [
            {"audit_domain": "external_validation", "classification": "reported_independent_or_multidatabase", "n_studies": int(external_present)},
            {"audit_domain": "calibration_reporting", "classification": "reported", "n_studies": int(calibration_present)},
            {"audit_domain": "decision_curve_reporting", "classification": "reported", "n_studies": int(dca_present)},
        ]
    )
    return pd.DataFrame(rows)


def main() -> int:
    TABLE_ROOT.mkdir(parents=True, exist_ok=True)
    MANUSCRIPT_TABLE_ROOT.mkdir(parents=True, exist_ok=True)
    full = pd.DataFrame(SCOPING_AUDIT)
    evidence = pd.DataFrame(
        EVIDENCE_NOTES,
        columns=["study_id", "evidence_domain", "evidence_summary", "source_text_file", "search_or_line_notes"],
    )
    compact = build_compact(full)
    summary = build_summary_counts(full)
    candidate = pd.read_csv(METADATA_ROOT / "scoping_literature_candidate_list.csv")
    candidate["pdf_status"] = "downloaded_and_text_extracted"

    outputs = {
        "copd_literature_scoping_audit_fulltext.csv": full,
        "copd_literature_scoping_audit_compact.csv": compact,
        "copd_literature_scoping_audit_summary_counts.csv": summary,
        "copd_literature_scoping_evidence_notes.csv": evidence,
        "copd_literature_candidate_status.csv": candidate,
    }
    for name, df in outputs.items():
        df.to_csv(TABLE_ROOT / name, index=False)
        df.to_csv(MANUSCRIPT_TABLE_ROOT / name, index=False)
        print(f"Wrote {TABLE_ROOT / name}")
    print("\nScoping audit summary counts:")
    print(summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
