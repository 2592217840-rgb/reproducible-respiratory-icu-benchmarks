from __future__ import annotations

import hashlib
import json
import platform
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
OUTPUT_TABLES = PROJECT_ROOT / "outputs" / "tables"
OUTPUT_FIGURES = PROJECT_ROOT / "outputs" / "figures"
OUTPUT_FIGURE_DATA = PROJECT_ROOT / "outputs" / "figure_data"
METADATA = PROJECT_ROOT / "metadata"
PROTOCOL = PROJECT_ROOT / "protocol"
DOCS = PROJECT_ROOT / "docs"
PUBLIC_RELEASE = PROJECT_ROOT / "public_release"
SCRIPTS = PROJECT_ROOT / "scripts"
PACKAGE = PROJECT_ROOT / "submission_package"


def ensure_dirs() -> None:
    for path in [
        PACKAGE,
        PACKAGE / "manuscript",
        PACKAGE / "tables",
        PACKAGE / "figures",
        PACKAGE / "source_data",
        PACKAGE / "supplementary",
        PACKAGE / "statements",
        PACKAGE / "freeze",
        PACKAGE / "journal_checklists",
    ]:
        path.mkdir(parents=True, exist_ok=True)


def read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path)


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.strip() + "\n", encoding="utf-8")
    print(f"Wrote {path}")


def write_csv(path: Path, df: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    print(f"Wrote {path}")


def fmt(value: float | int | str, digits: int = 3) -> str:
    if pd.isna(value):
        return "NA"
    if isinstance(value, str):
        return value
    return f"{float(value):.{digits}f}"


def pct(value: float) -> str:
    if pd.isna(value):
        return "NA"
    return f"{100 * float(value):.1f}%"


def make_table1() -> pd.DataFrame:
    mortality = read_csv(OUTPUT_TABLES / "copd_12h_cohort_definition_summary_updated.csv")
    ventilation = read_csv(OUTPUT_TABLES / "copd_12h_ventilation_outcome_summary.csv")
    mortality = mortality[mortality["cohort_definition"].isin(["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"])]
    ventilation = ventilation[ventilation["cohort_definition"].isin(["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"])]
    rows = []
    for _, row in mortality.iterrows():
        rows.append(
            {
                "task": "In-hospital mortality after 12h",
                "dataset": row["dataset"],
                "cohort": row["cohort_definition"],
                "risk_set_n": int(row["n_eligible_12h_mortality"]),
                "events": int(row["n_hospital_deaths_after_landmark"]),
                "event_rate": round(float(row["event_rate_after_landmark"]), 4),
                "early_respiratory_treatment_pct": row["early_resp_treatment_pct"],
                "invasive_ventilation_by_12h_pct": row["invasive_vent_by_12h_pct"],
            }
        )
    for _, row in ventilation.iterrows():
        rows.append(
            {
                "task": "New invasive ventilation 12-48h",
                "dataset": row["dataset"],
                "cohort": row["cohort_definition"],
                "risk_set_n": int(row["n_eligible_12h_new_invasive_vent"]),
                "events": int(row["n_new_invasive_vent_12_48h"]),
                "event_rate": round(float(row["event_rate_new_invasive_vent_12_48h"]), 4),
                "early_respiratory_treatment_pct": "",
                "invasive_ventilation_by_12h_pct": "",
            }
        )
    out = pd.DataFrame(rows)
    write_csv(PACKAGE / "tables" / "table1_cohort_and_outcome_summary.csv", out)
    return out


def make_table2() -> pd.DataFrame:
    df = read_csv(OUTPUT_TABLES / "respiratory_audit_taxonomy_expanded.csv")
    cols = [
        "audit_layer",
        "short_name",
        "definition",
        "failure_mechanism",
        "expected_metric_artifact",
        "corrective_action",
    ]
    out = df[cols].copy()
    write_csv(PACKAGE / "tables" / "table2_audit_taxonomy.csv", out)
    return out


def make_table3() -> pd.DataFrame:
    df = read_csv(OUTPUT_TABLES / "copd_model_family_external_metrics.csv")
    keep_audits = [
        "A0_clean",
        "A0_respiratory_extended",
        "A1_respiratory_extended_24h",
        "A3_all_proxies",
        "A6_density_only",
        "A7_composite_convenience",
    ]
    out = df[
        df["cohort_definition"].isin(["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"])
        & df["audit_variant"].isin(keep_audits)
    ].copy()
    cols = [
        "task",
        "cohort_definition",
        "model",
        "audit_variant",
        "n",
        "events",
        "event_rate",
        "auroc",
        "auprc_prevalence_ratio",
        "brier",
        "calibration_slope",
        "ici_eavg",
    ]
    out = out[cols].sort_values(["task", "cohort_definition", "model", "audit_variant"])
    write_csv(PACKAGE / "tables" / "table3_external_validation_metrics.csv", out)
    return out


def make_table4() -> pd.DataFrame:
    out = read_csv(OUTPUT_TABLES / "copd_key_bootstrap_auroc_delta_results.csv")
    write_csv(PACKAGE / "tables" / "table4_key_paired_bootstrap_auroc_deltas.csv", out)
    return out


def make_table5() -> pd.DataFrame:
    df = read_csv(OUTPUT_TABLES / "copd_a5_abg_target_population_shift.csv")
    out = df[
        df["cohort_definition"].isin(["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"])
        & df["variable"].isin(["task_outcome", "baseline_invasive_vent", "early_resp_treatment"])
    ].copy()
    write_csv(PACKAGE / "tables" / "table5_a5_abg_target_population_shift.csv", out)
    return out


def make_table6() -> pd.DataFrame:
    out = read_csv(OUTPUT_TABLES / "copd_literature_scoping_audit_summary_counts.csv")
    write_csv(PACKAGE / "tables" / "table6_contextual_literature_audit_summary.csv", out)
    return out


def copy_figures_and_source_data() -> None:
    for path in sorted(OUTPUT_FIGURES.glob("*.svg")):
        shutil.copy2(path, PACKAGE / "figures" / path.name)
        print(f"Copied {path.name}")
    for path in sorted(OUTPUT_FIGURE_DATA.glob("*.csv")):
        shutil.copy2(path, PACKAGE / "source_data" / path.name)
        print(f"Copied {path.name}")


def headline_values() -> dict[str, str]:
    table1 = read_csv(OUTPUT_TABLES / "copd_12h_cohort_definition_summary_updated.csv")
    vent = read_csv(OUTPUT_TABLES / "copd_12h_ventilation_outcome_summary.csv")
    metrics = read_csv(OUTPUT_TABLES / "copd_model_family_external_metrics.csv")
    boot = read_csv(OUTPUT_TABLES / "copd_key_bootstrap_auroc_delta_results.csv")
    lit = read_csv(OUTPUT_TABLES / "copd_literature_scoping_audit_summary_counts.csv")

    def metric(task: str, cohort: str, audit: str, col: str = "auroc") -> str:
        row = metrics[
            (metrics["task"] == task)
            & (metrics["cohort_definition"] == cohort)
            & (metrics["model"] == "xgboost")
            & (metrics["audit_variant"] == audit)
        ].iloc[0]
        return fmt(row[col], 4)

    def delta(task: str, cohort: str) -> str:
        row = boot[
            (boot["task"] == task)
            & (boot["cohort_definition"] == cohort)
            & (boot["audit_variant"] == "A1_respiratory_extended_24h")
        ].iloc[0]
        return f"{fmt(row['delta_estimate'], 5)} (95% CI {fmt(row['ci_lower'], 5)} to {fmt(row['ci_upper'], 5)})"

    def cohort_row(df: pd.DataFrame, dataset: str, cohort: str) -> pd.Series:
        return df[(df["dataset"] == dataset) & (df["cohort_definition"] == cohort)].iloc[0]

    m1 = cohort_row(table1, "MIMIC-IV", "c1_discharge_icd_copd")
    e1 = cohort_row(table1, "eICU", "c1_discharge_icd_copd")
    vm1 = cohort_row(vent, "MIMIC-IV", "c1_discharge_icd_copd")
    ve1 = cohort_row(vent, "eICU", "c1_discharge_icd_copd")

    return {
        "mortality_c1_mimic": f"{int(m1['n_eligible_12h_mortality'])} stays, {int(m1['n_hospital_deaths_after_landmark'])} deaths ({pct(m1['event_rate_after_landmark'])})",
        "mortality_c1_eicu": f"{int(e1['n_eligible_12h_mortality'])} stays, {int(e1['n_hospital_deaths_after_landmark'])} deaths ({pct(e1['event_rate_after_landmark'])})",
        "vent_c1_mimic": f"{int(vm1['n_eligible_12h_new_invasive_vent'])} stays, {int(vm1['n_new_invasive_vent_12_48h'])} events ({pct(vm1['event_rate_new_invasive_vent_12_48h'])})",
        "vent_c1_eicu": f"{int(ve1['n_eligible_12h_new_invasive_vent'])} stays, {int(ve1['n_new_invasive_vent_12_48h'])} events ({pct(ve1['event_rate_new_invasive_vent_12_48h'])})",
        "mort_c1_a0": metric("mortality", "c1_discharge_icd_copd", "A0_clean"),
        "mort_c1_a1resp": metric("mortality", "c1_discharge_icd_copd", "A1_respiratory_extended_24h"),
        "mort_c2_a0": metric("mortality", "c2_copd_acute_respiratory_failure", "A0_clean"),
        "mort_c2_a1resp": metric("mortality", "c2_copd_acute_respiratory_failure", "A1_respiratory_extended_24h"),
        "vent_c1_a0": metric("ventilation", "c1_discharge_icd_copd", "A0_clean"),
        "vent_c1_a1resp": metric("ventilation", "c1_discharge_icd_copd", "A1_respiratory_extended_24h"),
        "vent_c2_a0": metric("ventilation", "c2_copd_acute_respiratory_failure", "A0_clean"),
        "vent_c2_a1resp": metric("ventilation", "c2_copd_acute_respiratory_failure", "A1_respiratory_extended_24h"),
        "delta_mort_c1": delta("mortality", "c1_discharge_icd_copd"),
        "delta_mort_c2": delta("mortality", "c2_copd_acute_respiratory_failure"),
        "delta_vent_c1": delta("ventilation", "c1_discharge_icd_copd"),
        "delta_vent_c2": delta("ventilation", "c2_copd_acute_respiratory_failure"),
        "literature_high_a5": str(int(lit[(lit["audit_domain"] == "a5_complete_case_or_required_test_selection_risk") & (lit["classification"] == "high_risk_present")]["n_studies"].iloc[0])),
        "literature_high_a3c": str(int(lit[(lit["audit_domain"] == "a3c_treatment_procedure_proxy_risk") & (lit["classification"] == "high_risk_present")]["n_studies"].iloc[0])),
    }


def main_manuscript_text(v: dict[str, str]) -> str:
    return f"""
# Benchmark design bias and predictor inadmissibility in COPD/AECOPD ICU prediction models: a MIMIC-IV to eICU respiratory audit

## Abstract

### Background
Public intensive-care electronic health record benchmarks are widely used for clinical artificial intelligence research, yet apparent performance can be inflated or made clinically inadmissible by design choices that are not visible from headline discrimination metrics. COPD/AECOPD respiratory prediction tasks are especially vulnerable because cohort definitions, respiratory trajectories, treatment pathways, arterial blood gas testing, and measurement intensity are closely coupled to illness severity and downstream care.

### Methods
We developed a benchmark-governance audit framework for 12-hour landmark COPD/AECOPD ICU prediction tasks using MIMIC-IV for development and internal validation and eICU-CRD for external validation. Two tasks were evaluated: in-hospital mortality after the landmark and new invasive mechanical ventilation between 12 and 48 hours among patients not invasively ventilated by 12 hours. A time-admissible reference benchmark was compared with prespecified audit layers for future-window leakage, time-ambiguous diagnosis descriptors, administrative/discharge coding proxies, treatment/procedure proxies, ABG complete-case selection, measurement-density features, and a composite convenience benchmark. Logistic regression and XGBoost were evaluated using AUROC, prevalence-referenced AUPRC, Brier score, calibration slope, integrated calibration error, threshold-specific decision-curve net benefit, external recalibration, and 1000-resample paired bootstrap intervals.

### Results
For mortality in the broad COPD cohort, MIMIC-IV contained {v['mortality_c1_mimic']} and eICU contained {v['mortality_c1_eicu']}. For new invasive ventilation, MIMIC-IV contained {v['vent_c1_mimic']} whereas eICU contained {v['vent_c1_eicu']}, highlighting a large cross-database endpoint-prevalence difference. In XGBoost external validation, future respiratory trajectory features increased mortality AUROC from {v['mort_c1_a0']} to {v['mort_c1_a1resp']} in the broad COPD cohort and from {v['mort_c2_a0']} to {v['mort_c2_a1resp']} in the COPD plus acute respiratory failure cohort. The same audit produced much larger effects for new invasive ventilation, increasing AUROC from {v['vent_c1_a0']} to {v['vent_c1_a1resp']} in the broad cohort and from {v['vent_c2_a0']} to {v['vent_c2_a1resp']} in the severity-enriched cohort. Paired bootstrap AUROC deltas for future respiratory trajectories were {v['delta_mort_c1']} and {v['delta_mort_c2']} for the mortality cohorts, but {v['delta_vent_c1']} and {v['delta_vent_c2']} for the ventilation cohorts. ABG complete-case selection changed target populations, increasing mortality and baseline respiratory support in selected sets. In a contextual audit of 12 published COPD/AECOPD or respiratory ICU prediction benchmarks, high-risk treatment/procedure proxy features were identified in {v['literature_high_a3c']} studies and high-risk complete-case or required-test selection in {v['literature_high_a5']} studies.

### Conclusions
COPD/AECOPD ICU prediction benchmarks require explicit governance of predictor admissibility, landmark-time legality, proxy-variable provenance, complete-case target selection, measurement-process dependence, calibration, decision utility, and endpoint harmonization before model performance can be interpreted as transportable clinical prediction. External AUROC retention does not establish benchmark admissibility.

## Introduction

Public ICU databases have enabled rapid development of clinical prediction models and machine-learning benchmarks. These benchmarks are often treated as neutral tasks: a cohort is defined, predictors are extracted, a model is trained, and discrimination is compared across model families. In respiratory ICU prediction, this framing is incomplete. COPD/AECOPD tasks are shaped by diagnosis coding, respiratory support decisions, arterial blood gas testing, oxygenation documentation, medication use, and procedure records. These elements can be legitimate clinical facts in some settings, but they can also encode information unavailable at the intended decision time or generated by downstream care.

The central problem is not whether a model can achieve high AUROC. The central problem is whether the benchmark represents a valid decision-time prediction problem. A 12-hour landmark model cannot legitimately use measurements from 12 to 24 hours, discharge coding, post-landmark intubation, or outcome-proximal respiratory therapy signals as if they were baseline predictors. A model may also appear useful after complete-case filtering because the target population has silently changed to a more monitored and sicker subset. Similarly, measurement density can act as a site-dependent information channel rather than a purely biological risk signal.

We therefore designed this study as a benchmark audit rather than a conventional model-development study. The objective was to operationalize a reusable audit framework for COPD/AECOPD respiratory ICU prediction benchmarks and to quantify how specific design choices alter apparent performance, calibration, decision utility, target populations, and external transportability from MIMIC-IV to eICU.

## Methods

### Data sources
MIMIC-IV v3.1 was used for model development, internal validation, and controlled audit-variant construction. eICU-CRD v2.0 was used for external validation. Patient-level data were accessed locally under the respective data-use agreements and were not redistributed.

### Prediction tasks
The primary landmark was 12 hours after ICU admission. The first task was in-hospital mortality after the landmark among eligible COPD/AECOPD ICU stays. The second task was new invasive mechanical ventilation between 12 and 48 hours among patients alive and not invasively ventilated at or before 12 hours.

### Cohort definitions
The main manuscript focuses on two cohorts: C1, a broad discharge-ICD COPD cohort; and C2, a COPD plus acute respiratory failure cohort. Treatment-enriched and permissive convenience definitions were retained as supplementary sensitivity or stress-test cohorts because they can encode treatment pathways, site practice, and post-hoc phenotype information.

### Audit framework
A0 was the time-admissible reference benchmark. A1 added post-landmark future-window features. A3 separated time-ambiguous diagnosis descriptors, administrative/discharge coding proxies, and treatment/procedure proxies. A3c was not treated as a uniform exclusion category; early treatment-intensity indicators were separated from downstream respiratory escalation proxies and outcome-defining respiratory support proxies. A5 evaluated ABG complete-case selection as target-population shift. A6 evaluated measurement-density-only features. A7 combined future-window, proxy, and measurement-process channels as a composite convenience benchmark.

### Models and evaluation
Logistic regression and XGBoost were fitted in MIMIC-IV and externally validated in eICU without retraining. Evaluation included AUROC, prevalence-referenced AUPRC ratio, Brier score, calibration slope, integrated calibration error, and threshold-specific decision-curve net benefit. External recalibration was evaluated using intercept-only and intercept-plus-slope recalibration. Uncertainty was estimated using 1000-resample patient/stay-level bootstrap intervals, with paired bootstrap for A0-versus-audit contrasts.

### Contextual literature audit
Twelve representative COPD/AECOPD and respiratory ICU prediction benchmark studies were audited for predictor-window clarity, proxy-variable risks, complete-case or required-test selection, measurement-process features, external validation, calibration reporting, decision-curve reporting, and code or variable-dictionary availability. This audit was contextual and was not designed as a PRISMA systematic review or a prevalence estimate for the field.

## Results

### Cohorts and endpoint prevalence
The broad mortality cohort included {v['mortality_c1_mimic']} in MIMIC-IV and {v['mortality_c1_eicu']} in eICU. The broad new invasive ventilation risk set included {v['vent_c1_mimic']} in MIMIC-IV and {v['vent_c1_eicu']} in eICU. The markedly lower eICU ventilation event rate was treated as an endpoint-harmonization and transportability issue rather than a pure model-failure result.

### Future respiratory trajectories produced the strongest contamination signature
In XGBoost external validation, future respiratory trajectories increased mortality AUROC by {v['delta_mort_c1']} in C1 and {v['delta_mort_c2']} in C2. The corresponding effects for new invasive ventilation were much larger: {v['delta_vent_c1']} in C1 and {v['delta_vent_c2']} in C2. This task contrast indicates that outcome-proximal respiratory trajectories dominate apparent model performance for ventilation benchmarks.

### Measurement density carried limited but non-trivial signal
Density-only XGBoost models were weaker than time-admissible clinical models for mortality and did not consistently improve ventilation discrimination. This pattern supports the interpretation that observation-process features carry non-trivial but limited transportable signal; their main risk is confounding benchmark interpretation when mixed with clinical predictors.

### Complete-case selection changed target populations
ABG complete-case filtering selected more monitored and higher-risk patients. In the broad MIMIC-IV mortality cohort, the selected set increased mortality and baseline invasive ventilation. Similar shifts were observed in eICU. This demonstrates that complete-case filtering can change the target estimand even when discrimination does not uniformly improve.

### Composite convenience models separated performance from admissibility
The A7 composite convenience benchmark did not uniformly fail on all external metrics. In some mortality settings, it retained or improved external AUROC and probability metrics. This result does not validate the benchmark. Instead, it shows that a benchmark can be statistically performant while methodologically inadmissible because part of its performance derives from unavailable, post-hoc, outcome-proximal, or site-dependent information channels.

### Published benchmarks contained or insufficiently reported the targeted risks
The contextual literature audit identified high-risk treatment/procedure proxy features in {v['literature_high_a3c']} of 12 audited studies and high-risk complete-case or required-test selection in {v['literature_high_a5']} of 12. Ambiguous predictor windows, proxy variables, measurement-process features, and incomplete reporting of transportability were also observed or insufficiently auditable.

## Discussion

This study shows that COPD/AECOPD respiratory ICU benchmarks require a governance layer before model performance is interpreted. The strongest empirical finding was the ventilation-specific effect of future respiratory trajectories, which produced large external AUROC gains despite being unavailable at the 12-hour decision point. Mortality tasks showed more moderate contamination effects, indicating that benchmark failure signatures are task dependent.

The A3 results support a predictor-admissibility framing rather than a blacklist framing. Bronchodilators, steroids, and antibiotics may be valid early treatment information in specific designs, whereas intubation or invasive ventilation are outcome-defining or downstream respiratory support proxies for a new-ventilation task. This distinction is essential for reviewer-facing interpretation and for reproducible benchmark construction.

The A5 results reframe complete-case analysis as target-population shift. Required ABG availability selected a more monitored and higher-risk population, changing the estimand before modeling began. This is a clinical epidemiology problem as much as a machine-learning problem.

A7 provides a conceptual warning: external performance is not equivalent to decision-time validity. A benchmark can retain AUROC and even show favorable net benefit at selected thresholds while remaining inadmissible for the stated decision point. Transportability, calibration, DCA, and source provenance must be interpreted together.

### Limitations
This study used two public ICU databases and did not include international ICU datasets such as AmsterdamUMCdb or HiRID. The eICU invasive ventilation endpoint was rarer and was ascertained from different source tables than MIMIC-IV, which limits causal attribution of external failure to any single audit mechanism. The literature audit was contextual rather than systematic. DCA was reported as threshold-specific net benefit without bootstrap confidence intervals as the primary uncertainty target.

## Data availability
Patient-level MIMIC-IV and eICU-CRD data were not redistributed. They are available to credentialed users through PhysioNet under the corresponding data-use agreements. The study repository provides code, metadata, audit taxonomy files, variable dictionaries, aggregate outputs, figure source data, and synthetic mock examples.

## Code availability
The analysis code, audit configurations, reproducibility checklist, mock schemas, and aggregate outputs are prepared for public release. Restricted patient-level extracts, feature matrices, and predictions are excluded from public release.
"""


def supplementary_text() -> str:
    return """
# Supplementary Information

## Supplementary Methods

### Cohort definitions
C1 and C2 were defined as the primary analytic cohorts. C3 treatment-enriched COPD and C4 convenience COPD were retained as supplementary sensitivity or stress-test cohorts only. This separation prevents treatment-defined or permissive phenotype definitions from being interpreted as primary target populations.

### Predictor provenance
Predictor eligibility was adjudicated relative to the 12-hour landmark. Time-stamped pre-landmark values were eligible for A0. Post-landmark values, discharge/admin coding fields, time-ambiguous diagnosis descriptors, and treatment/procedure descriptors were excluded from A0 and evaluated through A1 or A3 audit layers.

### A3c task-specific admissibility
A3c variables were subtyped as early treatment-intensity indicators, downstream respiratory escalation proxies, outcome-defining respiratory support proxies, downstream procedure or diagnostic proxies, and non-respiratory treatment-escalation proxies. This classification separates potentially valid early treatment information from variables that directly encode downstream respiratory support or the target event.

### Complete-case selection
A5 ABG complete-case analyses compare full risk sets with selected sets using sample size, event rate, baseline respiratory support, early respiratory treatment, and standardized differences.

### Measurement density
A6 uses observation-process summaries rather than laboratory values themselves. These include measurement counts, missingness, variable-observation breadth, and recency.

### External recalibration
External recalibration was performed as intercept-only and intercept-plus-slope recalibration on eICU predictions. Recalibration was used to evaluate probability reliability and did not change predictor admissibility.

### Contextual literature audit
The published benchmark audit was contextual and illustrative. It was not a PRISMA systematic review and was not used to estimate the prevalence of benchmark-design risks across the field.

## Supplementary Tables
Supplementary table files are provided in `submission_package/tables` and `manuscript/tables`. The full A3 variable-level appendix, DCA tables, recalibration tables, bootstrap tables, and literature audit tables are retained as CSV files to preserve reproducibility.

## Supplementary Figures
Supplementary figure candidates include respiratory feature completeness and the published benchmark scoping audit matrix if the main text is limited to five figures.
"""


def figure_legends() -> str:
    return """
# Figure Legends

## Figure 1. Predictor admissibility audit for a 12-hour COPD/AECOPD ICU benchmark
Conceptual diagram showing the 12-hour ICU decision point, the A0 time-admissible reference feature set, future-window respiratory trajectory leakage, proxy variables, observation-process features, complete-case target selection, and the composite convenience benchmark. The figure emphasizes that decision-time admissibility is distinct from discrimination performance.

## Figure 2. Failure phenotype map across audit variants and model families
Scatter plot mapping audit variants by internal-external AUROC optimism gap and external calibration-slope deviation. Points identify relatively transportable models, discrimination optimism, probability failure, and pseudo-performance collapse signatures.

## Figure 3. Internal-external AUROC gap by task, model, and audit variant
Comparison of internal and external discrimination across mortality and ventilation tasks. The figure illustrates that higher internal performance does not necessarily correspond to stronger external reliability.

## Figure 4. ABG complete-case selection changes the benchmark target population
Comparison of full risk sets and ABG complete-case selected sets for key variables. Complete-case filtering changes sample size, event rate, baseline invasive ventilation, and early respiratory treatment.

## Figure 5. Threshold-specific decision-curve net benefit
External net benefit across clinically relevant thresholds for mortality and new invasive ventilation. Mortality and ventilation thresholds are interpreted separately because event rates differ substantially.

## Figure 6. Respiratory feature completeness across MIMIC-IV and eICU
Completeness of respiratory-specific variables in the 0-12 hour feature window. Cross-database differences in ABG and respiratory measurement availability motivate A5 and A6 audits.

## Figure 7. Contextual scoping audit of published COPD/AECOPD and respiratory ICU benchmarks
Audit matrix showing whether representative published benchmarks reported or contained design risks targeted by the framework. The audit is contextual and not a systematic review.
"""


def table_legends() -> str:
    return """
# Table Legends

## Table 1. Cohort and outcome summary
Risk-set sizes, event counts, event rates, early respiratory treatment, and baseline invasive ventilation for primary C1 and C2 mortality and ventilation tasks in MIMIC-IV and eICU.

## Table 2. Benchmark audit taxonomy
Definitions, mechanisms, expected artifacts, and corrective actions for A0-A7 audit layers.

## Table 3. External validation metrics
External AUROC, prevalence-referenced AUPRC ratio, Brier score, calibration slope, and integrated calibration error for logistic regression and XGBoost audit variants.

## Table 4. Key paired bootstrap AUROC deltas
1000-resample paired bootstrap deltas for future respiratory trajectories, density-only features, and composite convenience benchmarks relative to the corresponding reference.

## Table 5. A5 target-population shift
Full risk-set versus ABG complete-case selected-set comparisons for event rates, baseline invasive ventilation, and early respiratory treatment.

## Table 6. Contextual literature audit summary
Counts of audited studies classified by design-risk domain and reporting status.
"""


def cover_letter() -> str:
    return """
Dear Editors,

We submit the manuscript "Benchmark design bias and predictor inadmissibility in COPD/AECOPD ICU prediction models: a MIMIC-IV to eICU respiratory audit" for consideration in npj Digital Medicine.

This manuscript addresses a recurring problem in clinical AI benchmarking: apparent performance can be driven by predictors that are unavailable at the intended decision time, generated by downstream care, or dependent on local measurement processes. Rather than presenting another COPD mortality model, we develop and empirically evaluate a reusable benchmark-governance audit framework for COPD/AECOPD ICU prediction tasks.

Using MIMIC-IV for development and eICU-CRD for external validation, we evaluate mortality and new invasive ventilation tasks under prespecified audit layers for future-window leakage, proxy variables, complete-case selection, measurement-density features, and composite convenience benchmarks. The strongest empirical signature is observed in the new invasive ventilation task, where future respiratory trajectory features substantially inflate external AUROC despite being inadmissible for a 12-hour decision point. We also show that complete-case ABG selection changes the target population, and that external AUROC retention does not establish benchmark admissibility.

The manuscript is accompanied by an explicit predictor-provenance appendix, A3c treatment/procedure subtype classification, endpoint harmonization table, contextual audit of published respiratory ICU benchmarks, 1000-resample bootstrap uncertainty, figure source data, and a public-release reproducibility skeleton that excludes restricted patient-level data.

The work is original, is not under consideration elsewhere, and all authors will approve the submitted version. Patient-level MIMIC-IV and eICU-CRD data are not redistributed and remain available to credentialed users under the relevant PhysioNet data-use agreements.

Sincerely,

[Corresponding author name]
"""


def statements() -> dict[str, str]:
    return {
        "data_availability_statement.md": """
# Data Availability Statement

Patient-level MIMIC-IV and eICU-CRD data were not redistributed. MIMIC-IV v3.1 and eICU Collaborative Research Database v2.0 are available to credentialed users through PhysioNet under the corresponding data-use agreements. The study repository provides code, metadata, audit taxonomy files, variable dictionaries, aggregate result tables, figure source data, and synthetic mock examples required to reproduce the analytic workflow after local data access is obtained.
""",
        "code_availability_statement.md": """
# Code Availability Statement

The analysis code, audit configurations, cohort and predictor dictionaries, figure scripts, aggregate outputs, and public-release reproducibility skeleton are prepared for release in a public repository. Restricted patient-level extracts, feature matrices, and patient-level predictions are excluded from public release in accordance with the data-use agreements.
""",
        "ethics_and_data_use_statement.md": """
# Ethics and Data Use Statement

This study used deidentified public ICU datasets. Access to MIMIC-IV and eICU-CRD requires credentialing, completion of required human-subjects training where applicable, and agreement to the relevant PhysioNet data-use terms. No attempt was made to reidentify individuals. No patient-level data are redistributed in the accompanying materials.
""",
        "author_contributions_placeholder.md": """
# Author Contributions

[Author initials] conceived the study. [Author initials] designed the audit framework. [Author initials] performed cohort construction, feature extraction, modeling, statistical analysis, and figure generation. [Author initials] interpreted the results. [Author initials] drafted the manuscript. All authors reviewed and approved the final manuscript.
""",
        "competing_interests_placeholder.md": """
# Competing Interests

The authors declare no competing interests. Replace this placeholder if any author has a relevant financial or non-financial competing interest.
""",
    }


def checklist_text() -> str:
    return """
# Reporting and Bias-Assessment Alignment

## TRIPOD+AI alignment
The study reports the target population, prediction time, predictors, outcome definitions, model families, validation strategy, performance metrics, calibration, decision-curve analysis, uncertainty, data availability, and code availability where applicable. The manuscript is not framed as a deployable prediction model-development paper; it is a benchmark-governance audit.

## PROBAST+AI-inspired domains
Participant selection is addressed through C1/C2 primary cohort definitions and A5 target-population shift analysis. Predictor admissibility is addressed through A0-A7 taxonomy and variable-level provenance. Outcome definition and endpoint harmonization are addressed through mortality and invasive-ventilation source definitions. Analysis bias is addressed through external validation, calibration, DCA, bootstrap uncertainty, and sensitivity analyses.

## FUTURE-AI alignment
The audit framework operationalizes a pre-validation and benchmark-governance layer within the trustworthy AI lifecycle. It focuses on decision-time legality, reliability, robustness, transportability, and monitoring-relevant observation-process dependence.
"""


def hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def freeze_audit() -> None:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    run_id = "submission_freeze_20260511"
    include_roots = [
        OUTPUT_TABLES,
        OUTPUT_FIGURES,
        OUTPUT_FIGURE_DATA,
        METADATA,
        PROTOCOL,
        DOCS,
        PUBLIC_RELEASE,
        PACKAGE / "manuscript",
        PACKAGE / "tables",
        PACKAGE / "figures",
        PACKAGE / "source_data",
        PACKAGE / "supplementary",
        PACKAGE / "statements",
        PACKAGE / "journal_checklists",
    ]
    rows = []
    for root in include_roots:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if path.is_file():
                rows.append(
                    {
                        "run_id": run_id,
                        "path": str(path.relative_to(PROJECT_ROOT)),
                        "size_bytes": path.stat().st_size,
                        "sha256": hash_file(path),
                    }
                )
    checksum = pd.DataFrame(rows).sort_values("path")
    write_csv(PACKAGE / "freeze" / "output_file_checksums.csv", checksum)

    script_rows = []
    for path in SCRIPTS.rglob("*.py"):
        script_rows.append(
            {
                "run_id": run_id,
                "path": str(path.relative_to(PROJECT_ROOT)),
                "size_bytes": path.stat().st_size,
                "sha256": hash_file(path),
            }
        )
    write_csv(PACKAGE / "freeze" / "script_version_checksums.csv", pd.DataFrame(script_rows).sort_values("path"))

    env = pd.DataFrame(
        [
            {
                "run_id": run_id,
                "freeze_time_utc": now,
                "python": sys.version.replace("\n", " "),
                "platform": platform.platform(),
                "pandas": pd.__version__,
            }
        ]
    )
    write_csv(PACKAGE / "freeze" / "software_environment.csv", env)

    manifest = pd.DataFrame(
        [
            {
                "run_id": run_id,
                "freeze_time_utc": now,
                "status": "snapshot_only",
                "note": "git was not assumed available; file checksums provide the freeze record.",
            }
        ]
    )
    write_csv(PACKAGE / "freeze" / "analysis_freeze_manifest.csv", manifest)

    required = [
        PACKAGE / "manuscript" / "main_manuscript_draft.md",
        PACKAGE / "supplementary" / "supplementary_information.md",
        PACKAGE / "manuscript" / "figure_legends.md",
        PACKAGE / "manuscript" / "table_legends.md",
        PACKAGE / "tables" / "table1_cohort_and_outcome_summary.csv",
        PACKAGE / "tables" / "table2_audit_taxonomy.csv",
        PACKAGE / "tables" / "table3_external_validation_metrics.csv",
        PACKAGE / "tables" / "table4_key_paired_bootstrap_auroc_deltas.csv",
        PACKAGE / "statements" / "data_availability_statement.md",
        PACKAGE / "statements" / "code_availability_statement.md",
    ]
    audit = pd.DataFrame(
        [
            {
                "artifact": str(path.relative_to(PROJECT_ROOT)),
                "exists": path.exists(),
                "size_bytes": path.stat().st_size if path.exists() else 0,
            }
            for path in required
        ]
    )
    write_csv(PACKAGE / "freeze" / "manuscript_output_consistency_audit.csv", audit)
    flags = audit[~audit["exists"] | (audit["size_bytes"] <= 0)].copy()
    write_csv(PACKAGE / "freeze" / "manuscript_output_consistency_flags.csv", flags)


def package_manifest() -> None:
    rows = []
    for path in PACKAGE.rglob("*"):
        if path.is_file():
            rows.append(
                {
                    "path": str(path.relative_to(PACKAGE)),
                    "size_bytes": path.stat().st_size,
                    "category": path.relative_to(PACKAGE).parts[0],
                }
            )
    write_csv(PACKAGE / "submission_package_manifest.csv", pd.DataFrame(rows).sort_values("path"))


def package_readme() -> str:
    return """
# Submission Package

This folder contains a manuscript-ready working package for the COPD/AECOPD respiratory benchmark-bias audit.

## Contents

- `manuscript/`: main manuscript draft, figure legends, table legends, and cover letter.
- `tables/`: manuscript table candidates generated from aggregate analysis outputs.
- `figures/`: SVG figure files copied from the analysis output directory.
- `source_data/`: figure source-data CSV files.
- `supplementary/`: Supplementary Information draft.
- `statements/`: data availability, code availability, ethics/data-use, author contributions, and competing-interest placeholders.
- `journal_checklists/`: reporting and bias-assessment alignment notes.
- `freeze/`: checksum-based snapshot audit and manuscript output consistency audit.

## Human checks before submission

1. Replace author, affiliation, funding, and competing-interest placeholders.
2. Manually verify the 12-paper contextual literature audit classifications against PDFs.
3. Convert markdown manuscript files into the target journal format.
4. Apply journal-specific figure resolution and layout requirements.
5. Confirm all public-release files exclude patient-level data.
"""


def main() -> int:
    ensure_dirs()
    make_table1()
    make_table2()
    make_table3()
    make_table4()
    make_table5()
    make_table6()
    copy_figures_and_source_data()
    v = headline_values()

    write_text(PACKAGE / "manuscript" / "main_manuscript_draft.md", main_manuscript_text(v))
    write_text(PACKAGE / "supplementary" / "supplementary_information.md", supplementary_text())
    write_text(PACKAGE / "manuscript" / "figure_legends.md", figure_legends())
    write_text(PACKAGE / "manuscript" / "table_legends.md", table_legends())
    write_text(PACKAGE / "manuscript" / "cover_letter_npjdigitalmedicine.md", cover_letter())
    for name, content in statements().items():
        write_text(PACKAGE / "statements" / name, content)
    write_text(PACKAGE / "journal_checklists" / "tripod_probast_future_ai_alignment.md", checklist_text())
    write_text(PACKAGE / "README.md", package_readme())

    supplemental_manifest = read_csv(METADATA / "deliverables_manifest.csv")
    write_csv(PACKAGE / "supplementary" / "supplementary_table_manifest.csv", supplemental_manifest)

    freeze_audit()
    package_manifest()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
