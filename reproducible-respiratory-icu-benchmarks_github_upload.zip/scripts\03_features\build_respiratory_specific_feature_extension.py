from __future__ import annotations

import csv
import gzip
from collections import defaultdict
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_ROOT = PROJECT_ROOT.parent
MIMIC_ROOT = DATA_ROOT / "mimic-iv-3.1" / "mimic-iv-3.1"
EICU_ROOT = (
    DATA_ROOT
    / "eicu-collaborative-research-database-2.0"
    / "eicu-collaborative-research-database-2.0"
)
OUTPUT_ROOT = PROJECT_ROOT / "data_intermediate"
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"

COPD_CONTEXT_PATH = OUTPUT_ROOT / "copd_12h_backbone_with_resp_outcomes.csv.gz"
LANDMARK_MINUTES = 12 * 60
FUTURE_END_MINUTES = 24 * 60

COHORT_COLUMNS = [
    "c0_conservative_copd",
    "c1_discharge_icd_copd",
    "c2_copd_acute_respiratory_failure",
    "c3_treatment_enriched_copd",
    "c4_convenience_copd",
]

MIMIC_CHART_ITEM_MAP = {
    223834: "o2_flow",
    227287: "o2_flow",
    227582: "o2_flow",
    223835: "fio2",
    220339: "peep",
    224699: "peep",
    224700: "peep",
    224684: "tidal_volume",
    224685: "tidal_volume",
    224686: "tidal_volume",
    224688: "vent_rate",
    224689: "vent_rate",
    224690: "vent_rate",
}

MIMIC_LAB_ITEM_MAP = {
    50818: "paco2",
    50820: "ph",
    50821: "pao2",
    50817: "blood_o2_sat",
    50803: "abg_bicarbonate",
    50816: "blood_o2_content",
}

EICU_LAB_MAP = {
    "paco2": "paco2",
    "ph": "ph",
    "pao2": "pao2",
    "hco3": "abg_bicarbonate",
    "fio2": "fio2",
    "lpm o2": "o2_flow",
    "o2 sat (%)": "blood_o2_sat",
}

EICU_RESP_CHART_MAP = {
    "fio2": "fio2",
    "lpm o2": "o2_flow",
    "peep": "peep",
    "vent rate": "vent_rate",
}

RESP_FEATURES = [
    "fio2",
    "o2_flow",
    "peep",
    "vent_rate",
    "tidal_volume",
    "paco2",
    "ph",
    "pao2",
    "blood_o2_sat",
    "abg_bicarbonate",
    "blood_o2_content",
]


def clean_value(feature: str, value: object) -> float | None:
    try:
        val = float(value)
    except (TypeError, ValueError):
        return None
    if pd.isna(val):
        return None
    if feature == "fio2":
        if 0.2 <= val <= 1.0:
            return val * 100
        if 20 <= val <= 100:
            return val
        return None
    ranges = {
        "o2_flow": (0, 80),
        "peep": (0, 40),
        "vent_rate": (0, 80),
        "tidal_volume": (50, 1500),
        "paco2": (5, 200),
        "ph": (6.5, 8.0),
        "pao2": (20, 700),
        "blood_o2_sat": (40, 100),
        "abg_bicarbonate": (2, 60),
        "blood_o2_content": (0, 100),
    }
    low, high = ranges.get(feature, (-float("inf"), float("inf")))
    if low <= val <= high:
        return val
    return None


class Agg:
    def __init__(self) -> None:
        self.state: dict[tuple[str, str, str], dict[str, float]] = {}

    def add(self, rows: pd.DataFrame) -> None:
        if rows.empty:
            return
        rows = rows.dropna(subset=["icu_stay_id", "feature", "value", "offset_minutes", "window"]).copy()
        if rows.empty:
            return
        grouped = (
            rows.groupby(["icu_stay_id", "feature", "window"], sort=False)
            .agg(
                count=("value", "size"),
                total=("value", "sum"),
                minimum=("value", "min"),
                maximum=("value", "max"),
                last_time=("offset_minutes", "max"),
            )
            .reset_index()
        )
        latest = (
            rows.sort_values(["icu_stay_id", "feature", "window", "offset_minutes"])
            .groupby(["icu_stay_id", "feature", "window"], sort=False)
            .tail(1)[["icu_stay_id", "feature", "window", "value"]]
            .rename(columns={"value": "last"})
        )
        grouped = grouped.merge(latest, on=["icu_stay_id", "feature", "window"], how="left")
        for row in grouped.itertuples(index=False):
            key = (str(row.icu_stay_id), str(row.feature), str(row.window))
            existing = self.state.get(key)
            if existing is None:
                self.state[key] = {
                    "count": float(row.count),
                    "total": float(row.total),
                    "minimum": float(row.minimum),
                    "maximum": float(row.maximum),
                    "last_time": float(row.last_time),
                    "last": float(row.last),
                }
            else:
                existing["count"] += float(row.count)
                existing["total"] += float(row.total)
                existing["minimum"] = min(existing["minimum"], float(row.minimum))
                existing["maximum"] = max(existing["maximum"], float(row.maximum))
                if float(row.last_time) >= existing["last_time"]:
                    existing["last_time"] = float(row.last_time)
                    existing["last"] = float(row.last)

    def to_wide(self, ids: pd.DataFrame) -> pd.DataFrame:
        out = ids[["dataset", "icu_stay_id"]].drop_duplicates().copy()
        for window in ["resp0", "resp1"]:
            for feature in RESP_FEATURES:
                for stat in ["mean", "min", "max", "last"]:
                    out[f"{window}_{feature}_{stat}"] = pd.NA
                out[f"{window}_{feature}_count"] = 0
                out[f"{window}_{feature}_missing"] = 1
        index = {(row.dataset, str(row.icu_stay_id)): i for i, row in out.reset_index(drop=True).iterrows()}
        out = out.reset_index(drop=True)
        for (stay_id, feature, window), stats in self.state.items():
            rows = out.index[out["icu_stay_id"].astype(str).eq(stay_id)]
            if len(rows) == 0:
                continue
            i = int(rows[0])
            count = stats["count"]
            out.at[i, f"{window}_{feature}_mean"] = stats["total"] / count
            out.at[i, f"{window}_{feature}_min"] = stats["minimum"]
            out.at[i, f"{window}_{feature}_max"] = stats["maximum"]
            out.at[i, f"{window}_{feature}_last"] = stats["last"]
            out.at[i, f"{window}_{feature}_count"] = int(count)
            out.at[i, f"{window}_{feature}_missing"] = 0
        return out


def load_context() -> pd.DataFrame:
    df = pd.read_csv(COPD_CONTEXT_PATH, compression="gzip", low_memory=False)
    for col in ["icu_admit_time", "landmark_time"]:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    df["icu_stay_id"] = df["icu_stay_id"].astype(str)
    df["hospital_admission_id"] = df["hospital_admission_id"].astype(str)
    target = df[COHORT_COLUMNS].any(axis=1) & (
        df["eligible_12h_mortality"] | df["eligible_12h_new_invasive_vent"]
    )
    return df[target].copy()


def window_from_offset(offset: pd.Series) -> pd.Series:
    return pd.Series(
        pd.NA,
        index=offset.index,
        dtype="object",
    ).mask(offset.between(0, LANDMARK_MINUTES, inclusive="both"), "resp0").mask(
        offset.gt(LANDMARK_MINUTES) & offset.le(FUTURE_END_MINUTES), "resp1"
    )


def add_mimic_chart(ctx: pd.DataFrame, agg: Agg) -> None:
    mimic = ctx[ctx["dataset"].eq("MIMIC-IV")][["icu_stay_id", "icu_admit_time"]].drop_duplicates()
    mimic["stay_id"] = pd.to_numeric(mimic["icu_stay_id"], errors="coerce").astype("Int64")
    mimic = mimic.dropna(subset=["stay_id"])
    stay_ids = set(mimic["stay_id"].astype(int))
    itemids = set(MIMIC_CHART_ITEM_MAP)
    for chunk in pd.read_csv(
        MIMIC_ROOT / "icu" / "chartevents.csv.gz",
        compression="gzip",
        usecols=["stay_id", "charttime", "itemid", "valuenum"],
        chunksize=1_000_000,
        low_memory=False,
    ):
        chunk = chunk[chunk["stay_id"].isin(stay_ids) & chunk["itemid"].isin(itemids)].copy()
        if chunk.empty:
            continue
        chunk = chunk.merge(mimic, on="stay_id", how="inner")
        chunk["charttime"] = pd.to_datetime(chunk["charttime"], errors="coerce")
        chunk["offset_minutes"] = (chunk["charttime"] - chunk["icu_admit_time"]).dt.total_seconds() / 60
        chunk["window"] = window_from_offset(chunk["offset_minutes"])
        chunk = chunk.dropna(subset=["window"])
        if chunk.empty:
            continue
        chunk["feature"] = chunk["itemid"].map(MIMIC_CHART_ITEM_MAP)
        chunk["value"] = [
            clean_value(feature, value)
            for feature, value in zip(chunk["feature"], chunk["valuenum"])
        ]
        agg.add(chunk[["icu_stay_id", "feature", "value", "offset_minutes", "window"]])


def add_mimic_labs(ctx: pd.DataFrame, agg: Agg) -> None:
    mimic = ctx[ctx["dataset"].eq("MIMIC-IV")][["hospital_admission_id", "icu_stay_id", "icu_admit_time"]].drop_duplicates()
    mimic["hadm_id"] = pd.to_numeric(mimic["hospital_admission_id"], errors="coerce").astype("Int64")
    mimic = mimic.dropna(subset=["hadm_id"])
    hadm_ids = set(mimic["hadm_id"].astype(int))
    itemids = set(MIMIC_LAB_ITEM_MAP)
    for chunk in pd.read_csv(
        MIMIC_ROOT / "hosp" / "labevents.csv.gz",
        compression="gzip",
        usecols=["hadm_id", "charttime", "itemid", "valuenum"],
        chunksize=1_000_000,
        low_memory=False,
    ):
        chunk = chunk[chunk["hadm_id"].isin(hadm_ids) & chunk["itemid"].isin(itemids)].copy()
        if chunk.empty:
            continue
        chunk = chunk.merge(mimic, on="hadm_id", how="inner")
        chunk["charttime"] = pd.to_datetime(chunk["charttime"], errors="coerce")
        chunk["offset_minutes"] = (chunk["charttime"] - chunk["icu_admit_time"]).dt.total_seconds() / 60
        chunk["window"] = window_from_offset(chunk["offset_minutes"])
        chunk = chunk.dropna(subset=["window"])
        if chunk.empty:
            continue
        chunk["feature"] = chunk["itemid"].map(MIMIC_LAB_ITEM_MAP)
        chunk["value"] = [
            clean_value(feature, value)
            for feature, value in zip(chunk["feature"], chunk["valuenum"])
        ]
        agg.add(chunk[["icu_stay_id", "feature", "value", "offset_minutes", "window"]])


def add_eicu_labs(ctx: pd.DataFrame, agg: Agg) -> None:
    eicu = ctx[ctx["dataset"].eq("eICU")][["icu_stay_id"]].drop_duplicates()
    ids = set(pd.to_numeric(eicu["icu_stay_id"], errors="coerce").dropna().astype(int))
    labs = set(EICU_LAB_MAP)
    for chunk in pd.read_csv(
        EICU_ROOT / "lab.csv.gz",
        compression="gzip",
        usecols=["patientunitstayid", "labresultoffset", "labname", "labresult"],
        chunksize=1_000_000,
        low_memory=False,
    ):
        chunk["labname_norm"] = chunk["labname"].fillna("").str.strip().str.lower()
        chunk = chunk[
            chunk["patientunitstayid"].isin(ids)
            & chunk["labname_norm"].isin(labs)
            & chunk["labresultoffset"].between(0, FUTURE_END_MINUTES, inclusive="both")
        ].copy()
        if chunk.empty:
            continue
        chunk["icu_stay_id"] = chunk["patientunitstayid"].astype(str)
        chunk["offset_minutes"] = pd.to_numeric(chunk["labresultoffset"], errors="coerce")
        chunk["window"] = window_from_offset(chunk["offset_minutes"])
        chunk["feature"] = chunk["labname_norm"].map(EICU_LAB_MAP)
        chunk["value"] = [
            clean_value(feature, value)
            for feature, value in zip(chunk["feature"], chunk["labresult"])
        ]
        agg.add(chunk[["icu_stay_id", "feature", "value", "offset_minutes", "window"]])


def add_eicu_resp_chart(ctx: pd.DataFrame, agg: Agg) -> None:
    ids = set(ctx[ctx["dataset"].eq("eICU")]["icu_stay_id"].astype(str))
    labels = set(EICU_RESP_CHART_MAP)
    rows = []
    with gzip.open(EICU_ROOT / "respiratoryCharting.csv.gz", "rt", encoding="utf-8", errors="replace", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            stay_id = str(row.get("patientunitstayid", ""))
            if stay_id not in ids:
                continue
            label = (row.get("respchartvaluelabel", "") or "").strip().lower()
            if label not in labels:
                continue
            try:
                offset = float(row.get("respchartoffset", ""))
            except (TypeError, ValueError):
                continue
            if offset < 0 or offset > FUTURE_END_MINUTES:
                continue
            feature = EICU_RESP_CHART_MAP[label]
            value = clean_value(feature, row.get("respchartvalue", ""))
            if value is None:
                continue
            rows.append(
                {
                    "icu_stay_id": stay_id,
                    "feature": feature,
                    "value": value,
                    "offset_minutes": offset,
                    "window": "resp0" if offset <= LANDMARK_MINUTES else "resp1",
                }
            )
    if rows:
        agg.add(pd.DataFrame(rows))


def merge_extension(task: str, base_variant: str, out_variant: str, extension: pd.DataFrame, include_future: bool) -> None:
    in_path = OUTPUT_ROOT / f"copd_{'mortality_12h' if task == 'mortality' else 'new_invasive_ventilation_12h'}_{base_variant}_features.csv.gz"
    out_path = OUTPUT_ROOT / f"copd_{'mortality_12h' if task == 'mortality' else 'new_invasive_ventilation_12h'}_{out_variant}_features.csv.gz"
    base = pd.read_csv(in_path, compression="gzip", low_memory=False, dtype={"icu_stay_id": str})
    cols = ["dataset", "icu_stay_id"] + [col for col in extension.columns if col.startswith("resp0_")]
    if include_future:
        cols += [col for col in extension.columns if col.startswith("resp1_")]
    merged = base.merge(extension[cols], on=["dataset", "icu_stay_id"], how="left")
    for col in [c for c in merged.columns if c.startswith(("resp0_", "resp1_")) and c.endswith(("_count", "_missing"))]:
        merged[col] = merged[col].fillna(0 if col.endswith("_count") else 1).astype(int)
    merged.to_csv(out_path, index=False, compression="gzip")


def summarize(extension: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for dataset, group in extension.groupby("dataset"):
        for feature in RESP_FEATURES:
            for window in ["resp0", "resp1"]:
                col = f"{window}_{feature}_count"
                rows.append(
                    {
                        "dataset": dataset,
                        "window": window,
                        "feature": feature,
                        "n_observed": int(group[col].fillna(0).gt(0).sum()) if col in group else 0,
                        "observed_pct": round(float(group[col].fillna(0).gt(0).mean()) * 100, 2) if col in group else 0,
                        "median_count": round(float(group[col].fillna(0).median()), 2) if col in group else 0,
                    }
                )
    return pd.DataFrame(rows)


def main() -> int:
    ctx = load_context()
    agg = Agg()
    print("Extracting MIMIC respiratory chart features")
    add_mimic_chart(ctx, agg)
    print("Extracting MIMIC ABG lab features")
    add_mimic_labs(ctx, agg)
    print("Extracting eICU ABG/resp lab features")
    add_eicu_labs(ctx, agg)
    print("Extracting eICU respiratory chart features")
    add_eicu_resp_chart(ctx, agg)
    extension = agg.to_wide(ctx[["dataset", "icu_stay_id"]])
    ext_path = OUTPUT_ROOT / "copd_respiratory_specific_feature_extension.csv.gz"
    extension.to_csv(ext_path, index=False, compression="gzip")
    summary = summarize(extension)
    summary.to_csv(TABLE_ROOT / "copd_respiratory_specific_feature_completeness.csv", index=False)
    summary.to_csv(MANUSCRIPT_TABLE_ROOT / "copd_respiratory_specific_feature_completeness.csv", index=False)
    for task in ["mortality", "ventilation"]:
        merge_extension(task, "A0_clean", "A0_respiratory_extended", extension, include_future=False)
        merge_extension(task, "A1_future_window_24h", "A1_respiratory_extended_24h", extension, include_future=True)
    print(f"Wrote {ext_path}")
    print(summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
