# Mock Data

The CSV files in this folder are synthetic examples for testing schemas and
documentation. They are not derived from MIMIC-IV, eICU-CRD, or any real
patient-level record.

Use these files only to demonstrate expected column names and data types.
