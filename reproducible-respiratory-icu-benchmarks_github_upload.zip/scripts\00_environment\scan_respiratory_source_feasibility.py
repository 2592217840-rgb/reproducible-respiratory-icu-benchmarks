from __future__ import annotations

import csv
import gzip
import re
from collections import defaultdict
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
MIMIC_ROOT = (PROJECT_ROOT / "../mimic-iv-3.1/mimic-iv-3.1").resolve()
EICU_ROOT = (
    PROJECT_ROOT
    / "../eicu-collaborative-research-database-2.0/eicu-collaborative-research-database-2.0"
).resolve()
OUTPUT_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"


COPD_ICD9_PREFIXES = ("490", "491", "492", "496")
COPD_ICD10_PREFIXES = ("J40", "J41", "J42", "J43", "J44")
ACUTE_RESP_FAILURE_ICD9_PREFIXES = ("51881", "51882", "51884")
ACUTE_RESP_FAILURE_ICD10_PREFIXES = ("J96",)

COPD_TEXT_RE = re.compile(
    r"\b(copd|chronic obstructive|emphysema|chronic bronchitis|aecopd)\b",
    flags=re.IGNORECASE,
)
RESP_FAILURE_TEXT_RE = re.compile(
    r"\b(respiratory failure|acute respiratory failure|hypercapnic|hypoxemic)\b",
    flags=re.IGNORECASE,
)
RESP_TREATMENT_TEXT_RE = re.compile(
    r"\b(ventilat|intubat|extubat|bipap|cpap|non[- ]?invasive|niv|oxygen|bronchodilator|albuterol|ipratropium|steroid|prednisone|methylpred|antibiotic)\b",
    flags=re.IGNORECASE,
)


def norm_code(code: str) -> str:
    return code.strip().upper().replace(".", "")


def is_code_match(code: str, version: str, icd9_prefixes: tuple[str, ...], icd10_prefixes: tuple[str, ...]) -> bool:
    code_norm = norm_code(code)
    if str(version).strip() == "10":
        return code_norm.startswith(icd10_prefixes)
    return code_norm.startswith(icd9_prefixes)


def gzip_header(path: Path) -> list[str]:
    with gzip.open(path, "rt", encoding="utf-8", errors="replace", newline="") as handle:
        return next(csv.reader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    pd.DataFrame(rows).to_csv(path, index=False)


def mimic_icd_counts() -> list[dict]:
    path = MIMIC_ROOT / "hosp" / "diagnoses_icd.csv.gz"
    hadm_copd: set[str] = set()
    subj_copd: set[str] = set()
    hadm_resp_failure: set[str] = set()
    row_counts = defaultdict(int)
    with gzip.open(path, "rt", encoding="utf-8", errors="replace", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            row_counts["rows"] += 1
            code = row["icd_code"]
            version = row["icd_version"]
            if is_code_match(code, version, COPD_ICD9_PREFIXES, COPD_ICD10_PREFIXES):
                row_counts["copd_rows"] += 1
                hadm_copd.add(row["hadm_id"])
                subj_copd.add(row["subject_id"])
            if is_code_match(code, version, ACUTE_RESP_FAILURE_ICD9_PREFIXES, ACUTE_RESP_FAILURE_ICD10_PREFIXES):
                row_counts["acute_resp_failure_rows"] += 1
                hadm_resp_failure.add(row["hadm_id"])
    return [
        {
            "database": "MIMIC-IV",
            "source_table": "hosp/diagnoses_icd",
            "signal": "COPD ICD diagnosis",
            "rows_matching": row_counts["copd_rows"],
            "unique_subjects": len(subj_copd),
            "unique_encounters": len(hadm_copd),
        },
        {
            "database": "MIMIC-IV",
            "source_table": "hosp/diagnoses_icd",
            "signal": "acute respiratory failure ICD diagnosis",
            "rows_matching": row_counts["acute_resp_failure_rows"],
            "unique_subjects": "",
            "unique_encounters": len(hadm_resp_failure),
        },
    ]


def eicu_text_table_counts(filename: str, text_columns: list[str], id_column: str, patterns: dict[str, re.Pattern]) -> list[dict]:
    path = EICU_ROOT / filename
    rows = []
    matched_ids: dict[str, set[str]] = {name: set() for name in patterns}
    counts = defaultdict(int)
    with gzip.open(path, "rt", encoding="utf-8", errors="replace", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            counts["rows"] += 1
            text = " | ".join(row.get(col, "") for col in text_columns)
            for name, pattern in patterns.items():
                if pattern.search(text):
                    counts[name] += 1
                    matched_ids[name].add(row.get(id_column, ""))
    for name in patterns:
        rows.append(
            {
                "database": "eICU",
                "source_table": filename.replace(".csv.gz", ""),
                "signal": name,
                "rows_matching": counts[name],
                "unique_subjects": "",
                "unique_encounters": len(matched_ids[name]),
            }
        )
    return rows


def eicu_icd_counts() -> list[dict]:
    path = EICU_ROOT / "diagnosis.csv.gz"
    counts = defaultdict(int)
    copd_ids: set[str] = set()
    resp_failure_ids: set[str] = set()
    with gzip.open(path, "rt", encoding="utf-8", errors="replace", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            counts["rows"] += 1
            text = " | ".join([row.get("diagnosisstring", ""), row.get("icd9code", "")])
            if COPD_TEXT_RE.search(text) or any(norm_code(part).startswith(COPD_ICD9_PREFIXES) for part in text.split(",")):
                counts["copd"] += 1
                copd_ids.add(row["patientunitstayid"])
            if RESP_FAILURE_TEXT_RE.search(text):
                counts["resp_failure"] += 1
                resp_failure_ids.add(row["patientunitstayid"])
    return [
        {
            "database": "eICU",
            "source_table": "diagnosis",
            "signal": "COPD diagnosis string or ICD",
            "rows_matching": counts["copd"],
            "unique_subjects": "",
            "unique_encounters": len(copd_ids),
        },
        {
            "database": "eICU",
            "source_table": "diagnosis",
            "signal": "acute respiratory failure string",
            "rows_matching": counts["resp_failure"],
            "unique_subjects": "",
            "unique_encounters": len(resp_failure_ids),
        },
    ]


def header_inventory() -> list[dict]:
    files = [
        ("MIMIC-IV", MIMIC_ROOT / "hosp" / "diagnoses_icd.csv.gz"),
        ("MIMIC-IV", MIMIC_ROOT / "hosp" / "drgcodes.csv.gz"),
        ("MIMIC-IV", MIMIC_ROOT / "hosp" / "prescriptions.csv.gz"),
        ("MIMIC-IV", MIMIC_ROOT / "hosp" / "labevents.csv.gz"),
        ("MIMIC-IV", MIMIC_ROOT / "icu" / "chartevents.csv.gz"),
        ("MIMIC-IV", MIMIC_ROOT / "icu" / "inputevents.csv.gz"),
        ("MIMIC-IV", MIMIC_ROOT / "icu" / "procedureevents.csv.gz"),
        ("eICU", EICU_ROOT / "diagnosis.csv.gz"),
        ("eICU", EICU_ROOT / "admissionDx.csv.gz"),
        ("eICU", EICU_ROOT / "pastHistory.csv.gz"),
        ("eICU", EICU_ROOT / "lab.csv.gz"),
        ("eICU", EICU_ROOT / "medication.csv.gz"),
        ("eICU", EICU_ROOT / "treatment.csv.gz"),
        ("eICU", EICU_ROOT / "respiratoryCare.csv.gz"),
        ("eICU", EICU_ROOT / "respiratoryCharting.csv.gz"),
    ]
    rows = []
    for database, path in files:
        rows.append(
            {
                "database": database,
                "source_file": str(path.relative_to(MIMIC_ROOT if database == "MIMIC-IV" else EICU_ROOT)),
                "exists": path.exists(),
                "header": " | ".join(gzip_header(path)) if path.exists() else "",
            }
        )
    return rows


def main() -> int:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    MANUSCRIPT_TABLE_ROOT.mkdir(parents=True, exist_ok=True)

    count_rows = []
    count_rows.extend(mimic_icd_counts())
    count_rows.extend(eicu_icd_counts())
    count_rows.extend(
        eicu_text_table_counts(
            "admissionDx.csv.gz",
            ["admitdxpath", "admitdxname", "admitdxtext"],
            "patientunitstayid",
            {
                "COPD admission diagnosis text": COPD_TEXT_RE,
                "acute respiratory failure admission diagnosis text": RESP_FAILURE_TEXT_RE,
            },
        )
    )
    count_rows.extend(
        eicu_text_table_counts(
            "pastHistory.csv.gz",
            ["pasthistorypath", "pasthistoryvalue", "pasthistoryvaluetext"],
            "patientunitstayid",
            {"COPD past history text": COPD_TEXT_RE},
        )
    )
    count_rows.extend(
        eicu_text_table_counts(
            "treatment.csv.gz",
            ["treatmentstring"],
            "patientunitstayid",
            {"respiratory treatment proxy text": RESP_TREATMENT_TEXT_RE},
        )
    )
    count_rows.extend(
        eicu_text_table_counts(
            "respiratoryCharting.csv.gz",
            ["respcharttypecat", "respchartvaluelabel", "respchartvalue"],
            "patientunitstayid",
            {"respiratory charting signal": RESP_TREATMENT_TEXT_RE},
        )
    )

    header_rows = header_inventory()
    feasibility_rows = [
        {
            "check": "MIMIC COPD ICD source",
            "status": "available",
            "note": "diagnoses_icd supports C1/C2 administrative COPD and acute respiratory failure definitions.",
        },
        {
            "check": "eICU COPD diagnosis sources",
            "status": "available",
            "note": "diagnosis, admissionDx, and pastHistory support C0/C1/C3-style COPD definitions with offset review.",
        },
        {
            "check": "eICU respiratory treatment sources",
            "status": "available",
            "note": "respiratoryCare, respiratoryCharting, treatment, and medication support A3c and ventilation outcome mapping.",
        },
        {
            "check": "MIMIC respiratory treatment sources",
            "status": "available",
            "note": "procedureevents, inputevents, chartevents, d_items, and prescriptions support treatment/procedure proxy mapping.",
        },
        {
            "check": "Main feasibility conclusion",
            "status": "ready_for_cohort_build",
            "note": "MIMIC-IV plus eICU are sufficient for the first COPD/AECOPD respiratory benchmark audit.",
        },
    ]

    write_csv(OUTPUT_ROOT / "copd_source_keyword_counts.csv", count_rows)
    write_csv(OUTPUT_ROOT / "respiratory_source_header_inventory.csv", header_rows)
    write_csv(OUTPUT_ROOT / "source_feasibility_summary.csv", feasibility_rows)

    for name in [
        "copd_cohort_definition_taxonomy.csv",
        "respiratory_audit_taxonomy.csv",
        "predictor_provenance_availability_table.csv",
        "a3_proxy_classification_rules.csv",
        "a6_respiratory_measurement_density_definitions.csv",
    ]:
        source = PROJECT_ROOT / "metadata" / name
        target = MANUSCRIPT_TABLE_ROOT / name
        target.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")

    print("Wrote COPD respiratory source feasibility outputs.")
    print(pd.DataFrame(feasibility_rows).to_string(index=False))
    print(pd.DataFrame(count_rows).to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
