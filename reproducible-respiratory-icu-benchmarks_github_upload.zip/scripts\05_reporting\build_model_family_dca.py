from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
INTERMEDIATE_ROOT = PROJECT_ROOT / "data_intermediate"
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"

DCA_THRESHOLDS = {
    "mortality": [0.05, 0.10, 0.15, 0.20, 0.30],
    "ventilation": [0.005, 0.01, 0.02, 0.05, 0.10],
}

KEEP_COHORTS = {
    "c1_discharge_icd_copd",
    "c2_copd_acute_respiratory_failure",
}
KNOWN_COHORTS = [
    "c1_discharge_icd_copd",
    "c2_copd_acute_respiratory_failure",
    "c4_convenience_copd",
]
KEEP_AUDITS = {
    "A0_clean",
    "A0_respiratory_extended",
    "A1_future_window_24h",
    "A1_respiratory_extended_24h",
    "A3_all_proxies",
    "A5_abg_complete_case",
    "A6_density_only",
    "A7_composite_convenience",
}


def parse_prediction_path(path: Path) -> tuple[str, str, str, str]:
    stem = path.name.replace("_predictions.csv.gz", "")
    match = re.match(r"copd_(mortality|ventilation)_(.+)_(logistic|xgboost)$", stem)
    if not match:
        raise ValueError(f"Unexpected prediction file name: {path.name}")
    task = match.group(1)
    rest = match.group(2)
    model = match.group(3)
    cohort = next((value for value in KNOWN_COHORTS if rest.startswith(f"{value}_")), None)
    if cohort is None:
        raise ValueError(f"Could not parse cohort from prediction file name: {path.name}")
    audit = rest[len(cohort) + 1 :]
    return task, cohort, audit, model


def net_benefit(y: np.ndarray, pred: np.ndarray, threshold: float) -> float:
    treated = pred >= threshold
    tp = int(((y == 1) & treated).sum())
    fp = int(((y == 0) & treated).sum())
    n = len(y)
    return float(tp / n - fp / n * threshold / (1 - threshold))


def evaluate_file(path: Path) -> list[dict[str, object]]:
    task, cohort, audit, model = parse_prediction_path(path)
    if cohort not in KEEP_COHORTS or audit not in KEEP_AUDITS:
        return []
    df = pd.read_csv(path, compression="gzip", low_memory=False)
    df = df[df["split"].eq("external_valid")].copy()
    y = df["hospital_mortality"].astype(int).to_numpy()
    pred = df["predicted_risk"].astype(float).to_numpy()
    event_rate = float(np.mean(y))
    rows = []
    for threshold in DCA_THRESHOLDS[task]:
        rows.append(
            {
                "task": task,
                "cohort_definition": cohort,
                "model": model,
                "audit_variant": audit,
                "threshold": threshold,
                "n": int(len(y)),
                "events": int(y.sum()),
                "event_rate": event_rate,
                "net_benefit_model": net_benefit(y, pred, threshold),
                "net_benefit_treat_all": event_rate - (1 - event_rate) * threshold / (1 - threshold),
                "net_benefit_treat_none": 0.0,
            }
        )
    return rows


def build_wide(dca: pd.DataFrame) -> pd.DataFrame:
    dca = dca.copy()
    dca["threshold_label"] = dca["threshold"].map(lambda x: f"nb_t{x:g}")
    wide = dca.pivot_table(
        index=["task", "cohort_definition", "model", "audit_variant", "n", "events", "event_rate"],
        columns="threshold_label",
        values="net_benefit_model",
        aggfunc="first",
    ).reset_index()

    treat_all = dca.pivot_table(
        index=["task", "cohort_definition"],
        columns="threshold_label",
        values="net_benefit_treat_all",
        aggfunc="first",
    ).reset_index()
    treat_all.insert(2, "model", "reference")
    treat_all.insert(3, "audit_variant", "treat_all")
    treat_all.insert(4, "n", np.nan)
    treat_all.insert(5, "events", np.nan)
    treat_all.insert(6, "event_rate", np.nan)

    treat_none = treat_all.copy()
    treat_none["audit_variant"] = "treat_none"
    for col in treat_none.columns:
        if col.startswith("nb_t"):
            treat_none[col] = 0.0

    out = pd.concat([wide, treat_all, treat_none], ignore_index=True, sort=False)
    for col in out.columns:
        if pd.api.types.is_float_dtype(out[col]):
            out[col] = out[col].round(5)
    return out.sort_values(["task", "cohort_definition", "model", "audit_variant"])


def main() -> int:
    rows: list[dict[str, object]] = []
    for path in sorted(INTERMEDIATE_ROOT.glob("copd_*_predictions.csv.gz")):
        rows.extend(evaluate_file(path))
    dca = pd.DataFrame(rows)
    wide = build_wide(dca)
    outputs = {
        "copd_model_family_external_dca_long.csv": dca,
        "copd_model_family_external_dca_wide.csv": wide,
    }
    for name, df in outputs.items():
        df.to_csv(TABLE_ROOT / name, index=False)
        df.to_csv(MANUSCRIPT_TABLE_ROOT / name, index=False)
        print(f"Wrote {TABLE_ROOT / name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
