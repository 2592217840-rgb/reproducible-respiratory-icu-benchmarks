# Restricted-data boundary

This repository excludes restricted patient-level materials.

## Excluded materials

- Raw MIMIC-IV database files.
- Raw eICU Collaborative Research Database files.
- Patient-level cohort extracts.
- Patient-level feature matrices.
- Patient-level model predictions.
- Patient-level bootstrap samples.
- Row-level intermediate files derived from restricted ICU databases.

## Included materials

- Code for local reruns after credentialed data access.
- Protocol and task specifications.
- Audit taxonomy and predictor-provenance files.
- Aggregate model-performance outputs.
- Figure source data without patient-level rows.
- Synthetic schemas and examples.
- Contextual literature-audit extraction sheets.

The public files can be used to inspect the analysis design and aggregate results. Patient-level regeneration requires local access to MIMIC-IV and eICU under their data-use agreements.
