from __future__ import annotations

import csv
import gzip
import re
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_ROOT = PROJECT_ROOT.parent
MIMIC_ROOT = DATA_ROOT / "mimic-iv-3.1" / "mimic-iv-3.1"
EICU_ROOT = (
    DATA_ROOT
    / "eicu-collaborative-research-database-2.0"
    / "eicu-collaborative-research-database-2.0"
)

INPUT_PATH = PROJECT_ROOT / "data_intermediate" / "copd_12h_backbone_with_resp_outcomes.csv.gz"
OUTPUT_ROOT = PROJECT_ROOT / "data_intermediate"
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"

LANDMARK_HOURS = 12
FUTURE_END_HOURS = 24
LANDMARK_MINUTES = LANDMARK_HOURS * 60
FUTURE_END_MINUTES = FUTURE_END_HOURS * 60

COHORT_COLUMNS = [
    "c0_conservative_copd",
    "c1_discharge_icd_copd",
    "c2_copd_acute_respiratory_failure",
    "c3_treatment_enriched_copd",
    "c4_convenience_copd",
]

TASK_COLUMNS = [
    "eligible_12h_mortality",
    "hospital_mortality",
    "eligible_12h_new_invasive_vent",
    "new_invasive_vent_12_48h",
]

MIMIC_CHART_ITEM_MAP = {
    220045: "heart_rate",
    220210: "resp_rate",
    220277: "spo2",
    220052: "map",
    220181: "map",
    223761: "temperature_f",
    223762: "temperature_c",
    223834: "o2_flow",
    223835: "fio2",
}

MIMIC_LAB_ITEM_MAP = {
    50818: "paco2",
    50820: "ph",
    50821: "pao2",
    50803: "bicarbonate",
    50882: "bicarbonate",
    50912: "creatinine",
    51006: "bun",
    51301: "wbc",
    51222: "hemoglobin",
    50813: "lactate",
    52442: "lactate",
    50817: "blood_o2_sat",
    50816: "blood_o2_content",
}

EICU_VITAL_MAP = {
    "temperature": "temperature_c",
    "sao2": "spo2",
    "heartrate": "heart_rate",
    "respiration": "resp_rate",
    "systemicmean": "map",
}

EICU_VITAL_APERIODIC_MAP = {
    "noninvasivemean": "map",
}

EICU_LAB_MAP = {
    "paco2": "paco2",
    "ph": "ph",
    "pao2": "pao2",
    "hco3": "bicarbonate",
    "bicarbonate": "bicarbonate",
    "creatinine": "creatinine",
    "bun": "bun",
    "wbc x 1000": "wbc",
    "hgb": "hemoglobin",
    "lactate": "lactate",
    "o2 sat (%)": "blood_o2_sat",
    "fio2": "fio2",
    "lpm o2": "o2_flow",
}

EICU_RESP_CHART_MAP = {
    "fio2": "fio2",
    "lpm o2": "o2_flow",
    "peep": "peep",
    "vent rate": "vent_rate",
}

BASE_FEATURES = [
    "heart_rate",
    "resp_rate",
    "spo2",
    "map",
    "temperature_c",
    "o2_flow",
    "fio2",
    "paco2",
    "ph",
    "pao2",
    "bicarbonate",
    "creatinine",
    "bun",
    "wbc",
    "hemoglobin",
    "lactate",
    "blood_o2_sat",
    "peep",
    "vent_rate",
]

ABG_FEATURES = ["paco2", "ph", "pao2"]


@dataclass
class FeatureEvent:
    stay_id: str
    feature: str
    value: float
    offset_hours: float
    source: str


def ensure_dirs() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    TABLE_ROOT.mkdir(parents=True, exist_ok=True)
    MANUSCRIPT_TABLE_ROOT.mkdir(parents=True, exist_ok=True)


def read_input() -> pd.DataFrame:
    df = pd.read_csv(INPUT_PATH, compression="gzip", low_memory=False)
    for col in ["icu_admit_time", "landmark_time", "icu_discharge_time"]:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    df["icu_stay_id"] = df["icu_stay_id"].astype(str)
    df["hospital_admission_id"] = df["hospital_admission_id"].astype(str)
    for col in COHORT_COLUMNS:
        df[col] = df[col].fillna(False).astype(bool)
    target_cohort = df[COHORT_COLUMNS].any(axis=1)
    target_task = df["eligible_12h_mortality"] | df["eligible_12h_new_invasive_vent"]
    return df[target_cohort & target_task].copy()


def clean_value(feature: str, value: object) -> float | None:
    try:
        val = float(value)
    except (TypeError, ValueError):
        return None
    if pd.isna(val):
        return None

    if feature == "temperature_f":
        if 80 <= val <= 110:
            return (val - 32) * 5 / 9
        return None
    if feature == "temperature_c":
        if 25 <= val <= 45:
            return val
        return None
    if feature == "heart_rate" and 20 <= val <= 250:
        return val
    if feature == "resp_rate" and 3 <= val <= 80:
        return val
    if feature in {"spo2", "blood_o2_sat"} and 40 <= val <= 100:
        return val
    if feature == "map" and 20 <= val <= 250:
        return val
    if feature == "fio2":
        if 0.20 <= val <= 1.0:
            return val * 100
        if 20 <= val <= 100:
            return val
        return None
    if feature == "o2_flow" and 0 <= val <= 80:
        return val
    if feature == "paco2" and 5 <= val <= 200:
        return val
    if feature == "pao2" and 20 <= val <= 700:
        return val
    if feature == "ph" and 6.5 <= val <= 8.0:
        return val
    if feature == "bicarbonate" and 2 <= val <= 60:
        return val
    if feature == "creatinine" and 0.05 <= val <= 30:
        return val
    if feature == "bun" and 1 <= val <= 250:
        return val
    if feature == "wbc" and 0.1 <= val <= 300:
        return val
    if feature == "hemoglobin" and 2 <= val <= 25:
        return val
    if feature == "lactate" and 0.1 <= val <= 30:
        return val
    if feature == "peep" and 0 <= val <= 40:
        return val
    if feature == "vent_rate" and 0 <= val <= 80:
        return val
    return None


def make_empty_feature_frame(stay_ids: Iterable[str]) -> pd.DataFrame:
    frame = pd.DataFrame({"icu_stay_id": sorted(set(stay_ids))})
    return frame


def aggregate_events(events: list[FeatureEvent], stay_ids: Iterable[str], prefix: str) -> pd.DataFrame:
    rows: dict[tuple[str, str], list[tuple[float, float, str]]] = defaultdict(list)
    for event in events:
        rows[(event.stay_id, event.feature)].append(
            (event.offset_hours, event.value, event.source)
        )

    out = make_empty_feature_frame(stay_ids)
    feature_records: dict[str, list[dict]] = defaultdict(list)
    for (stay_id, feature), values in rows.items():
        values_sorted = sorted(values, key=lambda item: item[0])
        numeric_values = [item[1] for item in values_sorted]
        last_offset, last_value, _ = values_sorted[-1]
        feature_records[feature].append(
            {
                "icu_stay_id": stay_id,
                f"{prefix}_{feature}_mean": sum(numeric_values) / len(numeric_values),
                f"{prefix}_{feature}_last": last_value,
                f"{prefix}_{feature}_min": min(numeric_values),
                f"{prefix}_{feature}_max": max(numeric_values),
                f"{prefix}_{feature}_count": len(numeric_values),
                f"{prefix}_{feature}_hours_since_last": max(0.0, LANDMARK_HOURS - last_offset)
                if prefix == "a0"
                else None,
            }
        )
    for feature in sorted(feature_records):
        subset = pd.DataFrame(feature_records[feature])
        out = out.merge(subset, on="icu_stay_id", how="left")
    return out


def summarize_presence(events: list[FeatureEvent], stay_ids: Iterable[str], prefix: str) -> pd.DataFrame:
    base = make_empty_feature_frame(stay_ids)
    if not events:
        base[f"{prefix}_total_measurement_count"] = 0
        base[f"{prefix}_unique_features_observed"] = 0
        return base
    df = pd.DataFrame(
        {
            "icu_stay_id": [event.stay_id for event in events],
            "feature": [event.feature for event in events],
            "source": [event.source for event in events],
        }
    )
    density = (
        df.groupby("icu_stay_id")
        .agg(
            **{
                f"{prefix}_total_measurement_count": ("feature", "size"),
                f"{prefix}_unique_features_observed": ("feature", "nunique"),
                f"{prefix}_lab_measurement_count": (
                    "source",
                    lambda x: int((x == "lab").sum()),
                ),
                f"{prefix}_vital_measurement_count": (
                    "source",
                    lambda x: int((x == "vital").sum()),
                ),
                f"{prefix}_resp_measurement_count": (
                    "source",
                    lambda x: int((x == "resp").sum()),
                ),
            }
        )
        .reset_index()
    )
    out = base.merge(density, on="icu_stay_id", how="left")
    density_cols = [col for col in out.columns if col != "icu_stay_id"]
    out[density_cols] = out[density_cols].fillna(0).astype(int)
    return out


def mimic_chart_events(mimic_base: pd.DataFrame) -> tuple[list[FeatureEvent], list[FeatureEvent]]:
    stay_info = mimic_base[["icu_stay_id", "icu_admit_time"]].drop_duplicates()
    stay_ids = set(stay_info["icu_stay_id"])
    admit_times = dict(zip(stay_info["icu_stay_id"], stay_info["icu_admit_time"]))
    a0_events: list[FeatureEvent] = []
    a1_events: list[FeatureEvent] = []

    for chunk in pd.read_csv(
        MIMIC_ROOT / "icu" / "chartevents.csv.gz",
        compression="gzip",
        usecols=["stay_id", "charttime", "itemid", "valuenum"],
        parse_dates=["charttime"],
        chunksize=1_000_000,
    ):
        chunk = chunk[chunk["itemid"].isin(MIMIC_CHART_ITEM_MAP)].copy()
        if chunk.empty:
            continue
        chunk["icu_stay_id"] = chunk["stay_id"].astype(str)
        chunk = chunk[chunk["icu_stay_id"].isin(stay_ids)]
        if chunk.empty:
            continue
        for row in chunk.itertuples(index=False):
            stay_id = str(row.icu_stay_id)
            admit = admit_times.get(stay_id)
            if pd.isna(admit) or pd.isna(row.charttime):
                continue
            offset = (row.charttime - admit).total_seconds() / 3600
            if offset < 0 or offset > FUTURE_END_HOURS:
                continue
            feature = MIMIC_CHART_ITEM_MAP.get(int(row.itemid))
            value = clean_value(feature, row.valuenum)
            if value is None:
                continue
            if feature == "temperature_f":
                feature = "temperature_c"
            event = FeatureEvent(stay_id, feature, value, offset, "vital")
            if offset <= LANDMARK_HOURS:
                a0_events.append(event)
            elif offset <= FUTURE_END_HOURS:
                a1_events.append(event)
    return a0_events, a1_events


def mimic_lab_events(mimic_base: pd.DataFrame) -> tuple[list[FeatureEvent], list[FeatureEvent]]:
    lookup = mimic_base[
        ["hospital_admission_id", "icu_stay_id", "icu_admit_time"]
    ].drop_duplicates()
    hadm_ids = set(lookup["hospital_admission_id"])
    lookup_by_hadm = {
        row.hospital_admission_id: (row.icu_stay_id, row.icu_admit_time)
        for row in lookup.itertuples(index=False)
    }
    a0_events: list[FeatureEvent] = []
    a1_events: list[FeatureEvent] = []

    for chunk in pd.read_csv(
        MIMIC_ROOT / "hosp" / "labevents.csv.gz",
        compression="gzip",
        usecols=["hadm_id", "charttime", "itemid", "valuenum"],
        parse_dates=["charttime"],
        chunksize=1_000_000,
    ):
        chunk = chunk[chunk["itemid"].isin(MIMIC_LAB_ITEM_MAP)].copy()
        if chunk.empty:
            continue
        chunk["hospital_admission_id"] = chunk["hadm_id"].astype(str)
        chunk = chunk[chunk["hospital_admission_id"].isin(hadm_ids)]
        if chunk.empty:
            continue
        for row in chunk.itertuples(index=False):
            lookup_value = lookup_by_hadm.get(str(row.hospital_admission_id))
            if lookup_value is None or pd.isna(row.charttime):
                continue
            stay_id, admit = lookup_value
            offset = (row.charttime - admit).total_seconds() / 3600
            if offset < 0 or offset > FUTURE_END_HOURS:
                continue
            feature = MIMIC_LAB_ITEM_MAP.get(int(row.itemid))
            value = clean_value(feature, row.valuenum)
            if value is None:
                continue
            event = FeatureEvent(stay_id, feature, value, offset, "lab")
            if offset <= LANDMARK_HOURS:
                a0_events.append(event)
            elif offset <= FUTURE_END_HOURS:
                a1_events.append(event)
    return a0_events, a1_events


def eicu_vital_events(eicu_base: pd.DataFrame) -> tuple[list[FeatureEvent], list[FeatureEvent]]:
    stay_ids = set(eicu_base["icu_stay_id"])
    a0_events: list[FeatureEvent] = []
    a1_events: list[FeatureEvent] = []

    for path, offset_col, mapping, source in [
        (
            EICU_ROOT / "vitalPeriodic.csv.gz",
            "observationoffset",
            EICU_VITAL_MAP,
            "vital",
        ),
        (
            EICU_ROOT / "vitalAperiodic.csv.gz",
            "observationoffset",
            EICU_VITAL_APERIODIC_MAP,
            "vital",
        ),
    ]:
        usecols = ["patientunitstayid", offset_col] + list(mapping.keys())
        for chunk in pd.read_csv(
            path,
            compression="gzip",
            usecols=usecols,
            chunksize=1_000_000,
        ):
            chunk["icu_stay_id"] = chunk["patientunitstayid"].astype(str)
            chunk = chunk[chunk["icu_stay_id"].isin(stay_ids)]
            if chunk.empty:
                continue
            for row in chunk.itertuples(index=False):
                offset_minutes = getattr(row, offset_col)
                try:
                    offset = float(offset_minutes) / 60
                except (TypeError, ValueError):
                    continue
                if offset < 0 or offset > FUTURE_END_HOURS:
                    continue
                stay_id = str(row.icu_stay_id)
                for col, feature in mapping.items():
                    value = clean_value(feature, getattr(row, col))
                    if value is None:
                        continue
                    event = FeatureEvent(stay_id, feature, value, offset, source)
                    if offset <= LANDMARK_HOURS:
                        a0_events.append(event)
                    else:
                        a1_events.append(event)
    return a0_events, a1_events


def eicu_lab_events(eicu_base: pd.DataFrame) -> tuple[list[FeatureEvent], list[FeatureEvent]]:
    stay_ids = set(eicu_base["icu_stay_id"])
    a0_events: list[FeatureEvent] = []
    a1_events: list[FeatureEvent] = []
    lab_names = set(EICU_LAB_MAP)
    for chunk in pd.read_csv(
        EICU_ROOT / "lab.csv.gz",
        compression="gzip",
        usecols=["patientunitstayid", "labresultoffset", "labname", "labresult"],
        chunksize=1_000_000,
    ):
        chunk["icu_stay_id"] = chunk["patientunitstayid"].astype(str)
        chunk = chunk[chunk["icu_stay_id"].isin(stay_ids)]
        if chunk.empty:
            continue
        chunk["labname_norm"] = chunk["labname"].fillna("").str.strip().str.lower()
        chunk = chunk[chunk["labname_norm"].isin(lab_names)]
        if chunk.empty:
            continue
        for row in chunk.itertuples(index=False):
            try:
                offset = float(row.labresultoffset) / 60
            except (TypeError, ValueError):
                continue
            if offset < 0 or offset > FUTURE_END_HOURS:
                continue
            feature = EICU_LAB_MAP.get(str(row.labname_norm))
            value = clean_value(feature, row.labresult)
            if value is None:
                continue
            event = FeatureEvent(str(row.icu_stay_id), feature, value, offset, "lab")
            if offset <= LANDMARK_HOURS:
                a0_events.append(event)
            else:
                a1_events.append(event)
    return a0_events, a1_events


def eicu_resp_chart_events(eicu_base: pd.DataFrame) -> tuple[list[FeatureEvent], list[FeatureEvent]]:
    stay_ids = set(eicu_base["icu_stay_id"])
    a0_events: list[FeatureEvent] = []
    a1_events: list[FeatureEvent] = []
    labels = set(EICU_RESP_CHART_MAP)
    with gzip.open(
        EICU_ROOT / "respiratoryCharting.csv.gz",
        "rt",
        encoding="utf-8",
        errors="replace",
        newline="",
    ) as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            stay_id = str(row.get("patientunitstayid", ""))
            if stay_id not in stay_ids:
                continue
            label = (row.get("respchartvaluelabel", "") or "").strip().lower()
            if label not in labels:
                continue
            try:
                offset = float(row.get("respchartoffset", "")) / 60
            except (TypeError, ValueError):
                continue
            if offset < 0 or offset > FUTURE_END_HOURS:
                continue
            feature = EICU_RESP_CHART_MAP[label]
            value = clean_value(feature, row.get("respchartvalue", ""))
            if value is None:
                continue
            event = FeatureEvent(stay_id, feature, value, offset, "resp")
            if offset <= LANDMARK_HOURS:
                a0_events.append(event)
            else:
                a1_events.append(event)
    return a0_events, a1_events


def combine_feature_sets(base: pd.DataFrame, a0_events: list[FeatureEvent], a1_events: list[FeatureEvent]) -> pd.DataFrame:
    stay_ids = base["icu_stay_id"]
    a0_values = aggregate_events(a0_events, stay_ids, "a0")
    a1_values = aggregate_events(a1_events, stay_ids, "a1")
    a0_density = summarize_presence(a0_events, stay_ids, "a0")
    a1_density = summarize_presence(a1_events, stay_ids, "a1")

    out = base.merge(a0_values, on="icu_stay_id", how="left")
    out = out.merge(a1_values, on="icu_stay_id", how="left")
    out = out.merge(a0_density, on="icu_stay_id", how="left")
    out = out.merge(a1_density, on="icu_stay_id", how="left")

    for feature in BASE_FEATURES:
        observed_col = f"a0_{feature}_observed"
        count_col = f"a0_{feature}_count"
        out[observed_col] = out[count_col].fillna(0).gt(0) if count_col in out else False
    out["a0_abg_complete"] = out[[f"a0_{f}_observed" for f in ABG_FEATURES]].all(axis=1)
    out["a0_missing_feature_count"] = (
        len(BASE_FEATURES)
        - out[[f"a0_{feature}_observed" for feature in BASE_FEATURES]].sum(axis=1)
    )
    return out


def build_model_ready() -> pd.DataFrame:
    df = read_input()
    mimic_base = df[df["dataset"] == "MIMIC-IV"].copy()
    eicu_base = df[df["dataset"] == "eICU"].copy()

    mimic_chart_a0, mimic_chart_a1 = mimic_chart_events(mimic_base)
    mimic_lab_a0, mimic_lab_a1 = mimic_lab_events(mimic_base)
    eicu_vital_a0, eicu_vital_a1 = eicu_vital_events(eicu_base)
    eicu_lab_a0, eicu_lab_a1 = eicu_lab_events(eicu_base)
    eicu_resp_a0, eicu_resp_a1 = eicu_resp_chart_events(eicu_base)

    mimic_events_a0 = mimic_chart_a0 + mimic_lab_a0
    mimic_events_a1 = mimic_chart_a1 + mimic_lab_a1
    eicu_events_a0 = eicu_vital_a0 + eicu_lab_a0 + eicu_resp_a0
    eicu_events_a1 = eicu_vital_a1 + eicu_lab_a1 + eicu_resp_a1

    mimic_out = combine_feature_sets(mimic_base, mimic_events_a0, mimic_events_a1)
    eicu_out = combine_feature_sets(eicu_base, eicu_events_a0, eicu_events_a1)
    out = pd.concat([mimic_out, eicu_out], ignore_index=True, sort=False)

    density_cols = [
        col
        for col in out.columns
        if col.endswith("_measurement_count") or col.endswith("_unique_features_observed")
    ]
    out[density_cols] = out[density_cols].fillna(0).astype(int)
    return out


def summarize_model_ready(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for dataset, group in df.groupby("dataset", sort=False):
        for cohort in ["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure", "c4_convenience_copd"]:
            subset = group[group[cohort]]
            mortality = subset[subset["eligible_12h_mortality"]]
            vent = subset[subset["eligible_12h_new_invasive_vent"]]
            rows.append(
                {
                    "dataset": dataset,
                    "cohort_definition": cohort,
                    "n_mortality_risk_set": len(mortality),
                    "mortality_event_rate": round(
                        float(pd.to_numeric(mortality["hospital_mortality"], errors="coerce").mean()),
                        6,
                    )
                    if len(mortality)
                    else None,
                    "n_ventilation_risk_set": len(vent),
                    "ventilation_event_rate": round(float(vent["new_invasive_vent_12_48h"].mean()), 6)
                    if len(vent)
                    else None,
                    "a0_abg_complete_pct_mortality": round(float(mortality["a0_abg_complete"].mean()) * 100, 2)
                    if len(mortality)
                    else None,
                    "median_a0_total_measurement_count_mortality": round(
                        float(mortality["a0_total_measurement_count"].median()), 2
                    )
                    if len(mortality)
                    else None,
                    "median_a0_unique_features_observed_mortality": round(
                        float(mortality["a0_unique_features_observed"].median()), 2
                    )
                    if len(mortality)
                    else None,
                }
            )
    return pd.DataFrame(rows)


def summarize_feature_missingness(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    eligible = df[df["eligible_12h_mortality"] & df["c1_discharge_icd_copd"]].copy()
    for dataset, group in eligible.groupby("dataset", sort=False):
        for feature in BASE_FEATURES:
            obs_col = f"a0_{feature}_observed"
            rows.append(
                {
                    "dataset": dataset,
                    "cohort_definition": "c1_discharge_icd_copd",
                    "feature": feature,
                    "a0_observed_pct": round(float(group[obs_col].mean()) * 100, 2)
                    if obs_col in group
                    else 0.0,
                    "a0_nonmissing_n": int(group[obs_col].sum()) if obs_col in group else 0,
                    "risk_set_n": len(group),
                }
            )
    return pd.DataFrame(rows)


def write_feature_inventory() -> None:
    rows = []
    for feature in BASE_FEATURES:
        rows.append(
            {
                "feature": feature,
                "a0_columns": f"a0_{feature}_mean/last/min/max/count",
                "a1_columns": f"a1_{feature}_mean/last/min/max/count",
                "audit_role": "A0 time-legal value; A1 future-window stress test",
            }
        )
    rows.extend(
        [
            {
                "feature": "a0_abg_complete",
                "a0_columns": "a0_abg_complete",
                "a1_columns": "",
                "audit_role": "A5 ABG complete-case selection flag",
            },
            {
                "feature": "measurement_density",
                "a0_columns": "a0_total/lab/vital/resp_measurement_count; a0_unique_features_observed; a0_missing_feature_count",
                "a1_columns": "a1_total/lab/vital/resp_measurement_count; a1_unique_features_observed",
                "audit_role": "A6 observation-process feature set",
            },
        ]
    )
    pd.DataFrame(rows).to_csv(
        TABLE_ROOT / "model_ready_feature_inventory.csv",
        index=False,
    )
    pd.DataFrame(rows).to_csv(
        MANUSCRIPT_TABLE_ROOT / "model_ready_feature_inventory.csv",
        index=False,
    )


def main() -> int:
    ensure_dirs()
    model_ready = build_model_ready()
    out_path = OUTPUT_ROOT / "copd_12h_model_ready_respiratory_features.csv.gz"
    model_ready.to_csv(out_path, index=False, compression="gzip")

    summary = summarize_model_ready(model_ready)
    summary.to_csv(TABLE_ROOT / "model_ready_risk_set_feature_summary.csv", index=False)
    summary.to_csv(
        MANUSCRIPT_TABLE_ROOT / "model_ready_risk_set_feature_summary.csv",
        index=False,
    )

    missingness = summarize_feature_missingness(model_ready)
    missingness.to_csv(TABLE_ROOT / "a0_feature_missingness_c1_mortality.csv", index=False)
    write_feature_inventory()

    print(f"Wrote {out_path}")
    print("\nRisk set and feature summary:")
    print(summary.to_string(index=False))
    print("\nA0 feature missingness in C1 mortality risk set:")
    print(missingness.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
