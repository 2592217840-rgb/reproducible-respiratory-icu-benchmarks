from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / ".pydeps"))

import numpy as np
import pandas as pd
import xgboost as xgb


PROJECT_ROOT = Path(__file__).resolve().parents[2]
INTERMEDIATE_ROOT = PROJECT_ROOT / "data_intermediate"
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MODEL_ROOT = PROJECT_ROOT / "outputs" / "models"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"

SEED = 20260426
TRAIN_FRACTION = 0.70

COHORTS = [
    "c1_discharge_icd_copd",
    "c2_copd_acute_respiratory_failure",
    "c4_convenience_copd",
]

AUDITS = [
    "A0_clean",
    "A0_respiratory_extended",
    "A1_future_window_24h",
    "A1_respiratory_extended_24h",
    "A3_all_proxies",
    "A6_density_only",
    "A7_composite_convenience",
]

MATRIX_PATHS = {
    ("mortality", "A0_clean"): INTERMEDIATE_ROOT / "copd_mortality_12h_A0_clean_features.csv.gz",
    ("mortality", "A1_future_window_24h"): INTERMEDIATE_ROOT / "copd_mortality_12h_A1_future_window_24h_features.csv.gz",
    ("mortality", "A0_respiratory_extended"): INTERMEDIATE_ROOT / "copd_mortality_12h_A0_respiratory_extended_features.csv.gz",
    ("mortality", "A1_respiratory_extended_24h"): INTERMEDIATE_ROOT / "copd_mortality_12h_A1_respiratory_extended_24h_features.csv.gz",
    ("mortality", "A3_all_proxies"): INTERMEDIATE_ROOT / "copd_mortality_12h_A3_all_proxies_features.csv.gz",
    ("mortality", "A6_density_only"): INTERMEDIATE_ROOT / "copd_mortality_12h_A6_density_only_features.csv.gz",
    ("mortality", "A7_composite_convenience"): INTERMEDIATE_ROOT / "copd_mortality_12h_A7_composite_convenience_features.csv.gz",
    ("ventilation", "A0_clean"): INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A0_clean_features.csv.gz",
    ("ventilation", "A1_future_window_24h"): INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A1_future_window_24h_features.csv.gz",
    ("ventilation", "A0_respiratory_extended"): INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A0_respiratory_extended_features.csv.gz",
    ("ventilation", "A1_respiratory_extended_24h"): INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A1_respiratory_extended_24h_features.csv.gz",
    ("ventilation", "A3_all_proxies"): INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A3_all_proxies_features.csv.gz",
    ("ventilation", "A6_density_only"): INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A6_density_only_features.csv.gz",
    ("ventilation", "A7_composite_convenience"): INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A7_composite_convenience_features.csv.gz",
}


def sigmoid(z: np.ndarray) -> np.ndarray:
    z = np.clip(z, -35, 35)
    return 1.0 / (1.0 + np.exp(-z))


def rankdata_average(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(len(values), dtype=float)
    sorted_values = values[order]
    i = 0
    while i < len(values):
        j = i + 1
        while j < len(values) and sorted_values[j] == sorted_values[i]:
            j += 1
        ranks[order[i:j]] = (i + 1 + j) / 2.0
        i = j
    return ranks


def auroc(y: np.ndarray, pred: np.ndarray) -> float:
    y = y.astype(int)
    n_pos = int(y.sum())
    n_neg = len(y) - n_pos
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    ranks = rankdata_average(pred)
    return float((ranks[y == 1].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def auprc(y: np.ndarray, pred: np.ndarray) -> float:
    y = y.astype(int)
    n_pos = int(y.sum())
    if n_pos == 0:
        return float("nan")
    order = np.argsort(-pred, kind="mergesort")
    y_sorted = y[order]
    tp = np.cumsum(y_sorted)
    fp = np.cumsum(1 - y_sorted)
    recall = tp / n_pos
    precision = tp / np.maximum(tp + fp, 1)
    recall = np.r_[0.0, recall]
    precision = np.r_[precision[0] if len(precision) else 0.0, precision]
    return float(np.sum((recall[1:] - recall[:-1]) * precision[1:]))


def fit_logistic_l2(x: np.ndarray, y: np.ndarray, l2_penalty: float = 0.0) -> np.ndarray:
    n, p = x.shape
    design = np.column_stack([np.ones(n), x])
    beta = np.zeros(p + 1)
    penalty = np.r_[0.0, np.repeat(l2_penalty, p)]
    for _ in range(80):
        pred = sigmoid(design @ beta)
        weight = np.clip(pred * (1 - pred), 1e-6, None)
        gradient = design.T @ (pred - y) + penalty * beta
        hessian = (design.T * weight) @ design
        hessian.flat[:: hessian.shape[0] + 1] += penalty
        try:
            step = np.linalg.solve(hessian, gradient)
        except np.linalg.LinAlgError:
            step = np.linalg.lstsq(hessian, gradient, rcond=None)[0]
        beta -= step
        if float(np.max(np.abs(step))) < 1e-8:
            break
    return beta


def calibration_intercept_slope(y: np.ndarray, pred: np.ndarray) -> tuple[float, float]:
    if len(np.unique(y)) < 2:
        return float("nan"), float("nan")
    pred = np.clip(pred, 1e-6, 1 - 1e-6)
    logit_pred = np.log(pred / (1 - pred)).reshape(-1, 1)
    beta = fit_logistic_l2(logit_pred, y.astype(float), 0.0)
    return float(beta[0]), float(beta[1])


def ici(y: np.ndarray, pred: np.ndarray, n_bins: int = 10) -> float:
    frame = pd.DataFrame({"y": y, "pred": pred})
    try:
        frame["bin"] = pd.qcut(frame["pred"], q=n_bins, labels=False, duplicates="drop")
    except ValueError:
        frame["bin"] = 0
    grouped = frame.groupby("bin", dropna=False).agg(
        observed=("y", "mean"), predicted=("pred", "mean"), n=("y", "size")
    )
    return float(np.average(np.abs(grouped["observed"] - grouped["predicted"]), weights=grouped["n"]))


def metrics(y: np.ndarray, pred: np.ndarray) -> dict[str, float]:
    intercept, slope = calibration_intercept_slope(y, pred)
    prevalence = float(np.mean(y))
    ap = auprc(y, pred)
    return {
        "n": int(len(y)),
        "events": int(np.sum(y)),
        "event_rate": prevalence,
        "auroc": auroc(y, pred),
        "auprc": ap,
        "auprc_prevalence_ratio": ap / prevalence if prevalence > 0 else float("nan"),
        "brier": float(np.mean((y - pred) ** 2)),
        "mean_predicted_risk": float(np.mean(pred)),
        "calibration_intercept": intercept,
        "calibration_slope": slope,
        "ici_eavg": ici(y, pred),
    }


def select_feature_columns(df: pd.DataFrame, audit: str) -> list[str]:
    excluded = {
        "dataset",
        "patient_id",
        "hospital_id",
        "hospital_admission_id",
        "icu_stay_id",
        "sex",
        "icu_type",
        "hospital_mortality",
        "hospital_mortality_original",
        "task_name",
        "task_outcome",
        "eligible_12h_mortality",
        "eligible_12h_new_invasive_vent",
        "new_invasive_vent_12_48h",
    }
    columns = []
    for col in df.columns:
        if col in excluded or col.startswith(("c0_", "c1_", "c2_", "c3_", "c4_")):
            continue
        if audit != "A6_density_only" and col.startswith("a5_abg_"):
            continue
        if pd.api.types.is_numeric_dtype(df[col]) or pd.api.types.is_bool_dtype(df[col]):
            columns.append(col)
    return columns


def split_prepare(df: pd.DataFrame, audit: str) -> tuple[dict[str, pd.DataFrame], list[str], pd.Series]:
    mimic = df[df["dataset"].eq("MIMIC-IV")].copy()
    eicu = df[df["dataset"].eq("eICU")].copy()
    rng = np.random.default_rng(SEED)
    train_mask = rng.random(len(mimic)) < TRAIN_FRACTION
    frames = {
        "train": mimic[train_mask].copy(),
        "internal_valid": mimic[~train_mask].copy(),
        "external_valid": eicu.copy(),
    }
    feature_names = select_feature_columns(df, audit)
    medians = frames["train"][feature_names].median(numeric_only=True).fillna(0.0)
    return frames, feature_names, medians


def frame_to_matrix(frame: pd.DataFrame, feature_names: list[str], medians: pd.Series) -> np.ndarray:
    return frame[feature_names].fillna(medians).astype(float).to_numpy()


def train_one(task: str, audit: str, cohort: str, path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    df = pd.read_csv(path, compression="gzip", low_memory=False, dtype={"icu_stay_id": str})
    df = df[df[cohort].fillna(False).astype(bool)].copy()
    df["hospital_mortality"] = pd.to_numeric(df["hospital_mortality"], errors="coerce")
    df = df.dropna(subset=["hospital_mortality"]).copy()
    frames, feature_names, medians = split_prepare(df, audit)

    y_train = frames["train"]["hospital_mortality"].astype(float).to_numpy()
    x_train = frame_to_matrix(frames["train"], feature_names, medians)
    pos = float(np.sum(y_train))
    neg = float(len(y_train) - pos)
    scale_pos_weight = neg / pos if pos > 0 else 1.0

    dtrain = xgb.DMatrix(x_train, label=y_train, feature_names=feature_names)
    params = {
        "objective": "binary:logistic",
        "eval_metric": "logloss",
        "eta": 0.04,
        "max_depth": 3,
        "min_child_weight": 5,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "lambda": 2.0,
        "alpha": 0.1,
        "scale_pos_weight": scale_pos_weight,
        "seed": SEED,
        "verbosity": 0,
        "tree_method": "hist",
    }
    booster = xgb.train(params, dtrain, num_boost_round=180)

    safe = f"copd_{task}_{cohort}_{audit}_xgboost"
    booster.save_model(str(MODEL_ROOT / f"{safe}.json"))
    with (MODEL_ROOT / f"{safe}_metadata.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "task": task,
                "audit_variant": audit,
                "cohort_definition": cohort,
                "n_features": len(feature_names),
                "feature_names": feature_names,
                "params": params,
                "num_boost_round": 180,
            },
            handle,
            indent=2,
        )

    metrics_rows = []
    prediction_rows = []
    for split, frame in frames.items():
        y = frame["hospital_mortality"].astype(float).to_numpy()
        x = frame_to_matrix(frame, feature_names, medians)
        pred = booster.predict(xgb.DMatrix(x, feature_names=feature_names))
        row = {
            "task": task,
            "audit_variant": audit,
            "cohort_definition": cohort,
            "model": "xgboost",
            "dataset": "eICU" if split == "external_valid" else "MIMIC-IV",
            "split": split,
            "n_features": len(feature_names),
        }
        row.update(metrics(y, pred))
        metrics_rows.append(row)
        prediction_rows.append(
            pd.DataFrame(
                {
                    "task": task,
                    "audit_variant": audit,
                    "cohort_definition": cohort,
                    "dataset": row["dataset"],
                    "split": split,
                    "icu_stay_id": frame["icu_stay_id"].astype(str).to_numpy(),
                    "hospital_mortality": y,
                    "predicted_risk": pred,
                }
            )
        )
    predictions = pd.concat(prediction_rows, ignore_index=True)
    predictions.to_csv(INTERMEDIATE_ROOT / f"{safe}_predictions.csv.gz", index=False, compression="gzip")
    importance = pd.DataFrame(
        {"feature": list(booster.get_score(importance_type="gain").keys()), "gain": list(booster.get_score(importance_type="gain").values())}
    ).sort_values("gain", ascending=False)
    importance.to_csv(MODEL_ROOT / f"{safe}_feature_importance_gain.csv", index=False)
    return pd.DataFrame(metrics_rows), predictions


def build_delta(metrics_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (task, cohort, split), group in metrics_df.groupby(["task", "cohort_definition", "split"], sort=False):
        base = group[group["audit_variant"].eq("A0_clean")]
        if base.empty:
            continue
        base = base.iloc[0]
        for _, row in group.iterrows():
            rows.append(
                {
                    "task": task,
                    "cohort_definition": cohort,
                    "split": split,
                    "audit_variant": row["audit_variant"],
                    "delta_auroc_vs_A0": row["auroc"] - base["auroc"],
                    "delta_brier_vs_A0": row["brier"] - base["brier"],
                    "delta_calibration_slope_vs_A0": row["calibration_slope"] - base["calibration_slope"],
                    "delta_auprc_prevalence_ratio_vs_A0": row["auprc_prevalence_ratio"] - base["auprc_prevalence_ratio"],
                }
            )
    return pd.DataFrame(rows)


def main() -> int:
    MODEL_ROOT.mkdir(parents=True, exist_ok=True)
    TABLE_ROOT.mkdir(parents=True, exist_ok=True)
    all_metrics = []
    for task in ["mortality", "ventilation"]:
        for audit in AUDITS:
            path = MATRIX_PATHS[(task, audit)]
            for cohort in COHORTS:
                print(f"Training XGBoost {task} {audit} {cohort}")
                metrics_df, _ = train_one(task, audit, cohort, path)
                all_metrics.append(metrics_df)
    metrics_df = pd.concat(all_metrics, ignore_index=True)
    delta = build_delta(metrics_df)
    metrics_df.to_csv(TABLE_ROOT / "copd_xgboost_audit_metrics.csv", index=False)
    delta.to_csv(TABLE_ROOT / "copd_xgboost_audit_delta_vs_A0.csv", index=False)
    metrics_df.to_csv(MANUSCRIPT_TABLE_ROOT / "copd_xgboost_audit_metrics.csv", index=False)
    delta.to_csv(MANUSCRIPT_TABLE_ROOT / "copd_xgboost_audit_delta_vs_A0.csv", index=False)
    print("\nXGBoost external validation:")
    external = metrics_df[metrics_df["split"].eq("external_valid")]
    print(
        external[
            [
                "task",
                "cohort_definition",
                "audit_variant",
                "n",
                "events",
                "auroc",
                "auprc_prevalence_ratio",
                "brier",
                "calibration_slope",
                "ici_eavg",
            ]
        ].round(4).to_string(index=False)
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
