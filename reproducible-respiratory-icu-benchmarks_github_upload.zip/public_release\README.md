# Public release notes

This folder contains the public-facing schemas, synthetic examples, and release
checks for the COPD/AECOPD respiratory ICU audit. It does not contain MIMIC-IV
or eICU patient-level data.

## Files that can be public

- Analysis scripts.
- Protocol and statistical analysis plan.
- Cohort, audit, predictor-provenance, and guidance-mapping metadata.
- Aggregate result tables.
- Figure scripts and figure source data without patient-level rows.
- Synthetic mock inputs for testing schemas and examples.

## Files excluded from release

- Raw MIMIC-IV or eICU-CRD files.
- Patient-level intermediate extracts.
- Patient-level feature matrices.
- Patient-level predictions.
- Row-level files derived from restricted clinical databases.

## Repository layout

```text
.
|-- README.md
|-- analysis_manifest.yml
|-- environment.yml
|-- requirements.txt
|-- protocol/
|-- metadata/
|-- scripts/
|-- aggregate_outputs/
|-- figures/
|-- figure_source_data/
`-- public_release/
    |-- README.md
    |-- REPRODUCIBILITY_CHECKLIST.md
    |-- schemas/
    `-- mock_data/
```

Aggregate tables and figure source data should contain summaries only. If a
file contains `icu_stay_id`, `subject_id`, `patientunitstayid`, or row-level
predictions, leave it out unless it is a clearly labelled mock or schema file.

## Local reruns

Credentialed users must obtain MIMIC-IV and eICU-CRD locally through PhysioNet
and configure local paths before running the scripts.
