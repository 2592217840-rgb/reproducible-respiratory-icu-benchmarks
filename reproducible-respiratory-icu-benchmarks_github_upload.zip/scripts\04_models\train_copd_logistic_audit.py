from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
INTERMEDIATE_ROOT = PROJECT_ROOT / "data_intermediate"
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MODEL_ROOT = PROJECT_ROOT / "outputs" / "models"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"

SEED = 20260426
TRAIN_FRACTION = 0.70
L2_PENALTY = 1.0
MAX_ITER = 80
TOL = 1e-7

COHORTS = [
    "c1_discharge_icd_copd",
    "c2_copd_acute_respiratory_failure",
    "c4_convenience_copd",
]

MATRIX_SPECS = [
    (
        "mortality",
        "A0_clean",
        INTERMEDIATE_ROOT / "copd_mortality_12h_A0_clean_features.csv.gz",
    ),
    (
        "mortality",
        "A0_respiratory_extended",
        INTERMEDIATE_ROOT / "copd_mortality_12h_A0_respiratory_extended_features.csv.gz",
    ),
    (
        "mortality",
        "A1_future_window_24h",
        INTERMEDIATE_ROOT / "copd_mortality_12h_A1_future_window_24h_features.csv.gz",
    ),
    (
        "mortality",
        "A1_respiratory_extended_24h",
        INTERMEDIATE_ROOT / "copd_mortality_12h_A1_respiratory_extended_24h_features.csv.gz",
    ),
    (
        "mortality",
        "A3a_time_ambiguous_diagnosis",
        INTERMEDIATE_ROOT / "copd_mortality_12h_A3a_time_ambiguous_diagnosis_features.csv.gz",
    ),
    (
        "mortality",
        "A3b_admin_coding",
        INTERMEDIATE_ROOT / "copd_mortality_12h_A3b_admin_coding_features.csv.gz",
    ),
    (
        "mortality",
        "A3c_procedure_treatment",
        INTERMEDIATE_ROOT / "copd_mortality_12h_A3c_procedure_treatment_features.csv.gz",
    ),
    (
        "mortality",
        "A3_all_proxies",
        INTERMEDIATE_ROOT / "copd_mortality_12h_A3_all_proxies_features.csv.gz",
    ),
    (
        "mortality",
        "A7_composite_convenience",
        INTERMEDIATE_ROOT / "copd_mortality_12h_A7_composite_convenience_features.csv.gz",
    ),
    (
        "mortality",
        "A5_abg_complete_case",
        INTERMEDIATE_ROOT / "copd_mortality_12h_A5_abg_complete_case_features.csv.gz",
    ),
    (
        "mortality",
        "A6_density_only",
        INTERMEDIATE_ROOT / "copd_mortality_12h_A6_density_only_features.csv.gz",
    ),
    (
        "ventilation",
        "A0_clean",
        INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A0_clean_features.csv.gz",
    ),
    (
        "ventilation",
        "A0_respiratory_extended",
        INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A0_respiratory_extended_features.csv.gz",
    ),
    (
        "ventilation",
        "A1_future_window_24h",
        INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A1_future_window_24h_features.csv.gz",
    ),
    (
        "ventilation",
        "A1_respiratory_extended_24h",
        INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A1_respiratory_extended_24h_features.csv.gz",
    ),
    (
        "ventilation",
        "A3a_time_ambiguous_diagnosis",
        INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A3a_time_ambiguous_diagnosis_features.csv.gz",
    ),
    (
        "ventilation",
        "A3b_admin_coding",
        INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A3b_admin_coding_features.csv.gz",
    ),
    (
        "ventilation",
        "A3c_procedure_treatment",
        INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A3c_procedure_treatment_features.csv.gz",
    ),
    (
        "ventilation",
        "A3_all_proxies",
        INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A3_all_proxies_features.csv.gz",
    ),
    (
        "ventilation",
        "A7_composite_convenience",
        INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A7_composite_convenience_features.csv.gz",
    ),
    (
        "ventilation",
        "A5_abg_complete_case",
        INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A5_abg_complete_case_features.csv.gz",
    ),
    (
        "ventilation",
        "A6_density_only",
        INTERMEDIATE_ROOT / "copd_new_invasive_ventilation_12h_A6_density_only_features.csv.gz",
    ),
]

DCA_THRESHOLDS = {
    "mortality": [0.05, 0.10, 0.15, 0.20, 0.30],
    "ventilation": [0.005, 0.01, 0.02, 0.05, 0.10],
}


@dataclass
class PreparedData:
    x_train: np.ndarray
    y_train: np.ndarray
    x_internal: np.ndarray
    y_internal: np.ndarray
    x_external: np.ndarray
    y_external: np.ndarray
    train_frame: pd.DataFrame
    internal_frame: pd.DataFrame
    external_frame: pd.DataFrame
    feature_names: list[str]
    medians: pd.Series
    means: pd.Series
    stds: pd.Series


def ensure_dirs() -> None:
    INTERMEDIATE_ROOT.mkdir(parents=True, exist_ok=True)
    TABLE_ROOT.mkdir(parents=True, exist_ok=True)
    MODEL_ROOT.mkdir(parents=True, exist_ok=True)
    MANUSCRIPT_TABLE_ROOT.mkdir(parents=True, exist_ok=True)


def sigmoid(z: np.ndarray) -> np.ndarray:
    z = np.clip(z, -35, 35)
    return 1.0 / (1.0 + np.exp(-z))


def fit_logistic_l2(
    x: np.ndarray,
    y: np.ndarray,
    l2_penalty: float = L2_PENALTY,
    max_iter: int = MAX_ITER,
    tol: float = TOL,
) -> tuple[np.ndarray, list[dict[str, float]]]:
    n, p = x.shape
    x_design = np.column_stack([np.ones(n), x])
    beta = np.zeros(p + 1)
    penalty = np.r_[0.0, np.repeat(l2_penalty, p)]
    history: list[dict[str, float]] = []

    for iteration in range(1, max_iter + 1):
        eta = x_design @ beta
        prob = sigmoid(eta)
        weight = np.clip(prob * (1.0 - prob), 1e-6, None)
        gradient = x_design.T @ (prob - y) + penalty * beta
        hessian = (x_design.T * weight) @ x_design
        hessian.flat[:: hessian.shape[0] + 1] += penalty
        try:
            step = np.linalg.solve(hessian, gradient)
        except np.linalg.LinAlgError:
            step = np.linalg.lstsq(hessian, gradient, rcond=None)[0]
        beta = beta - step
        max_step = float(np.max(np.abs(step)))
        loss = float(
            -np.mean(
                y * np.log(np.clip(prob, 1e-15, 1))
                + (1 - y) * np.log(np.clip(1 - prob, 1e-15, 1))
            )
            + 0.5 * l2_penalty * np.sum(beta[1:] ** 2) / max(n, 1)
        )
        history.append({"iteration": iteration, "loss": loss, "max_step": max_step})
        if max_step < tol:
            break
    return beta, history


def predict_logistic(beta: np.ndarray, x: np.ndarray) -> np.ndarray:
    return sigmoid(np.column_stack([np.ones(len(x)), x]) @ beta)


def rankdata_average(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(len(values), dtype=float)
    sorted_values = values[order]
    i = 0
    while i < len(values):
        j = i + 1
        while j < len(values) and sorted_values[j] == sorted_values[i]:
            j += 1
        avg_rank = (i + 1 + j) / 2.0
        ranks[order[i:j]] = avg_rank
        i = j
    return ranks


def auroc(y: np.ndarray, pred: np.ndarray) -> float:
    y = y.astype(int)
    n_pos = int(y.sum())
    n_neg = len(y) - n_pos
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    ranks = rankdata_average(pred)
    return float((ranks[y == 1].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def auprc(y: np.ndarray, pred: np.ndarray) -> float:
    y = y.astype(int)
    n_pos = int(y.sum())
    if n_pos == 0:
        return float("nan")
    order = np.argsort(-pred, kind="mergesort")
    y_sorted = y[order]
    tp = np.cumsum(y_sorted)
    fp = np.cumsum(1 - y_sorted)
    recall = tp / n_pos
    precision = tp / np.maximum(tp + fp, 1)
    recall = np.r_[0.0, recall]
    precision = np.r_[precision[0] if len(precision) else 0.0, precision]
    return float(np.sum((recall[1:] - recall[:-1]) * precision[1:]))


def calibration_intercept_slope(y: np.ndarray, pred: np.ndarray) -> tuple[float, float]:
    if len(np.unique(y)) < 2:
        return float("nan"), float("nan")
    pred = np.clip(pred, 1e-6, 1 - 1e-6)
    logit_pred = np.log(pred / (1 - pred)).reshape(-1, 1)
    beta, _ = fit_logistic_l2(logit_pred, y.astype(float), l2_penalty=0.0, max_iter=60)
    return float(beta[0]), float(beta[1])


def ici(y: np.ndarray, pred: np.ndarray, n_bins: int = 10) -> float:
    frame = pd.DataFrame({"y": y, "pred": pred})
    try:
        frame["bin"] = pd.qcut(frame["pred"], q=n_bins, labels=False, duplicates="drop")
    except ValueError:
        frame["bin"] = 0
    grouped = (
        frame.groupby("bin", dropna=False)
        .agg(observed=("y", "mean"), predicted=("pred", "mean"), n=("y", "size"))
        .reset_index()
    )
    return float(np.average(np.abs(grouped["observed"] - grouped["predicted"]), weights=grouped["n"]))


def net_benefit(y: np.ndarray, pred: np.ndarray, threshold: float) -> float:
    y = y.astype(int)
    treated = pred >= threshold
    tp = int(((y == 1) & treated).sum())
    fp = int(((y == 0) & treated).sum())
    n = len(y)
    if n == 0 or threshold <= 0 or threshold >= 1:
        return float("nan")
    return float(tp / n - fp / n * threshold / (1 - threshold))


def treat_all_net_benefit(y: np.ndarray, threshold: float) -> float:
    prevalence = float(np.mean(y))
    return float(prevalence - (1 - prevalence) * threshold / (1 - threshold))


def metric_row(y: np.ndarray, pred: np.ndarray) -> dict[str, float]:
    intercept, slope = calibration_intercept_slope(y, pred)
    prevalence = float(np.mean(y)) if len(y) else float("nan")
    ap = auprc(y, pred)
    return {
        "n": int(len(y)),
        "events": int(np.sum(y)),
        "event_rate": prevalence,
        "auroc": auroc(y, pred),
        "auprc": ap,
        "auprc_prevalence_ratio": float(ap / prevalence) if prevalence > 0 else float("nan"),
        "brier": float(np.mean((y - pred) ** 2)),
        "mean_predicted_risk": float(np.mean(pred)),
        "calibration_intercept": intercept,
        "calibration_slope": slope,
        "ici_eavg": ici(y, pred),
    }


def calibration_bins(y: np.ndarray, pred: np.ndarray, n_bins: int = 10) -> pd.DataFrame:
    frame = pd.DataFrame({"y": y, "pred": pred})
    try:
        frame["bin"] = pd.qcut(frame["pred"], q=n_bins, labels=False, duplicates="drop")
    except ValueError:
        frame["bin"] = 0
    return (
        frame.groupby("bin", dropna=False)
        .agg(
            n=("y", "size"),
            observed_rate=("y", "mean"),
            mean_predicted=("pred", "mean"),
            min_predicted=("pred", "min"),
            max_predicted=("pred", "max"),
        )
        .reset_index()
    )


def select_feature_columns(df: pd.DataFrame, audit_variant: str) -> list[str]:
    excluded_exact = {
        "dataset",
        "patient_id",
        "hospital_id",
        "hospital_admission_id",
        "icu_stay_id",
        "sex",
        "icu_type",
        "hospital_mortality",
        "hospital_mortality_original",
        "task_name",
        "task_outcome",
        "eligible_12h_mortality",
        "eligible_12h_new_invasive_vent",
        "new_invasive_vent_12_48h",
    }
    excluded_prefixes = ("c0_", "c1_", "c2_", "c3_", "c4_")
    columns: list[str] = []
    for col in df.columns:
        if col in excluded_exact:
            continue
        if col.startswith(excluded_prefixes):
            continue
        if audit_variant != "A6_density_only" and col.startswith("a5_abg_"):
            continue
        if pd.api.types.is_numeric_dtype(df[col]) or pd.api.types.is_bool_dtype(df[col]):
            columns.append(col)
    return columns


def prepare_data(df: pd.DataFrame, audit_variant: str) -> PreparedData:
    mimic = df[df["dataset"].eq("MIMIC-IV")].copy()
    eicu = df[df["dataset"].eq("eICU")].copy()
    rng = np.random.default_rng(SEED)
    train_mask = rng.random(len(mimic)) < TRAIN_FRACTION
    mimic_train = mimic[train_mask].copy()
    mimic_internal = mimic[~train_mask].copy()

    feature_names = select_feature_columns(df, audit_variant)
    y_train = mimic_train["hospital_mortality"].astype(float).to_numpy()
    y_internal = mimic_internal["hospital_mortality"].astype(float).to_numpy()
    y_external = eicu["hospital_mortality"].astype(float).to_numpy()

    medians = mimic_train[feature_names].median(numeric_only=True).fillna(0.0)
    train_filled = mimic_train[feature_names].fillna(medians).astype(float)
    internal_filled = mimic_internal[feature_names].fillna(medians).astype(float)
    external_filled = eicu[feature_names].fillna(medians).astype(float)

    means = train_filled.mean()
    stds = train_filled.std(ddof=0).replace(0, 1).fillna(1.0)

    return PreparedData(
        x_train=((train_filled - means) / stds).to_numpy(dtype=float),
        y_train=y_train,
        x_internal=((internal_filled - means) / stds).to_numpy(dtype=float),
        y_internal=y_internal,
        x_external=((external_filled - means) / stds).to_numpy(dtype=float),
        y_external=y_external,
        train_frame=mimic_train,
        internal_frame=mimic_internal,
        external_frame=eicu,
        feature_names=feature_names,
        medians=medians,
        means=means,
        stds=stds,
    )


def write_artifacts(
    task: str,
    audit_variant: str,
    cohort: str,
    prepared: PreparedData,
    beta: np.ndarray,
    history: list[dict[str, float]],
    pred_train: np.ndarray,
    pred_internal: np.ndarray,
    pred_external: np.ndarray,
) -> pd.DataFrame:
    safe_name = f"copd_{task}_{cohort}_{audit_variant}_logistic"
    coefficient = pd.DataFrame(
        [{"feature": "intercept", "coefficient": float(beta[0])}]
        + [
            {"feature": feature, "coefficient": float(coef)}
            for feature, coef in zip(prepared.feature_names, beta[1:])
        ]
    )
    coefficient.to_csv(MODEL_ROOT / f"{safe_name}_coefficients.csv", index=False)
    with (MODEL_ROOT / f"{safe_name}_metadata.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "task": task,
                "audit_variant": audit_variant,
                "cohort": cohort,
                "seed": SEED,
                "train_fraction": TRAIN_FRACTION,
                "l2_penalty": L2_PENALTY,
                "n_features": len(prepared.feature_names),
                "feature_names": prepared.feature_names,
                "iterations": len(history),
                "history": history,
            },
            handle,
            indent=2,
        )

    pred_frames = []
    for split, frame, y, pred in [
        ("train", prepared.train_frame, prepared.y_train, pred_train),
        ("internal_valid", prepared.internal_frame, prepared.y_internal, pred_internal),
        ("external_valid", prepared.external_frame, prepared.y_external, pred_external),
    ]:
        pred_frames.append(
            pd.DataFrame(
                {
                    "task": task,
                    "audit_variant": audit_variant,
                    "cohort_definition": cohort,
                    "dataset": frame["dataset"].to_numpy(),
                    "split": split,
                    "icu_stay_id": frame["icu_stay_id"].astype(str).to_numpy(),
                    "hospital_mortality": y,
                    "predicted_risk": pred,
                }
            )
        )
    predictions = pd.concat(pred_frames, ignore_index=True)
    predictions.to_csv(
        INTERMEDIATE_ROOT / f"{safe_name}_predictions.csv.gz",
        index=False,
        compression="gzip",
    )

    bins = []
    for split, y, pred in [
        ("train", prepared.y_train, pred_train),
        ("internal_valid", prepared.y_internal, pred_internal),
        ("external_valid", prepared.y_external, pred_external),
    ]:
        table = calibration_bins(y, pred)
        table.insert(0, "split", split)
        table.insert(0, "cohort_definition", cohort)
        table.insert(0, "audit_variant", audit_variant)
        table.insert(0, "task", task)
        bins.append(table)
    return pd.concat(bins, ignore_index=True)


def run_one(task: str, audit_variant: str, path: Path, cohort: str) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    df = pd.read_csv(path, compression="gzip", low_memory=False, dtype={"icu_stay_id": str})
    df = df[df[cohort].fillna(False).astype(bool)].copy()
    df["hospital_mortality"] = pd.to_numeric(df["hospital_mortality"], errors="coerce")
    df = df.dropna(subset=["hospital_mortality"]).copy()
    if df["dataset"].eq("MIMIC-IV").sum() < 100 or df["dataset"].eq("eICU").sum() < 100:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    if df[df["dataset"].eq("MIMIC-IV")]["hospital_mortality"].nunique() < 2:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    if df[df["dataset"].eq("eICU")]["hospital_mortality"].nunique() < 2:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    prepared = prepare_data(df, audit_variant)
    beta, history = fit_logistic_l2(prepared.x_train, prepared.y_train)
    pred_train = predict_logistic(beta, prepared.x_train)
    pred_internal = predict_logistic(beta, prepared.x_internal)
    pred_external = predict_logistic(beta, prepared.x_external)

    calibration = write_artifacts(
        task,
        audit_variant,
        cohort,
        prepared,
        beta,
        history,
        pred_train,
        pred_internal,
        pred_external,
    )

    metrics_rows = []
    for split, dataset, y, pred in [
        ("train", "MIMIC-IV", prepared.y_train, pred_train),
        ("internal_valid", "MIMIC-IV", prepared.y_internal, pred_internal),
        ("external_valid", "eICU", prepared.y_external, pred_external),
    ]:
        row = {
            "task": task,
            "audit_variant": audit_variant,
            "cohort_definition": cohort,
            "model": "logistic_l2_numpy",
            "dataset": dataset,
            "split": split,
            "n_features": len(prepared.feature_names),
        }
        row.update(metric_row(y, pred))
        metrics_rows.append(row)

    dca_rows = []
    for split, dataset, y, pred in [
        ("internal_valid", "MIMIC-IV", prepared.y_internal, pred_internal),
        ("external_valid", "eICU", prepared.y_external, pred_external),
    ]:
        for threshold in DCA_THRESHOLDS[task]:
            dca_rows.append(
                {
                    "task": task,
                    "audit_variant": audit_variant,
                    "cohort_definition": cohort,
                    "dataset": dataset,
                    "split": split,
                    "threshold": threshold,
                    "net_benefit_model": net_benefit(y, pred, threshold),
                    "net_benefit_treat_all": treat_all_net_benefit(y, threshold),
                    "net_benefit_treat_none": 0.0,
                }
            )

    return pd.DataFrame(metrics_rows), pd.DataFrame(dca_rows), calibration


def build_delta_summary(metrics: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (task, cohort, split), group in metrics.groupby(
        ["task", "cohort_definition", "split"], sort=False
    ):
        base = group[group["audit_variant"].eq("A0_clean")]
        if base.empty:
            continue
        base_row = base.iloc[0]
        for _, row in group.iterrows():
            rows.append(
                {
                    "task": task,
                    "cohort_definition": cohort,
                    "split": split,
                    "audit_variant": row["audit_variant"],
                    "delta_auroc_vs_A0": row["auroc"] - base_row["auroc"],
                    "delta_auprc_ratio_vs_A0": row["auprc_prevalence_ratio"]
                    - base_row["auprc_prevalence_ratio"],
                    "delta_brier_vs_A0": row["brier"] - base_row["brier"],
                    "delta_calibration_slope_vs_A0": row["calibration_slope"]
                    - base_row["calibration_slope"],
                    "internal_external_auroc_gap": None,
                }
            )
    out = pd.DataFrame(rows)
    gap_rows = []
    for (task, cohort, audit_variant), group in metrics.groupby(
        ["task", "cohort_definition", "audit_variant"], sort=False
    ):
        internal = group[group["split"].eq("internal_valid")]
        external = group[group["split"].eq("external_valid")]
        if internal.empty or external.empty:
            continue
        gap_rows.append(
            {
                "task": task,
                "cohort_definition": cohort,
                "audit_variant": audit_variant,
                "internal_external_auroc_gap": float(internal.iloc[0]["auroc"] - external.iloc[0]["auroc"]),
                "external_calibration_slope_deviation": float(
                    abs(1 - external.iloc[0]["calibration_slope"])
                ),
            }
        )
    gaps = pd.DataFrame(gap_rows)
    if not gaps.empty:
        out = out.drop(columns=["internal_external_auroc_gap"]).merge(
            gaps, on=["task", "cohort_definition", "audit_variant"], how="left"
        )
    return out


def main() -> int:
    ensure_dirs()
    all_metrics = []
    all_dca = []
    all_calibration = []

    for task, audit_variant, path in MATRIX_SPECS:
        for cohort in COHORTS:
            print(f"Training {task} {audit_variant} {cohort}")
            metrics, dca, calibration = run_one(task, audit_variant, path, cohort)
            if not metrics.empty:
                all_metrics.append(metrics)
                all_dca.append(dca)
                all_calibration.append(calibration)

    metrics_df = pd.concat(all_metrics, ignore_index=True)
    dca_df = pd.concat(all_dca, ignore_index=True)
    calibration_df = pd.concat(all_calibration, ignore_index=True)
    delta_df = build_delta_summary(metrics_df)

    metrics_path = TABLE_ROOT / "copd_logistic_audit_metrics.csv"
    dca_path = TABLE_ROOT / "copd_logistic_threshold_dca.csv"
    calibration_path = TABLE_ROOT / "copd_logistic_calibration_bins.csv"
    delta_path = TABLE_ROOT / "copd_logistic_audit_delta_vs_A0.csv"

    metrics_df.to_csv(metrics_path, index=False)
    dca_df.to_csv(dca_path, index=False)
    calibration_df.to_csv(calibration_path, index=False)
    delta_df.to_csv(delta_path, index=False)

    metrics_df.to_csv(MANUSCRIPT_TABLE_ROOT / metrics_path.name, index=False)
    dca_df.to_csv(MANUSCRIPT_TABLE_ROOT / dca_path.name, index=False)
    delta_df.to_csv(MANUSCRIPT_TABLE_ROOT / delta_path.name, index=False)

    print(f"Wrote {metrics_path}")
    print(f"Wrote {dca_path}")
    print(f"Wrote {delta_path}")
    print("\nExternal validation metrics:")
    external = metrics_df[metrics_df["split"].eq("external_valid")].copy()
    cols = [
        "task",
        "cohort_definition",
        "audit_variant",
        "n",
        "events",
        "event_rate",
        "auroc",
        "auprc",
        "auprc_prevalence_ratio",
        "brier",
        "calibration_intercept",
        "calibration_slope",
        "ici_eavg",
    ]
    print(external[cols].to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
