from __future__ import annotations

import csv
import gzip
import re
from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_ROOT = PROJECT_ROOT.parent
MIMIC_ROOT = DATA_ROOT / "mimic-iv-3.1" / "mimic-iv-3.1"
EICU_ROOT = (
    DATA_ROOT
    / "eicu-collaborative-research-database-2.0"
    / "eicu-collaborative-research-database-2.0"
)

INPUT_BACKBONE = (
    PROJECT_ROOT / "data_intermediate" / "copd_12h_backbone_with_cohort_flags.csv.gz"
)
OUTPUT_ROOT = PROJECT_ROOT / "data_intermediate"
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"

LANDMARK_HOURS = 12
LANDMARK_MINUTES = LANDMARK_HOURS * 60
OUTCOME_WINDOW_HOURS = 48
OUTCOME_WINDOW_MINUTES = OUTCOME_WINDOW_HOURS * 60

COHORT_COLUMNS = [
    "c0_conservative_copd",
    "c1_discharge_icd_copd",
    "c2_copd_acute_respiratory_failure",
    "c3_treatment_enriched_copd",
    "c4_convenience_copd",
]

MIMIC_INVASIVE_VENT_PROCEDURE_ITEMIDS = {
    224385,  # Intubation
    225792,  # Invasive Ventilation
}
MIMIC_RESPIRATORY_SUPPORT_PROCEDURE_ITEMIDS = {
    224385,
    225792,
    225794,  # Non-invasive Ventilation
}

COPD_TREATMENT_DRUG_RE = re.compile(
    r"\b(?:"
    r"albuterol|salbutamol|ipratropium|duoneb|combivent|tiotropium|spiriva|"
    r"budesonide|formoterol|fluticasone|salmeterol|advair|symbicort|"
    r"prednisone|prednisolone|methylpred|solu[- ]?medrol|hydrocortisone|dexamethasone|"
    r"azithromycin|levofloxacin|moxifloxacin|ceftriaxone|doxycycline"
    r")\b",
    flags=re.IGNORECASE,
)

EICU_INVASIVE_AIRWAY_RE = re.compile(
    r"\b(?:oral ett|nasal ett|endotracheal|tracheostomy|ett)\b",
    flags=re.IGNORECASE,
)
EICU_RESPIRATORY_TREATMENT_RE = re.compile(
    r"\b(?:"
    r"ventilat|intubat|extubat|bipap|cpap|non[- ]?invasive|niv|oxygen|"
    r"bronchodilator|albuterol|ipratropium|steroid|prednisone|methylpred|"
    r"antibiotic|azithromycin|levofloxacin|ceftriaxone"
    r")\b",
    flags=re.IGNORECASE,
)


def ensure_dirs() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    TABLE_ROOT.mkdir(parents=True, exist_ok=True)
    MANUSCRIPT_TABLE_ROOT.mkdir(parents=True, exist_ok=True)


def read_backbone() -> pd.DataFrame:
    df = pd.read_csv(INPUT_BACKBONE, compression="gzip", low_memory=False)
    for col in [
        "icu_admit_time",
        "icu_discharge_time",
        "hospital_admit_time",
        "hospital_discharge_time",
        "landmark_time",
    ]:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    for col in COHORT_COLUMNS:
        df[col] = df[col].fillna(False).astype(bool)
    df["icu_stay_id"] = df["icu_stay_id"].astype(str)
    df["hospital_admission_id"] = df["hospital_admission_id"].astype(str)
    return df


def _merge_mimic_stay_times(events: pd.DataFrame, mimic_base: pd.DataFrame) -> pd.DataFrame:
    stay_times = mimic_base[
        ["icu_stay_id", "icu_admit_time", "landmark_time", "icu_discharge_time"]
    ].drop_duplicates()
    events["icu_stay_id"] = events["stay_id"].astype(str)
    events = events.merge(stay_times, on="icu_stay_id", how="inner")
    return events


def build_mimic_procedure_respiratory_flags(mimic_base: pd.DataFrame) -> pd.DataFrame:
    stay_ids = set(mimic_base["icu_stay_id"].astype(str))
    proc = pd.read_csv(
        MIMIC_ROOT / "icu" / "procedureevents.csv.gz",
        compression="gzip",
        usecols=["stay_id", "starttime", "endtime", "itemid"],
        parse_dates=["starttime", "endtime"],
    )
    proc = proc[proc["stay_id"].astype(str).isin(stay_ids)].copy()
    proc = proc[
        proc["itemid"].isin(
            MIMIC_INVASIVE_VENT_PROCEDURE_ITEMIDS
            | MIMIC_RESPIRATORY_SUPPORT_PROCEDURE_ITEMIDS
        )
    ].copy()
    proc = _merge_mimic_stay_times(proc, mimic_base)
    proc["event_time"] = proc["starttime"].fillna(proc["endtime"])
    proc["hours_from_icu_admit"] = (
        proc["event_time"] - proc["icu_admit_time"]
    ).dt.total_seconds() / 3600
    proc["is_invasive_vent_event"] = proc["itemid"].isin(
        MIMIC_INVASIVE_VENT_PROCEDURE_ITEMIDS
    )
    proc["is_resp_support_event"] = proc["itemid"].isin(
        MIMIC_RESPIRATORY_SUPPORT_PROCEDURE_ITEMIDS
    )

    rows = []
    for stay_id, group in proc.groupby("icu_stay_id"):
        invasive = group[group["is_invasive_vent_event"]]
        support = group[group["is_resp_support_event"]]
        rows.append(
            {
                "icu_stay_id": stay_id,
                "mimic_invasive_vent_before_or_at_12h": bool(
                    (invasive["hours_from_icu_admit"] <= LANDMARK_HOURS).any()
                ),
                "mimic_new_invasive_vent_12_48h": bool(
                    (
                        (invasive["hours_from_icu_admit"] > LANDMARK_HOURS)
                        & (invasive["hours_from_icu_admit"] <= OUTCOME_WINDOW_HOURS)
                    ).any()
                ),
                "mimic_early_resp_support_before_or_at_12h": bool(
                    (support["hours_from_icu_admit"] <= LANDMARK_HOURS).any()
                ),
            }
        )
    out = pd.DataFrame(rows)
    if out.empty:
        out = pd.DataFrame(
            columns=[
                "icu_stay_id",
                "mimic_invasive_vent_before_or_at_12h",
                "mimic_new_invasive_vent_12_48h",
                "mimic_early_resp_support_before_or_at_12h",
            ]
        )
    return out


def build_mimic_early_copd_treatment_flags(mimic_base: pd.DataFrame) -> pd.DataFrame:
    mimic_base = mimic_base.copy()
    mimic_base["hospital_admission_id"] = mimic_base["hospital_admission_id"].astype(str)
    hadm_lookup = mimic_base[
        [
            "hospital_admission_id",
            "icu_stay_id",
            "hospital_admit_time",
            "icu_admit_time",
            "landmark_time",
        ]
    ].drop_duplicates()
    hadm_ids = set(hadm_lookup["hospital_admission_id"])

    chunks = []
    for chunk in pd.read_csv(
        MIMIC_ROOT / "hosp" / "prescriptions.csv.gz",
        compression="gzip",
        usecols=["hadm_id", "starttime", "drug"],
        parse_dates=["starttime"],
        chunksize=500_000,
    ):
        chunk["hospital_admission_id"] = chunk["hadm_id"].astype(str)
        chunk = chunk[chunk["hospital_admission_id"].isin(hadm_ids)].copy()
        if chunk.empty:
            continue
        chunk["drug"] = chunk["drug"].fillna("")
        chunk = chunk[chunk["drug"].str.contains(COPD_TREATMENT_DRUG_RE, regex=True)]
        if not chunk.empty:
            chunks.append(chunk[["hospital_admission_id", "starttime", "drug"]])
    if chunks:
        rx = pd.concat(chunks, ignore_index=True)
        rx = rx.merge(hadm_lookup, on="hospital_admission_id", how="inner")
        rx["early_copd_med_before_or_at_12h"] = (
            rx["starttime"].notna()
            & (rx["starttime"] >= rx["hospital_admit_time"])
            & (rx["starttime"] <= rx["landmark_time"])
        )
        flags = (
            rx.groupby("icu_stay_id")
            .agg(
                mimic_early_copd_med_before_or_at_12h=(
                    "early_copd_med_before_or_at_12h",
                    "max",
                )
            )
            .reset_index()
        )
    else:
        flags = pd.DataFrame(
            columns=["icu_stay_id", "mimic_early_copd_med_before_or_at_12h"]
        )
    return flags


def _safe_float(value: str) -> float | None:
    try:
        if value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def build_eicu_respiratory_flags(eicu_base: pd.DataFrame) -> pd.DataFrame:
    stay_ids = set(eicu_base["icu_stay_id"].astype(str))
    flags: dict[str, dict[str, bool | list[float]]] = {
        stay_id: {
            "eicu_invasive_vent_before_or_at_12h": False,
            "eicu_new_invasive_vent_12_48h": False,
            "eicu_early_resp_treatment_before_or_at_12h": False,
            "invasive_evidence_offsets": [],
            "vent_start_chart_offsets": [],
        }
        for stay_id in stay_ids
    }

    with gzip.open(
        EICU_ROOT / "respiratoryCare.csv.gz",
        "rt",
        encoding="utf-8",
        errors="replace",
        newline="",
    ) as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            stay_id = str(row.get("patientunitstayid", ""))
            if stay_id not in flags:
                continue
            airway = row.get("airwaytype", "") or ""
            is_invasive_airway = bool(EICU_INVASIVE_AIRWAY_RE.search(airway))
            status = _safe_float(row.get("respcarestatusoffset", ""))
            start = _safe_float(row.get("ventstartoffset", ""))
            if is_invasive_airway:
                if status is not None:
                    flags[stay_id]["invasive_evidence_offsets"].append(status)
                # Negative starts indicate ventilation already underway before ICU admission.
                # A zero start is common in eICU and is treated as ambiguous rather than
                # automatically baseline ventilation.
                if start is not None and start < 0:
                    flags[stay_id]["invasive_evidence_offsets"].append(start)

    with gzip.open(
        EICU_ROOT / "respiratoryCharting.csv.gz",
        "rt",
        encoding="utf-8",
        errors="replace",
        newline="",
    ) as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            stay_id = str(row.get("patientunitstayid", ""))
            if stay_id not in flags:
                continue
            label = (row.get("respchartvaluelabel", "") or "").strip().lower()
            if label != "rt vent on/off":
                continue
            value = (row.get("respchartvalue", "") or "").strip().lower()
            offset = _safe_float(row.get("respchartoffset", ""))
            if offset is None:
                continue
            if value in {"start", "continued"} and offset <= LANDMARK_MINUTES:
                flags[stay_id]["invasive_evidence_offsets"].append(offset)
            elif value == "start" and LANDMARK_MINUTES < offset <= OUTCOME_WINDOW_MINUTES:
                flags[stay_id]["vent_start_chart_offsets"].append(offset)

    with gzip.open(
        EICU_ROOT / "treatment.csv.gz",
        "rt",
        encoding="utf-8",
        errors="replace",
        newline="",
    ) as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            stay_id = str(row.get("patientunitstayid", ""))
            if stay_id not in flags:
                continue
            offset = _safe_float(row.get("treatmentoffset", ""))
            if offset is None or offset > LANDMARK_MINUTES:
                continue
            text = row.get("treatmentstring", "") or ""
            if EICU_RESPIRATORY_TREATMENT_RE.search(text):
                flags[stay_id]["eicu_early_resp_treatment_before_or_at_12h"] = True

    for stay_id, values in flags.items():
        evidence_offsets = values["invasive_evidence_offsets"]
        chart_start_offsets = values["vent_start_chart_offsets"]
        has_baseline_evidence = any(offset <= LANDMARK_MINUTES for offset in evidence_offsets)
        has_new_airway_evidence = any(
            LANDMARK_MINUTES < offset <= OUTCOME_WINDOW_MINUTES
            for offset in evidence_offsets
        )
        has_new_chart_start = any(
            LANDMARK_MINUTES < offset <= OUTCOME_WINDOW_MINUTES
            for offset in chart_start_offsets
        )
        values["eicu_invasive_vent_before_or_at_12h"] = bool(has_baseline_evidence)
        values["eicu_new_invasive_vent_12_48h"] = bool(
            not has_baseline_evidence and (has_new_airway_evidence or has_new_chart_start)
        )

    return pd.DataFrame(
        [
            {
                "icu_stay_id": stay_id,
                "eicu_invasive_vent_before_or_at_12h": values[
                    "eicu_invasive_vent_before_or_at_12h"
                ],
                "eicu_new_invasive_vent_12_48h": values[
                    "eicu_new_invasive_vent_12_48h"
                ],
                "eicu_early_resp_treatment_before_or_at_12h": values[
                    "eicu_early_resp_treatment_before_or_at_12h"
                ],
            }
            for stay_id, values in flags.items()
        ]
    )


def attach_flags(backbone: pd.DataFrame) -> pd.DataFrame:
    mimic = backbone[backbone["dataset"] == "MIMIC-IV"].copy()
    eicu = backbone[backbone["dataset"] == "eICU"].copy()

    mimic_proc = build_mimic_procedure_respiratory_flags(mimic)
    mimic_rx = build_mimic_early_copd_treatment_flags(mimic)
    mimic = mimic.merge(mimic_proc, on="icu_stay_id", how="left")
    mimic = mimic.merge(mimic_rx, on="icu_stay_id", how="left")
    for col in [
        "mimic_invasive_vent_before_or_at_12h",
        "mimic_new_invasive_vent_12_48h",
        "mimic_early_resp_support_before_or_at_12h",
        "mimic_early_copd_med_before_or_at_12h",
    ]:
        mimic[col] = mimic[col].fillna(False).astype(bool)

    eicu_flags = build_eicu_respiratory_flags(eicu)
    eicu = eicu.merge(eicu_flags, on="icu_stay_id", how="left")
    for col in [
        "eicu_invasive_vent_before_or_at_12h",
        "eicu_new_invasive_vent_12_48h",
        "eicu_early_resp_treatment_before_or_at_12h",
    ]:
        eicu[col] = eicu[col].fillna(False).astype(bool)

    mimic["invasive_vent_before_or_at_12h"] = mimic[
        "mimic_invasive_vent_before_or_at_12h"
    ]
    mimic["new_invasive_vent_12_48h"] = mimic["mimic_new_invasive_vent_12_48h"]
    mimic["early_resp_treatment_before_or_at_12h"] = (
        mimic["mimic_early_resp_support_before_or_at_12h"]
        | mimic["mimic_early_copd_med_before_or_at_12h"]
    )

    eicu["invasive_vent_before_or_at_12h"] = eicu[
        "eicu_invasive_vent_before_or_at_12h"
    ]
    eicu["new_invasive_vent_12_48h"] = eicu["eicu_new_invasive_vent_12_48h"]
    eicu["early_resp_treatment_before_or_at_12h"] = eicu[
        "eicu_early_resp_treatment_before_or_at_12h"
    ]

    combined = pd.concat([mimic, eicu], ignore_index=True)
    combined["eligible_12h_new_invasive_vent"] = (
        combined["eligible_12h_mortality"]
        & ~combined["invasive_vent_before_or_at_12h"]
    )

    # C3 is deliberately a treatment-enriched cohort definition. It is used to audit
    # cohort-definition bias and should not be interpreted as a clean COPD phenotype.
    combined["c3_treatment_enriched_copd"] = (
        combined["c3_treatment_enriched_copd"]
        | (
            (combined["c0_conservative_copd"] | combined["c1_discharge_icd_copd"])
            & combined["early_resp_treatment_before_or_at_12h"]
        )
    ).astype(bool)
    combined["c4_convenience_copd"] = (
        combined["c0_conservative_copd"]
        | combined["c1_discharge_icd_copd"]
        | combined["c2_copd_acute_respiratory_failure"]
        | combined["c3_treatment_enriched_copd"]
    ).astype(bool)
    return combined


def summarize_updated_mortality_cohorts(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    eligible = df[df["eligible_12h_mortality"]].copy()
    for dataset, dataset_group in eligible.groupby("dataset", sort=False):
        for cohort_col in COHORT_COLUMNS:
            cohort = dataset_group[dataset_group[cohort_col]]
            rows.append(
                {
                    "dataset": dataset,
                    "cohort_definition": cohort_col,
                    "n_eligible_12h_mortality": len(cohort),
                    "n_hospital_deaths_after_landmark": int(
                        pd.to_numeric(cohort["hospital_mortality"], errors="coerce")
                        .fillna(0)
                        .sum()
                    ),
                    "event_rate_after_landmark": round(
                        float(
                            pd.to_numeric(
                                cohort["hospital_mortality"], errors="coerce"
                            ).mean()
                        ),
                        6,
                    )
                    if len(cohort)
                    else None,
                    "n_with_early_resp_treatment": int(
                        cohort["early_resp_treatment_before_or_at_12h"].sum()
                    )
                    if len(cohort)
                    else 0,
                    "early_resp_treatment_pct": round(
                        float(cohort["early_resp_treatment_before_or_at_12h"].mean())
                        * 100,
                        2,
                    )
                    if len(cohort)
                    else None,
                    "n_invasive_vent_by_12h": int(
                        cohort["invasive_vent_before_or_at_12h"].sum()
                    )
                    if len(cohort)
                    else 0,
                    "invasive_vent_by_12h_pct": round(
                        float(cohort["invasive_vent_before_or_at_12h"].mean()) * 100,
                        2,
                    )
                    if len(cohort)
                    else None,
                }
            )
    return pd.DataFrame(rows)


def summarize_ventilation_outcome(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    eligible = df[df["eligible_12h_new_invasive_vent"]].copy()
    for dataset, dataset_group in eligible.groupby("dataset", sort=False):
        for cohort_col in COHORT_COLUMNS:
            cohort = dataset_group[dataset_group[cohort_col]]
            rows.append(
                {
                    "dataset": dataset,
                    "cohort_definition": cohort_col,
                    "n_eligible_12h_new_invasive_vent": len(cohort),
                    "n_new_invasive_vent_12_48h": int(
                        cohort["new_invasive_vent_12_48h"].sum()
                    ),
                    "event_rate_new_invasive_vent_12_48h": round(
                        float(cohort["new_invasive_vent_12_48h"].mean()),
                        6,
                    )
                    if len(cohort)
                    else None,
                    "n_hospital_deaths": int(
                        pd.to_numeric(cohort["hospital_mortality"], errors="coerce")
                        .fillna(0)
                        .sum()
                    ),
                    "hospital_mortality_rate": round(
                        float(
                            pd.to_numeric(
                                cohort["hospital_mortality"], errors="coerce"
                            ).mean()
                        ),
                        6,
                    )
                    if len(cohort)
                    else None,
                    "n_excluded_already_invasive_vent_by_12h": int(
                        (
                            df["eligible_12h_mortality"]
                            & df[cohort_col]
                            & df["invasive_vent_before_or_at_12h"]
                            & (df["dataset"] == dataset)
                        ).sum()
                    ),
                }
            )
    return pd.DataFrame(rows)


def summarize_source_signals(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for dataset, group in df.groupby("dataset", sort=False):
        rows.append(
            {
                "dataset": dataset,
                "n_eligible_12h_mortality": int(group["eligible_12h_mortality"].sum()),
                "n_early_resp_treatment_before_or_at_12h": int(
                    (
                        group["eligible_12h_mortality"]
                        & group["early_resp_treatment_before_or_at_12h"]
                    ).sum()
                ),
                "n_invasive_vent_before_or_at_12h": int(
                    (
                        group["eligible_12h_mortality"]
                        & group["invasive_vent_before_or_at_12h"]
                    ).sum()
                ),
                "n_new_invasive_vent_12_48h_in_risk_set": int(
                    (
                        group["eligible_12h_new_invasive_vent"]
                        & group["new_invasive_vent_12_48h"]
                    ).sum()
                ),
            }
        )
    return pd.DataFrame(rows)


def main() -> int:
    ensure_dirs()
    backbone = read_backbone()
    with_flags = attach_flags(backbone)

    out_path = OUTPUT_ROOT / "copd_12h_backbone_with_resp_outcomes.csv.gz"
    with_flags.to_csv(out_path, index=False, compression="gzip")

    cohort_summary = summarize_updated_mortality_cohorts(with_flags)
    cohort_summary.to_csv(
        TABLE_ROOT / "copd_12h_cohort_definition_summary_updated.csv",
        index=False,
    )
    cohort_summary.to_csv(
        MANUSCRIPT_TABLE_ROOT / "copd_12h_cohort_definition_summary_updated.csv",
        index=False,
    )

    vent_summary = summarize_ventilation_outcome(with_flags)
    vent_summary.to_csv(
        TABLE_ROOT / "copd_12h_ventilation_outcome_summary.csv",
        index=False,
    )
    vent_summary.to_csv(
        MANUSCRIPT_TABLE_ROOT / "copd_12h_ventilation_outcome_summary.csv",
        index=False,
    )

    source_summary = summarize_source_signals(with_flags)
    source_summary.to_csv(
        TABLE_ROOT / "respiratory_outcome_source_signal_summary.csv",
        index=False,
    )

    print(f"Wrote {out_path}")
    print("\nUpdated mortality cohort definitions:")
    print(cohort_summary.to_string(index=False))
    print("\nNew invasive ventilation outcome:")
    print(vent_summary.to_string(index=False))
    print("\nSource signal summary:")
    print(source_summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
