from __future__ import annotations

from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
FIGURE_ROOT = PROJECT_ROOT / "outputs" / "figures"
FIGURE_DATA_ROOT = PROJECT_ROOT / "outputs" / "figure_data"
METADATA_ROOT = PROJECT_ROOT / "metadata"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"
MANUSCRIPT_FIGURE_ROOT = PROJECT_ROOT / "manuscript" / "figures"
MANUSCRIPT_FIGURE_DATA_ROOT = PROJECT_ROOT / "manuscript" / "figure_data"
INTERMEDIATE_ROOT = PROJECT_ROOT / "data_intermediate"


def ensure_dirs() -> None:
    for path in [
        TABLE_ROOT,
        FIGURE_ROOT,
        FIGURE_DATA_ROOT,
        METADATA_ROOT,
        MANUSCRIPT_TABLE_ROOT,
        MANUSCRIPT_FIGURE_ROOT,
        MANUSCRIPT_FIGURE_DATA_ROOT,
    ]:
        path.mkdir(parents=True, exist_ok=True)


def write_table(df: pd.DataFrame, name: str, also_metadata: bool = False) -> None:
    for root in [TABLE_ROOT, MANUSCRIPT_TABLE_ROOT]:
        out = root / name
        df.to_csv(out, index=False)
        print(f"Wrote {out}")
    if also_metadata:
        out = METADATA_ROOT / name
        df.to_csv(out, index=False)
        print(f"Wrote {out}")


def esc(value: object) -> str:
    return str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def text(x: float, y: float, content: object, size: int = 13, anchor: str = "middle", weight: str = "400") -> str:
    return (
        f'<text x="{x:.1f}" y="{y:.1f}" font-family="Arial, sans-serif" '
        f'font-size="{size}" font-weight="{weight}" text-anchor="{anchor}" fill="#1e2428">{esc(content)}</text>'
    )


def rect(
    x: float,
    y: float,
    w: float,
    h: float,
    fill: str,
    stroke: str = "#2c3940",
    radius: float = 10,
    opacity: float = 1,
) -> str:
    return (
        f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{radius:.1f}" '
        f'fill="{fill}" stroke="{stroke}" stroke-width="1.2" opacity="{opacity}"/>'
    )


def line(x1: float, y1: float, x2: float, y2: float, color: str = "#334047", width: float = 2, dash: str = "") -> str:
    dash_attr = f' stroke-dasharray="{dash}"' if dash else ""
    return (
        f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
        f'stroke="{color}" stroke-width="{width:.1f}"{dash_attr} marker-end="url(#arrow)"/>'
    )


def multiline_text(x: float, y: float, lines: list[str], size: int = 12, anchor: str = "middle", weight: str = "400") -> list[str]:
    parts = []
    for i, item in enumerate(lines):
        parts.append(text(x, y + i * (size + 4), item, size=size, anchor=anchor, weight=weight))
    return parts


def save_svg(name: str, content: str) -> None:
    for root in [FIGURE_ROOT, MANUSCRIPT_FIGURE_ROOT]:
        out = root / name
        out.write_text(content, encoding="utf-8")
        print(f"Wrote {out}")


def save_figure_data(name: str, df: pd.DataFrame) -> None:
    for root in [FIGURE_DATA_ROOT, MANUSCRIPT_FIGURE_DATA_ROOT]:
        out = root / name
        df.to_csv(out, index=False)
        print(f"Wrote {out}")


def build_expanded_taxonomy() -> pd.DataFrame:
    rows = [
        {
            "audit_layer": "A0",
            "short_name": "time-legal reference",
            "definition": "Reference benchmark using predictors measured or known at or before the 12h ICU landmark; explicit post-landmark and administrative proxy variables are excluded.",
            "failure_mechanism": "None by design for landmark-time availability, but residual EHR observation-process effects may remain.",
            "example_predictor_class": "Demographics, pre-landmark vitals, labs, ABG values, SpO2, respiratory rate, and time-stamped respiratory physiology before 12h.",
            "detectability": "Requires timestamp rules, source-table provenance, and predictor-window audit.",
            "expected_metric_artifact": "Baseline discrimination, calibration, and decision utility for comparison with audit variants.",
            "reporting_requirement": "Report landmark, predictor windows, feature provenance, missing-data handling, and external validation metrics.",
            "corrective_action": "Use as the reference model; do not describe as bias-free, only as time-admissible with respect to the landmark.",
        },
        {
            "audit_layer": "A1",
            "short_name": "future-window leakage",
            "definition": "Stress test adding values or trajectories measured after the 12h decision point, usually from 12h to 24h.",
            "failure_mechanism": "Predictors are unavailable when the model is supposed to act; respiratory trajectories may be close to the endpoint.",
            "example_predictor_class": "12-24h ABG, PaCO2, PaO2, pH, FiO2, oxygen flow, SpO2, respiratory rate, and ventilator settings.",
            "detectability": "Compare measurement timestamps and aggregation windows against the landmark.",
            "expected_metric_artifact": "Inflated discrimination, especially for new invasive ventilation where future respiratory deterioration is outcome-proximal.",
            "reporting_requirement": "Report exact predictor time windows and whether any feature window crosses the decision time.",
            "corrective_action": "Exclude from deployable 12h models; analyze only as leakage stress test or redefine the prediction time.",
        },
        {
            "audit_layer": "A3a",
            "short_name": "time-ambiguous diagnosis descriptors",
            "definition": "Diagnostic descriptors or problem-list strings whose availability before 12h cannot be verified reliably.",
            "failure_mechanism": "May encode early clinical impression, later diagnostic clarification, or database documentation timing rather than prospectively available predictors.",
            "example_predictor_class": "eICU diagnosis paths, admission diagnosis strings, past-history descriptors, and non-standard problem-list text.",
            "detectability": "Requires table-level and row-level timestamp audit; if unavailable, classify as time-ambiguous rather than automatically valid.",
            "expected_metric_artifact": "Context-dependent pseudo-performance and limited reproducibility across databases.",
            "reporting_requirement": "Separate time-ambiguous diagnosis from timestamp-verified baseline diagnoses and from discharge/admin coding.",
            "corrective_action": "Exclude from A0 unless prediction-time availability is verified; report sensitivity as A3a.",
        },
        {
            "audit_layer": "A3b",
            "short_name": "administrative/discharge coding proxies",
            "definition": "ICD, DRG, discharge diagnosis, or other administrative fields generated after care episodes or without prospective availability.",
            "failure_mechanism": "Post-hoc coding can encode phenotype, complications, outcome severity, or care pathway information.",
            "example_predictor_class": "COPD, acute respiratory failure, sepsis, shock, do-not-resuscitate, procedure-related ICD, and DRG codes.",
            "detectability": "Identify source as administrative/discharge coding and verify whether it exists only after discharge or billing abstraction.",
            "expected_metric_artifact": "Internal pseudo-performance, phenotype leakage, and external coding-system transport failure.",
            "reporting_requirement": "State whether codes define cohort membership only or enter the prediction model as predictors.",
            "corrective_action": "Use for cohort definition only when justified; do not include as predictors for a 12h landmark model.",
        },
        {
            "audit_layer": "A3c",
            "short_name": "treatment/procedure proxy",
            "definition": "Treatment, procedure, respiratory therapy, medication, or order variables that can encode clinician decisions or downstream deterioration.",
            "failure_mechanism": "Treatment pathways may be consequences of evolving illness and may be post-landmark or outcome-proximal.",
            "example_predictor_class": "Intubation, invasive ventilation, NIV, bronchodilator, steroid, antibiotic, respiratory therapy, and procedure-code strings.",
            "detectability": "Requires timestamp and clinical-role adjudication; legality depends on whether the event occurred before the landmark and is valid for the target decision.",
            "expected_metric_artifact": "Inflated apparent performance and practice-pattern dependent external failure.",
            "reporting_requirement": "Separate baseline treatment status from post-landmark treatment escalation and downstream procedures.",
            "corrective_action": "Exclude post-landmark or outcome-defining treatment variables; analyze pre-landmark treatment as separate sensitivity if clinically justified.",
        },
        {
            "audit_layer": "A5",
            "short_name": "complete-case / required-test selection",
            "definition": "Restricting the benchmark to patients with complete ABG, respiratory labs, or other required measurements.",
            "failure_mechanism": "Measurement availability selects a more monitored and often sicker target population, changing the estimand.",
            "example_predictor_class": "Complete ABG panel, complete respiratory variables, or complete core lab panels required for inclusion.",
            "detectability": "Compare full risk set against selected set using sample size, event rate, respiratory support, measurement counts, and SMDs.",
            "expected_metric_artifact": "May not inflate AUROC but changes event rate, case mix, and clinical target population.",
            "reporting_requirement": "Report full risk set, selected set, event-rate shift, and covariate balance/standardized differences.",
            "corrective_action": "Avoid complete-case cohort definitions when possible; use imputation or missingness-aware modeling and report target-population shift.",
        },
        {
            "audit_layer": "A6",
            "short_name": "measurement-process signal",
            "definition": "Explicit observation-process summaries derived from measurement occurrence, frequency, missingness, or recency rather than measured physiology.",
            "failure_mechanism": "Measurement intensity reflects severity, clinician concern, site workflow, and database documentation practices.",
            "example_predictor_class": "ABG count, lab count, vital count, unique variables observed, missingness count, charting frequency, time since last ABG or SpO2.",
            "detectability": "Classify features by whether they summarize measurement process rather than clinical value.",
            "expected_metric_artifact": "Non-trivial but limited transportable signal; can confound interpretation when mixed with clinical predictors.",
            "reporting_requirement": "Report measurement density features separately and evaluate density-only models or ablation sensitivity.",
            "corrective_action": "Treat as observation-process audit channel; avoid interpreting it as purely biological risk signal.",
        },
        {
            "audit_layer": "A7",
            "short_name": "composite convenience benchmark",
            "definition": "Convenience model combining future-window features, proxy variables, and measurement-process summaries.",
            "failure_mechanism": "Stacks multiple high-risk information channels that may be unavailable, post-hoc, outcome-proximal, or site-dependent.",
            "example_predictor_class": "A1 future respiratory trajectory plus A3 proxy variables plus A6 measurement-density features.",
            "detectability": "Requires full audit taxonomy; high performance alone cannot establish validity.",
            "expected_metric_artifact": "Can yield high internal or even acceptable external AUROC while remaining methodologically inadmissible for the decision point.",
            "reporting_requirement": "Report legality and provenance separately from discrimination, calibration, and DCA.",
            "corrective_action": "Do not use as deployable benchmark; use as stress test demonstrating separation between performance and admissibility.",
        },
    ]
    df = pd.DataFrame(rows)
    write_table(df, "respiratory_audit_taxonomy_expanded.csv", also_metadata=True)
    return df


def classify_proxy_feature(feature: str) -> dict[str, str]:
    lower = feature.lower()
    if lower.startswith("proxy_eicu_dx"):
        proxy_class = "A3a_time_ambiguous_diagnosis"
        source_database = "eICU"
        source_domain = "diagnosis path / diagnostic descriptor"
        available_at_12h = "ambiguous"
        future_generated = "unclear"
        outcome_proximity = "medium; high if respiratory failure or ventilation-related descriptor"
        predictor_admissibility = "exclude from A0 unless prediction-time availability is verified"
        rule = "Diagnostic descriptor exists, but reliable availability before the 12h landmark is not guaranteed."
    elif lower.startswith("proxy_mimic_dx"):
        proxy_class = "A3b_admin_discharge_coding"
        source_database = "MIMIC-IV"
        source_domain = "administrative/discharge diagnosis code"
        available_at_12h = "no"
        future_generated = "yes"
        outcome_proximity = "medium to high depending on code"
        predictor_admissibility = "inadmissible as 12h predictor; may be used only for cohort definition if prespecified"
        rule = "ICD/discharge-level coding is post-hoc or not prospectively available at the landmark."
    elif lower.startswith("proxy_mimic_drg"):
        proxy_class = "A3b_admin_discharge_coding"
        source_database = "MIMIC-IV"
        source_domain = "diagnosis-related group / administrative discharge code"
        available_at_12h = "no"
        future_generated = "yes"
        outcome_proximity = "medium to high because DRGs summarize the completed care episode"
        predictor_admissibility = "inadmissible as 12h predictor; may be used only for administrative description outside the prediction model"
        rule = "DRG/admin coding is discharge-level information and not prospectively available at the landmark."
    elif lower.startswith("proxy_mimic_proc"):
        proxy_class = "A3c_treatment_procedure_proxy"
        source_database = "MIMIC-IV"
        source_domain = "procedure or treatment code"
        available_at_12h = "variable; often no without timestamp adjudication"
        future_generated = "possible"
        outcome_proximity = "high for ventilation/intubation/procedure-related codes"
        predictor_admissibility = "exclude from A0 unless pre-landmark timing and clinical role are verified"
        rule = "Procedure/treatment variables can encode downstream care pathway or outcome-proximal intervention."
    elif lower.startswith("proxy_eicu_tx") or lower.startswith("proxy_eicu_treatment") or lower.startswith("proxy_eicu_proc"):
        proxy_class = "A3c_treatment_procedure_proxy"
        source_database = "eICU"
        source_domain = "treatment/procedure descriptor"
        available_at_12h = "variable; often time-ambiguous"
        future_generated = "possible"
        outcome_proximity = "high for respiratory treatment escalation descriptors"
        predictor_admissibility = "exclude from A0 unless pre-landmark timing and clinical role are verified"
        rule = "Treatment descriptors may encode clinician decisions and site-specific practice rather than baseline state."
    else:
        proxy_class = "A3_unknown_proxy"
        source_database = "unknown"
        source_domain = "proxy feature"
        available_at_12h = "unclear"
        future_generated = "unclear"
        outcome_proximity = "unclear"
        predictor_admissibility = "manual review required"
        rule = "Feature was added by an A3 matrix but does not match the expected proxy naming rules."
    return {
        "proxy_class": proxy_class,
        "source_database": source_database,
        "source_domain": source_domain,
        "available_at_12h": available_at_12h,
        "generated_by_future_care_or_posthoc_process": future_generated,
        "outcome_proximity": outcome_proximity,
        "predictor_admissibility_for_12h_landmark": predictor_admissibility,
        "classification_rule": rule,
    }


def classify_a3c_subtype(feature: str) -> dict[str, str]:
    lower = feature.lower()
    if any(token in lower for token in ["intub", "invasive_vent", "mechanical_ventilation", "0bh17ez", "9604", "9671", "9672"]):
        return {
            "a3c_subtype": "outcome_defining_respiratory_support_proxy",
            "mortality_task_risk": "high",
            "ventilation_task_risk": "extreme",
            "task_specific_admissibility": "Exclude for new-ventilation prediction; for mortality use only if pre-landmark timing and clinical role are explicitly verified.",
            "subtype_rationale": "Intubation or invasive ventilation directly overlaps the ventilation endpoint or downstream respiratory failure pathway.",
        }
    if any(token in lower for token in ["non_invasive_ventilation", "niv", "cpap", "peep", "ventilator_weaning", "tracheal_suctioning"]):
        return {
            "a3c_subtype": "downstream_respiratory_escalation_proxy",
            "mortality_task_risk": "high",
            "ventilation_task_risk": "high",
            "task_specific_admissibility": "Exclude post-landmark records; pre-landmark NIV/CPAP should be analyzed as treatment-intensity sensitivity, not mixed into A0 without justification.",
            "subtype_rationale": "Non-invasive support and ventilator-care descriptors may encode respiratory escalation and clinician treatment pathway.",
        }
    if any(token in lower for token in ["bronchodilator", "albuterol", "ipratropium", "steroid", "antibacterial", "antibiotic", "vancomycin", "piperacil"]):
        return {
            "a3c_subtype": "early_treatment_intensity_indicator",
            "mortality_task_risk": "moderate",
            "ventilation_task_risk": "moderate_to_high",
            "task_specific_admissibility": "Potentially admissible only when confirmed before 12h; report separately because it reflects clinician judgment and site practice.",
            "subtype_rationale": "Medication or antibiotic treatment can be legitimate early care information but also encodes treatment intensity and clinician suspicion.",
        }
    if any(token in lower for token in ["vasopressor", "norepinephrine", "phenylephrine", "pressor", "shock"]):
        return {
            "a3c_subtype": "non_respiratory_treatment_escalation_proxy",
            "mortality_task_risk": "high",
            "ventilation_task_risk": "moderate",
            "task_specific_admissibility": "Use only if pre-landmark timing is verified and the target decision permits treatment-status predictors; otherwise audit as proxy.",
            "subtype_rationale": "Hemodynamic escalation may encode downstream severity and site-specific care pathway.",
        }
    if any(token in lower for token in ["procedure", "catheter", "dialysis", "hemodialysis", "bronchoscopy", "x_ray", "ct_scan", "mri", "ultrasound"]):
        return {
            "a3c_subtype": "downstream_procedure_or_diagnostic_proxy",
            "mortality_task_risk": "moderate_to_high",
            "ventilation_task_risk": "moderate_to_high",
            "task_specific_admissibility": "Exclude if post-landmark or time-ambiguous; include only as a prespecified sensitivity if timing and clinical role are verified.",
            "subtype_rationale": "Procedures and diagnostics may reflect evolving illness, workup intensity, and downstream care processes.",
        }
    return {
        "a3c_subtype": "general_treatment_or_care_process_indicator",
        "mortality_task_risk": "moderate",
        "ventilation_task_risk": "moderate",
        "task_specific_admissibility": "Not uniformly inadmissible; requires timestamp verification and should be separated from outcome-defining respiratory support proxies.",
        "subtype_rationale": "Treatment/care-process descriptor may reflect early care intensity or site workflow rather than a purely baseline clinical state.",
    }


def build_a3_variable_provenance_appendix() -> pd.DataFrame:
    manifest = pd.read_csv(TABLE_ROOT / "copd_model_matrix_manifest.csv")
    rows = []
    for task in sorted(manifest["task"].unique()):
        base_row = manifest[(manifest["task"].eq(task)) & (manifest["audit_variant"].eq("A0_clean"))]
        if base_row.empty:
            continue
        base_cols = set(pd.read_csv(PROJECT_ROOT / base_row.iloc[0]["path"], nrows=0).columns)
        for audit_variant in [
            "A3a_time_ambiguous_diagnosis",
            "A3b_admin_coding",
            "A3c_procedure_treatment",
            "A3_all_proxies",
            "A7_composite_convenience",
        ]:
            audit_row = manifest[(manifest["task"].eq(task)) & (manifest["audit_variant"].eq(audit_variant))]
            if audit_row.empty:
                continue
            audit_cols = list(pd.read_csv(PROJECT_ROOT / audit_row.iloc[0]["path"], nrows=0).columns)
            added = [col for col in audit_cols if col not in base_cols and col.startswith("proxy_")]
            for col in added:
                details = classify_proxy_feature(col)
                subtype = classify_a3c_subtype(col) if details["proxy_class"] == "A3c_treatment_procedure_proxy" else {
                    "a3c_subtype": "",
                    "mortality_task_risk": "",
                    "ventilation_task_risk": "",
                    "task_specific_admissibility": "",
                    "subtype_rationale": "",
                }
                rows.append(
                    {
                        "task": task,
                        "audit_variant_where_added": audit_variant,
                        "feature_name": col,
                        **details,
                        **subtype,
                    }
                )
    df = pd.DataFrame(rows).drop_duplicates()
    class_order = {
        "A3a_time_ambiguous_diagnosis": 1,
        "A3b_admin_discharge_coding": 2,
        "A3c_treatment_procedure_proxy": 3,
        "A3_unknown_proxy": 9,
    }
    df["_class_order"] = df["proxy_class"].map(class_order).fillna(9)
    df = df.sort_values(["task", "_class_order", "audit_variant_where_added", "feature_name"]).drop(columns=["_class_order"])
    write_table(df, "copd_a3_variable_level_provenance_appendix.csv")
    return df


def build_a3c_admissibility_subtyping_table() -> pd.DataFrame:
    rows = [
        {
            "a3c_subtype": "early_treatment_intensity_indicator",
            "example_features": "pre-landmark bronchodilator steroid antibiotic oxygen therapy",
            "mortality_task_interpretation": "May be clinically legitimate if timestamped before 12h, but reflects clinician judgment and treatment intensity.",
            "ventilation_task_interpretation": "May be legitimate if before 12h, but can be closer to the escalation pathway than baseline physiology.",
            "risk_level": "moderate",
            "recommended_handling": "Do not treat as uniformly inadmissible; separate from A0 unless timing and clinical role are verified, then use as sensitivity.",
        },
        {
            "a3c_subtype": "downstream_respiratory_escalation_proxy",
            "example_features": "NIV CPAP PEEP ventilator weaning tracheal suctioning respiratory therapy strings",
            "mortality_task_interpretation": "High-risk severity and care-pathway proxy, especially if time-ambiguous or post-landmark.",
            "ventilation_task_interpretation": "High-risk because it may precede or substitute for invasive ventilation escalation.",
            "risk_level": "high",
            "recommended_handling": "Exclude post-landmark records; if pre-landmark, analyze separately as respiratory treatment-intensity sensitivity.",
        },
        {
            "a3c_subtype": "outcome_defining_respiratory_support_proxy",
            "example_features": "intubation invasive ventilation mechanical ventilation procedure codes",
            "mortality_task_interpretation": "High-risk downstream severity marker unless clearly pre-landmark baseline status.",
            "ventilation_task_interpretation": "Outcome proxy for new invasive ventilation prediction and should be excluded from predictors.",
            "risk_level": "extreme for ventilation task",
            "recommended_handling": "Exclude from A0 and from deployable ventilation models; use only in A3c/A7 stress tests.",
        },
        {
            "a3c_subtype": "downstream_procedure_or_diagnostic_proxy",
            "example_features": "bronchoscopy chest x-ray CT ultrasound catheter dialysis procedure strings",
            "mortality_task_interpretation": "May encode evolving illness, diagnostic workup, or downstream care intensity.",
            "ventilation_task_interpretation": "May encode workup or procedures near respiratory deterioration.",
            "risk_level": "moderate_to_high",
            "recommended_handling": "Require timestamp and role adjudication; otherwise exclude from A0 and audit as proxy.",
        },
        {
            "a3c_subtype": "non_respiratory_treatment_escalation_proxy",
            "example_features": "vasopressor norepinephrine phenylephrine shock treatment strings",
            "mortality_task_interpretation": "High-risk severity proxy for mortality if downstream or time-ambiguous.",
            "ventilation_task_interpretation": "Moderate risk as general critical illness treatment pathway signal.",
            "risk_level": "moderate_to_high",
            "recommended_handling": "Use only if pre-landmark timing is verified and treatment-status predictors are prespecified.",
        },
    ]
    df = pd.DataFrame(rows)
    write_table(df, "copd_a3c_task_specific_admissibility_subtypes.csv", also_metadata=True)
    return df


def build_endpoint_harmonization_table() -> pd.DataFrame:
    mortality = pd.read_csv(TABLE_ROOT / "copd_12h_cohort_definition_summary_updated.csv")
    ventilation = pd.read_csv(TABLE_ROOT / "copd_12h_ventilation_outcome_summary.csv")

    rows = []
    for _, row in mortality.iterrows():
        rows.append(
            {
                "task": "in-hospital mortality after 12h",
                "dataset": row["dataset"],
                "cohort_definition": row["cohort_definition"],
                "risk_set_n": int(row["n_eligible_12h_mortality"]) if pd.notna(row["n_eligible_12h_mortality"]) else 0,
                "events": int(row["n_hospital_deaths_after_landmark"]) if pd.notna(row["n_hospital_deaths_after_landmark"]) else 0,
                "event_rate": row["event_rate_after_landmark"],
                "endpoint_source": "hospital discharge status and survival through the 12h landmark",
                "timestamp_rule": "patients must be alive and in the ICU risk set at 12h; deaths after 12h count as events",
                "harmonization_caveat": "Mortality is more stable than respiratory treatment endpoints, but discharge practices and hospital-transfer capture can still differ by database.",
                "interpretation_guardrail": "Use as the hard endpoint reference; still report external calibration and prevalence-referenced AUPRC.",
            }
        )

    for _, row in ventilation.iterrows():
        dataset = row["dataset"]
        if dataset == "MIMIC-IV":
            source = "procedureevents itemids 224385 intubation and 225792 invasive ventilation"
            timestamp = "procedure event time compared with ICU admission; patients already invasively ventilated by 12h excluded"
            caveat = "Procedure-event capture differs from eICU respiratory-care documentation; event rates are higher in MIMIC-IV."
        else:
            source = "respiratoryCare airway descriptors and respiratoryCharting RT Vent On/Off supporting evidence"
            timestamp = "respcarestatusoffset and charting offsets compared with ICU admission; ventstartoffset=0 treated as ambiguous rather than automatic baseline ventilation"
            caveat = "eICU events are rare and source definitions are less directly harmonized with MIMIC-IV procedure events."
        rows.append(
            {
                "task": "new invasive mechanical ventilation 12-48h",
                "dataset": dataset,
                "cohort_definition": row["cohort_definition"],
                "risk_set_n": int(row["n_eligible_12h_new_invasive_vent"]) if pd.notna(row["n_eligible_12h_new_invasive_vent"]) else 0,
                "events": int(row["n_new_invasive_vent_12_48h"]) if pd.notna(row["n_new_invasive_vent_12_48h"]) else 0,
                "event_rate": row["event_rate_new_invasive_vent_12_48h"],
                "endpoint_source": source,
                "timestamp_rule": timestamp,
                "harmonization_caveat": caveat,
                "interpretation_guardrail": "Interpret AUPRC, calibration, and DCA in light of low eICU event prevalence and endpoint ascertainment differences; do not attribute all external failure to model design alone.",
            }
        )

    df = pd.DataFrame(rows)
    if "event_rate" in df:
        df["event_rate"] = pd.to_numeric(df["event_rate"], errors="coerce").round(6)
    write_table(df, "copd_endpoint_harmonization_and_event_rate_caveats.csv")
    return df


def build_cohort_role_table() -> pd.DataFrame:
    rows = [
        {
            "cohort_definition": "C1_discharge_icd_copd",
            "analysis_role": "primary",
            "main_text_handling": "Primary broad COPD/AECOPD cohort for mortality and ventilation analyses.",
            "rationale": "Available in both MIMIC-IV and eICU with sufficient sample size and directly comparable external validation.",
            "caveat": "Discharge ICD is a post-hoc phenotype source; this is a cohort-definition limitation, not a predictor admissibility claim.",
        },
        {
            "cohort_definition": "C2_copd_acute_respiratory_failure",
            "analysis_role": "primary",
            "main_text_handling": "Primary severity-enriched respiratory cohort.",
            "rationale": "Tests whether audit signatures persist in a clinically higher-risk COPD/respiratory failure subset.",
            "caveat": "Acute respiratory failure coding may enrich severity using post-hoc diagnosis; interpret as benchmark phenotype audit.",
        },
        {
            "cohort_definition": "C3_treatment_enriched_copd",
            "analysis_role": "supplementary sensitivity",
            "main_text_handling": "Mention only briefly; keep detailed results in Supplementary material.",
            "rationale": "Useful for demonstrating treatment-defined phenotype bias and site-process dependence.",
            "caveat": "Treatment-enriched cohort is influenced by care pathways and should not be presented as an equal primary cohort.",
        },
        {
            "cohort_definition": "C4_convenience_copd",
            "analysis_role": "supplementary failure demonstration",
            "main_text_handling": "Use as a convenience-benchmark stress test, not as a primary cohort.",
            "rationale": "Emulates permissive literature-style COPD definitions and demonstrates maximal cohort-definition pseudo-performance risk.",
            "caveat": "Can look like a deliberately biased cohort if overemphasized; avoid equal weighting with C1/C2 in the main narrative.",
        },
    ]
    df = pd.DataFrame(rows)
    write_table(df, "copd_cohort_main_vs_supplementary_roles.csv", also_metadata=True)
    return df


def build_scoping_audit_boundary_statement() -> pd.DataFrame:
    rows = [
        {
            "section": "Methods",
            "recommended_text": "We performed a contextual scoping audit of representative COPD/AECOPD and respiratory ICU prediction benchmarks. This audit was not designed as a PRISMA systematic review and was not used to estimate field-wide prevalence of design risks.",
        },
        {
            "section": "Results",
            "recommended_text": "Among the audited studies, several design features targeted by the framework were present or insufficiently auditable from the published report, including ambiguous predictor windows, proxy variables, complete-case or required-test selection, measurement-process features, and incomplete transportability reporting.",
        },
        {
            "section": "Discussion",
            "recommended_text": "The literature audit should be interpreted as contextual evidence that these risks occur in published respiratory ICU benchmarks, not as proof of their frequency across the entire field.",
        },
        {
            "section": "Limitations",
            "recommended_text": "Because the contextual audit was intentionally bounded and not a formal systematic review, conclusions about prevalence, citation-weighted impact, or comparative quality of individual studies are outside the scope of this work.",
        },
    ]
    df = pd.DataFrame(rows)
    write_table(df, "copd_literature_scoping_audit_boundary_statements.csv", also_metadata=True)
    return df


def build_admissibility_diagram() -> pd.DataFrame:
    rows = [
        {
            "stage": "Prediction target",
            "label": "12h ICU decision point",
            "status": "anchor",
            "interpretation": "All predictor availability is judged relative to this decision time.",
        },
        {
            "stage": "Admissible predictors",
            "label": "A0: pre-landmark clinical variables",
            "status": "admissible reference",
            "interpretation": "Time-stamped demographics, vitals, labs, and respiratory physiology observed by 12h.",
        },
        {
            "stage": "Future-window risk",
            "label": "A1: 12-24h trajectory",
            "status": "inadmissible for 12h",
            "interpretation": "Unavailable at the decision point and outcome-proximal for ventilation.",
        },
        {
            "stage": "Proxy risk",
            "label": "A3: diagnosis/admin/procedure/treatment proxies",
            "status": "time-ambiguous or post hoc",
            "interpretation": "Requires provenance adjudication; not a variable blacklist.",
        },
        {
            "stage": "Observation process",
            "label": "A6: measurement density",
            "status": "process-dependent",
            "interpretation": "Carries non-trivial but workflow-dependent risk signal.",
        },
        {
            "stage": "Target population",
            "label": "A5: ABG complete-case filter",
            "status": "estimand shift",
            "interpretation": "Changes the benchmark population before performance is interpreted.",
        },
        {
            "stage": "Composite stress test",
            "label": "A7: stacked convenience benchmark",
            "status": "inadmissible stress test",
            "interpretation": "Performance can be statistically acceptable while clinically non-actionable.",
        },
    ]
    df = pd.DataFrame(rows)
    save_figure_data("figure_0_predictor_admissibility_diagram_source.csv", df)

    width, height = 1180, 640
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#334047"/></marker></defs>',
        '<rect x="0" y="0" width="1180" height="640" fill="#fbfaf6"/>',
        text(590, 42, "Predictor Admissibility Audit for a 12h COPD/AECOPD ICU Benchmark", 22, weight="700"),
        text(590, 70, "The validity target is decision-time admissibility, not AUROC alone", 14, weight="400"),
        rect(455, 105, 270, 78, "#f7e2a7", "#936f1d", radius=16),
        *multiline_text(590, 133, ["12h ICU decision point", "prediction-time anchor"], size=15, weight="700"),
        line(590, 183, 590, 235, color="#936f1d", width=2.2),
        rect(365, 235, 450, 82, "#d7ece7", "#1f6f78", radius=14),
        *multiline_text(590, 262, ["A0 time-legal reference", "pre-landmark demographics, vitals, labs, ABG, SpO2, RR"], size=13, weight="700"),
        line(365, 276, 235, 276, color="#c85a3d", width=2),
        rect(55, 232, 180, 88, "#f4c7b8", "#a53c25", radius=14),
        *multiline_text(145, 260, ["A1 future window", "12-24h respiratory", "trajectory"], size=12, weight="700"),
        line(815, 276, 945, 276, color="#7851a9", width=2),
        rect(945, 220, 190, 112, "#dfd2f0", "#6a4698", radius=14),
        *multiline_text(1040, 250, ["A3 proxy fields", "diagnosis/admin", "procedure/treatment", "provenance required"], size=12, weight="700"),
        line(500, 317, 390, 410, color="#b8902d", width=2),
        rect(155, 410, 235, 95, "#f2dfaa", "#8e6e1b", radius=14),
        *multiline_text(272.5, 440, ["A6 observation process", "counts, missingness,", "frequency, recency"], size=12, weight="700"),
        line(680, 317, 790, 410, color="#566556", width=2),
        rect(790, 410, 235, 95, "#d7dfd3", "#526052", radius=14),
        *multiline_text(907.5, 440, ["A5 target selection", "ABG complete-case", "estimand shift"], size=12, weight="700"),
        line(590, 317, 590, 505, color="#932f2f", width=2.2),
        rect(390, 505, 400, 80, "#e9b8b5", "#842929", radius=14),
        *multiline_text(590, 532, ["A7 composite convenience benchmark", "can perform externally while remaining inadmissible"], size=13, weight="700"),
        text(145, 344, "Unavailable at 12h; outcome-proximal for ventilation", 12, anchor="middle"),
        text(1040, 358, "Not a blacklist: adjudicate source, timing, and clinical role", 12, anchor="middle"),
        text(272.5, 530, "Workflow-dependent signal", 12, anchor="middle"),
        text(907.5, 530, "Changes the target population", 12, anchor="middle"),
        "</svg>",
    ]
    svg = "\n".join(parts)
    save_svg("figure_0_predictor_admissibility_diagram.svg", svg)
    return df


def build_hardening_manifest() -> pd.DataFrame:
    rows = [
        {
            "asset": "expanded audit taxonomy",
            "path": "outputs/tables/respiratory_audit_taxonomy_expanded.csv",
            "purpose": "Turns A0-A7 from internal model-version labels into a reusable benchmark-governance framework.",
        },
        {
            "asset": "A3 variable-level provenance appendix",
            "path": "outputs/tables/copd_a3_variable_level_provenance_appendix.csv",
            "purpose": "Documents proxy-feature source, timing availability, future-generation risk, outcome proximity, and admissibility.",
        },
        {
            "asset": "endpoint harmonization and event-rate caveats",
            "path": "outputs/tables/copd_endpoint_harmonization_and_event_rate_caveats.csv",
            "purpose": "Separates model failure from endpoint ascertainment, low prevalence, and database-harmonization risks.",
        },
        {
            "asset": "A3c task-specific admissibility subtypes",
            "path": "outputs/tables/copd_a3c_task_specific_admissibility_subtypes.csv",
            "purpose": "Separates outcome-defining respiratory support proxies from early treatment-intensity indicators.",
        },
        {
            "asset": "cohort main/supplementary role table",
            "path": "outputs/tables/copd_cohort_main_vs_supplementary_roles.csv",
            "purpose": "Keeps C1/C2 as primary cohorts and confines C3/C4 to supplementary sensitivity or stress-test roles.",
        },
        {
            "asset": "scoping audit boundary statements",
            "path": "outputs/tables/copd_literature_scoping_audit_boundary_statements.csv",
            "purpose": "Prevents the contextual literature audit from being misrepresented as a PRISMA systematic review.",
        },
        {
            "asset": "predictor admissibility diagram",
            "path": "outputs/figures/figure_0_predictor_admissibility_diagram.svg",
            "purpose": "Conceptual main figure candidate showing 12h decision-time legality, future leakage, proxy fields, observation process, and target selection.",
        },
    ]
    df = pd.DataFrame(rows)
    write_table(df, "copd_submission_hardening_asset_manifest.csv")
    return df


def main() -> None:
    ensure_dirs()
    build_expanded_taxonomy()
    build_a3_variable_provenance_appendix()
    build_a3c_admissibility_subtyping_table()
    build_cohort_role_table()
    build_scoping_audit_boundary_statement()
    build_endpoint_harmonization_table()
    build_admissibility_diagram()
    build_hardening_manifest()


if __name__ == "__main__":
    main()
