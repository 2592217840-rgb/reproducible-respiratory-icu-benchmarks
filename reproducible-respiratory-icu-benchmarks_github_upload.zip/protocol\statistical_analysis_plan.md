# Statistical analysis plan

## Overview

This analysis compares prespecified COPD/AECOPD ICU benchmark variants against a 12-hour time-legal reference. The main outputs are changes in discrimination, calibration, decision-curve net benefit, target-population composition, and MIMIC-IV to eICU external validation.

## Development and Validation

- Development/internal validation: MIMIC-IV.
- External validation: eICU-CRD.
- Primary split in MIMIC-IV: temporal split if calendar information supports stable splitting; otherwise random train/internal validation split stratified by outcome.
- External validation: models trained in MIMIC-IV are transported to eICU without retraining.

## Primary Contrasts

For each task, cohort definition, model family, and metric:

```text
delta = audit_variant - A0_respiratory_clean_reference
```

Primary audit variants:

- A1 vs A0.
- A3a/A3b/A3c/A3-all vs A0.
- A5 vs A0.
- A6 vs A0.
- A7 vs A0.

Primary cohort analyses will be restricted to C1 discharge-ICD COPD and C2
COPD plus acute respiratory failure. C3 treatment-enriched COPD and C4
convenience COPD are supplementary sensitivity cohorts and
are not interpreted as equal primary populations.

## Metrics

Discrimination:

- AUROC.
- AUPRC.
- Prevalence-referenced AUPRC ratio.

Calibration:

- Brier score.
- Calibration intercept.
- Calibration slope.
- Integrated calibration index / Eavg when estimable.

Decision utility:

- Threshold-specific net benefit.

Transportability:

- Internal-external AUROC gap.
- Internal-external calibration slope change.
- Failure phenotype map.

## Decision Curve Thresholds

Mortality:

- 5%, 10%, 15%, 20%, 30%.

Invasive mechanical ventilation initiation:

- 5%, 10%, 20%, 30%, 40%.

Thresholds may be adjusted after event-rate estimation, but the final analysis must report the event rate and justify any changes.

## Complete-Case / Selection Analysis

A5 is interpreted primarily as a target-population and estimand-shift audit. For full risk set versus ABG/lab complete-case set, report:

- N.
- Events.
- Event rate.
- Age.
- Sex.
- ICU type.
- Invasive ventilation before landmark.
- NIV or oxygen therapy before landmark where available.
- ABG count.
- SpO2 measurement count.
- Respiratory rate measurement count.
- Lab count.
- Vital count.
- Observed variable count.
- Missing variable count.
- Standardized mean differences.

## Measurement-Density Mechanism Analysis

A6 must include an explicit density-only model:

- ABG count.
- SpO2 count.
- Respiratory rate count.
- Lab measurement count.
- Vital measurement count.
- Unique observed respiratory variables.
- Missing respiratory variable count.
- Time since last ABG or SpO2 where available.

The density-only model tests whether observation-process signals are internally predictive and externally unstable.

## Uncertainty

- Use stay-level bootstrap for confidence intervals because only one ICU stay per patient is retained.
- Use paired bootstrap for A0 versus audit-variant deltas.
- Report uncertainty for AUROC, AUPRC, Brier score, calibration slope, and key DCA thresholds when available.
- If DCA uncertainty is not computed in the first manuscript version, label DCA comparisons exploratory.

## Interpretation Rules

Do not claim that any one audit mechanism causally explains all MIMIC-to-eICU transport failure. Use comparative language:

```text
Compared with A0 under the same development-validation design, audit variants produced failure patterns consistent with non-transportable or inadmissible information channels.
```

External AUROC retention does not establish benchmark admissibility if predictors are not valid at the stated prediction time.

A3c treatment/procedure proxies are not a uniform exclusion category. The
analysis distinguishes outcome-defining respiratory support proxies, downstream
procedure proxies, and early treatment-intensity indicators. Verified
pre-landmark bronchodilator, steroid, or antibiotic use may be clinically
admissible in some settings but should be reported separately because it can
encode clinician judgment and site-specific treatment practice.

The published benchmark audit is contextual/scoping only. It is not a PRISMA
systematic review and must not be used to estimate the prevalence of design
risks across the full COPD or respiratory ICU prediction literature.
