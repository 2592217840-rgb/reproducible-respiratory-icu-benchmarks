# Task specifications

## Shared Rules

- Unit of analysis: ICU stay.
- Development database: MIMIC-IV.
- External validation database: eICU-CRD.
- Primary landmark: ICU admission + 12 hours.
- Clean feature window: ICU admission through the landmark.
- Patients with the target event before or at the landmark are excluded from the corresponding risk set.
- Untimestamped post hoc administrative fields are excluded from A0.
- Time-ambiguous diagnosis, procedure, treatment, and administrative descriptors are audited separately.

## Task 1: COPD/AECOPD 12h Landmark In-Hospital Mortality

### Clinical use case

Post-landmark in-hospital mortality after an early ICU decision point.

### Eligible Population

Adult ICU stays satisfying a pre-specified COPD/AECOPD cohort definition and alive at the 12h landmark.

### Time Zero

ICU admission time.

### Prediction Time

12 hours after ICU admission.

### Outcome

In-hospital death after the 12h landmark.

### Forbidden A0 Predictors

- Hospital discharge status or location.
- ICU discharge information.
- Discharge ICD or DRG codes.
- Acute respiratory failure discharge/admin codes.
- Procedure or treatment records occurring after the landmark.
- Post-landmark ventilation, NIV, oxygen escalation, steroid, bronchodilator, antibiotic, or vasopressor treatment.
- ABG, SpO2, respiratory rate, or oxygen-flow summaries whose aggregation window crosses the landmark.

## Task 2: COPD/AECOPD 12h Landmark Invasive Mechanical Ventilation Initiation

### Clinical use case

New invasive ventilation after the 12-hour landmark among patients not already invasively ventilated.

### Eligible Population

Adult COPD/AECOPD ICU stays alive at 12h and not receiving invasive mechanical ventilation before or at the 12h landmark. Patients already invasively ventilated before 12h are excluded from this task's risk set.

### Time Zero

ICU admission time.

### Prediction Time

12 hours after ICU admission.

### Outcome

New invasive mechanical ventilation initiation between 12h and 48h after ICU admission.

### Sensitivity Horizon

New invasive mechanical ventilation initiation between 12h and 72h.

### Forbidden A0 Predictors

- Post-landmark invasive ventilation records.
- Post-landmark intubation/procedure events.
- Post-landmark respiratory therapy treatment strings.
- Post-landmark ABG/oxygenation trends.
- Procedure codes or billing codes reflecting ventilation.
- Medication or treatment orders that occur after the landmark and encode respiratory deterioration.

## Optional Task 3: Respiratory Treatment Escalation

### Outcome

Composite of new invasive mechanical ventilation, vasopressor initiation, or ICU death after the 12h landmark.

### Role

Sensitivity analysis only. It is not a replacement for the two primary tasks.

## Implementation Order

1. Readiness and source feasibility scan.
2. COPD/AECOPD cohort definition C0-C4 in MIMIC-IV and eICU.
3. Task 1 mortality risk set and A0 feature matrix.
4. Task 2 invasive ventilation initiation risk set and A0 feature matrix.
5. A1/A3/A5/A6/A7 audit variants.
6. Logistic regression, density-only, and XGBoost models.
7. Calibration, DCA, failure phenotype map, and manuscript tables.
