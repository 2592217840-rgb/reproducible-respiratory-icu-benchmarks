from __future__ import annotations

from pathlib import Path

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_ROOT = PROJECT_ROOT.parent
ICU_AUDIT_ROOT = DATA_ROOT / "icu_bias_audit"
MIMIC_ROOT = DATA_ROOT / "mimic-iv-3.1" / "mimic-iv-3.1"
EICU_ROOT = (
    DATA_ROOT
    / "eicu-collaborative-research-database-2.0"
    / "eicu-collaborative-research-database-2.0"
)

COPD_OUTCOME_PATH = (
    PROJECT_ROOT / "data_intermediate" / "copd_12h_backbone_with_resp_outcomes.csv.gz"
)
OUTPUT_ROOT = PROJECT_ROOT / "data_intermediate"
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"

LANDMARK_MINUTES = 12 * 60

COHORT_COLUMNS = [
    "c0_conservative_copd",
    "c1_discharge_icd_copd",
    "c2_copd_acute_respiratory_failure",
    "c3_treatment_enriched_copd",
    "c4_convenience_copd",
]

TASKS = {
    "mortality": {
        "eligible_col": "eligible_12h_mortality",
        "outcome_col": "hospital_mortality",
        "output_prefix": "copd_mortality_12h",
    },
    "ventilation": {
        "eligible_col": "eligible_12h_new_invasive_vent",
        "outcome_col": "new_invasive_vent_12_48h",
        "output_prefix": "copd_new_invasive_ventilation_12h",
    },
}

ICU_FEATURE_VARIANTS = {
    "A0_clean": ICU_AUDIT_ROOT
    / "data_intermediate"
    / "mortality_12h_clean_features.csv.gz",
    "A1_future_window_24h": ICU_AUDIT_ROOT
    / "data_intermediate"
    / "mortality_12h_A1_future_window_24h_features.csv.gz",
    "A3a_time_ambiguous_diagnosis": ICU_AUDIT_ROOT
    / "data_intermediate"
    / "mortality_12h_A3a_time_ambiguous_diagnosis_features.csv.gz",
    "A3b_admin_coding": ICU_AUDIT_ROOT
    / "data_intermediate"
    / "mortality_12h_A3b_admin_coding_features.csv.gz",
    "A3c_procedure_treatment": ICU_AUDIT_ROOT
    / "data_intermediate"
    / "mortality_12h_A3c_procedure_treatment_features.csv.gz",
    "A3_all_proxies": ICU_AUDIT_ROOT
    / "data_intermediate"
    / "mortality_12h_A3_proxy_features.csv.gz",
    "A7_composite_convenience": ICU_AUDIT_ROOT
    / "data_intermediate"
    / "mortality_12h_A7_composite_convenience_features.csv.gz",
}

MIMIC_ABG_ITEM_MAP = {
    50818: "paco2",
    50820: "ph",
    50821: "pao2",
}
EICU_ABG_NAME_MAP = {
    "paco2": "paco2",
    "ph": "ph",
    "pao2": "pao2",
}
ABG_FEATURES = ["paco2", "ph", "pao2"]


def ensure_dirs() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    TABLE_ROOT.mkdir(parents=True, exist_ok=True)
    MANUSCRIPT_TABLE_ROOT.mkdir(parents=True, exist_ok=True)


def read_copd_outcomes() -> pd.DataFrame:
    df = pd.read_csv(COPD_OUTCOME_PATH, compression="gzip", low_memory=False)
    for col in ["icu_admit_time", "landmark_time"]:
        df[col] = pd.to_datetime(df[col], errors="coerce")
    df["icu_stay_id"] = df["icu_stay_id"].astype(str)
    df["hospital_admission_id"] = df["hospital_admission_id"].astype(str)
    for col in COHORT_COLUMNS:
        df[col] = df[col].fillna(False).astype(bool)
    target = df[COHORT_COLUMNS].any(axis=1)
    eligible_any_task = df[[spec["eligible_col"] for spec in TASKS.values()]].any(axis=1)
    keep_cols = [
        "dataset",
        "patient_id",
        "hospital_admission_id",
        "icu_stay_id",
        "icu_admit_time",
        "landmark_time",
        "hospital_mortality",
        "eligible_12h_mortality",
        "eligible_12h_new_invasive_vent",
        "new_invasive_vent_12_48h",
        "invasive_vent_before_or_at_12h",
        "early_resp_treatment_before_or_at_12h",
    ] + COHORT_COLUMNS
    return df.loc[target & eligible_any_task, keep_cols].copy()


def build_abg_availability(copd: pd.DataFrame) -> pd.DataFrame:
    cache_path = OUTPUT_ROOT / "copd_12h_abg_availability.csv.gz"
    if cache_path.exists():
        return pd.read_csv(cache_path, compression="gzip", dtype={"icu_stay_id": str})

    base = copd[["dataset", "hospital_admission_id", "icu_stay_id", "icu_admit_time"]].copy()
    rows: list[pd.DataFrame] = []

    mimic = base[base["dataset"].eq("MIMIC-IV")].copy()
    if not mimic.empty:
        mimic_lookup = mimic[["hospital_admission_id", "icu_stay_id", "icu_admit_time"]].drop_duplicates()
        mimic_lookup["hadm_id"] = pd.to_numeric(
            mimic_lookup["hospital_admission_id"], errors="coerce"
        ).astype("Int64")
        mimic_lookup = mimic_lookup.dropna(subset=["hadm_id"])
        hadm_ids = set(mimic_lookup["hadm_id"].astype(int))
        itemids = set(MIMIC_ABG_ITEM_MAP)
        for chunk in pd.read_csv(
            MIMIC_ROOT / "hosp" / "labevents.csv.gz",
            compression="gzip",
            usecols=["hadm_id", "charttime", "itemid", "valuenum"],
            chunksize=1_000_000,
            low_memory=False,
        ):
            chunk = chunk[chunk["hadm_id"].isin(hadm_ids) & chunk["itemid"].isin(itemids)].copy()
            if chunk.empty:
                continue
            chunk = chunk.merge(mimic_lookup, on="hadm_id", how="inner")
            chunk["charttime"] = pd.to_datetime(chunk["charttime"], errors="coerce")
            chunk["offset_minutes"] = (
                chunk["charttime"] - chunk["icu_admit_time"]
            ).dt.total_seconds() / 60
            chunk = chunk[chunk["offset_minutes"].between(0, LANDMARK_MINUTES, inclusive="both")]
            if chunk.empty:
                continue
            rows.append(
                pd.DataFrame(
                    {
                        "dataset": "MIMIC-IV",
                        "icu_stay_id": chunk["icu_stay_id"].astype(str),
                        "abg_feature": chunk["itemid"].map(MIMIC_ABG_ITEM_MAP),
                    }
                )
            )

    eicu = base[base["dataset"].eq("eICU")].copy()
    if not eicu.empty:
        eicu_ids = set(pd.to_numeric(eicu["icu_stay_id"], errors="coerce").dropna().astype(int))
        lab_names = set(EICU_ABG_NAME_MAP)
        for chunk in pd.read_csv(
            EICU_ROOT / "lab.csv.gz",
            compression="gzip",
            usecols=["patientunitstayid", "labresultoffset", "labname", "labresult"],
            chunksize=1_000_000,
            low_memory=False,
        ):
            chunk["labname_norm"] = chunk["labname"].fillna("").str.strip().str.lower()
            chunk = chunk[
                chunk["patientunitstayid"].isin(eicu_ids)
                & chunk["labname_norm"].isin(lab_names)
                & chunk["labresultoffset"].between(0, LANDMARK_MINUTES, inclusive="both")
            ].copy()
            if chunk.empty:
                continue
            rows.append(
                pd.DataFrame(
                    {
                        "dataset": "eICU",
                        "icu_stay_id": chunk["patientunitstayid"].astype(str),
                        "abg_feature": chunk["labname_norm"].map(EICU_ABG_NAME_MAP),
                    }
                )
            )

    out = base[["dataset", "icu_stay_id"]].drop_duplicates().copy()
    if rows:
        long = pd.concat(rows, ignore_index=True).dropna(subset=["abg_feature"])
        counts = (
            long.groupby(["dataset", "icu_stay_id", "abg_feature"])
            .size()
            .unstack(fill_value=0)
            .reset_index()
        )
        out = out.merge(counts, on=["dataset", "icu_stay_id"], how="left")
    for feature in ABG_FEATURES:
        if feature not in out:
            out[feature] = 0
        out[f"a5_abg_{feature}_observed"] = out[feature].fillna(0).gt(0)
        out[f"a5_abg_{feature}_count"] = out[feature].fillna(0).astype(int)
        out = out.drop(columns=[feature])
    out["a5_abg_any"] = out[[f"a5_abg_{f}_observed" for f in ABG_FEATURES]].any(axis=1)
    out["a5_abg_complete"] = out[[f"a5_abg_{f}_observed" for f in ABG_FEATURES]].all(axis=1)
    out["a5_abg_measurement_count"] = out[[f"a5_abg_{f}_count" for f in ABG_FEATURES]].sum(axis=1)
    out.to_csv(cache_path, index=False, compression="gzip")
    return out


def load_icu_feature_matrix(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, compression="gzip", low_memory=False, dtype={"icu_stay_id": str})
    df["icu_stay_id"] = df["icu_stay_id"].astype(str)
    return df


def add_copd_context(features: pd.DataFrame, copd: pd.DataFrame, abg: pd.DataFrame) -> pd.DataFrame:
    context_cols = [
        "dataset",
        "icu_stay_id",
        "eligible_12h_mortality",
        "eligible_12h_new_invasive_vent",
        "new_invasive_vent_12_48h",
        "invasive_vent_before_or_at_12h",
        "early_resp_treatment_before_or_at_12h",
    ] + COHORT_COLUMNS
    merged = features.merge(copd[context_cols], on=["dataset", "icu_stay_id"], how="inner")
    merged = merged.merge(abg, on=["dataset", "icu_stay_id"], how="left")
    abg_cols = [col for col in merged.columns if col.startswith("a5_abg_")]
    for col in abg_cols:
        if col.endswith("_observed") or col in {"a5_abg_any", "a5_abg_complete"}:
            merged[col] = merged[col].fillna(False).astype(bool)
        else:
            merged[col] = merged[col].fillna(0).astype(int)
    return merged


def prepare_task_matrix(merged: pd.DataFrame, task_name: str) -> pd.DataFrame:
    spec = TASKS[task_name]
    df = merged[merged[spec["eligible_col"]]].copy()
    df["task_name"] = task_name
    df["task_outcome"] = pd.to_numeric(df[spec["outcome_col"]], errors="coerce").astype(int)
    if task_name == "ventilation":
        df["hospital_mortality_original"] = pd.to_numeric(
            df["hospital_mortality"], errors="coerce"
        )
        df["hospital_mortality"] = df["task_outcome"]
    else:
        df["hospital_mortality_original"] = df["hospital_mortality"]
    return df


def make_density_only_matrix(task_df: pd.DataFrame) -> pd.DataFrame:
    id_cols = [
        "dataset",
        "patient_id",
        "hospital_id",
        "hospital_admission_id",
        "icu_stay_id",
        "age",
        "sex",
        "icu_type",
        "sex_female",
        "hospital_mortality",
        "hospital_mortality_original",
        "task_name",
        "task_outcome",
        "eligible_12h_mortality",
        "eligible_12h_new_invasive_vent",
        "new_invasive_vent_12_48h",
        "invasive_vent_before_or_at_12h",
        "early_resp_treatment_before_or_at_12h",
    ] + COHORT_COLUMNS
    id_cols = [col for col in id_cols if col in task_df.columns]
    density_cols = [
        col
        for col in task_df.columns
        if col.endswith("_count") or col.endswith("_missing") or col.startswith("a5_abg_")
    ]
    out = task_df[id_cols + density_cols].copy()
    count_cols = [col for col in out.columns if col.endswith("_count")]
    missing_cols = [col for col in out.columns if col.endswith("_missing")]
    out["a6_total_measurement_count"] = out[count_cols].sum(axis=1) if count_cols else 0
    out["a6_missing_feature_count"] = out[missing_cols].sum(axis=1) if missing_cols else 0
    out["a6_observed_feature_count"] = len(missing_cols) - out["a6_missing_feature_count"]
    return out


def summarize_matrix(df: pd.DataFrame, task_name: str, audit_variant: str) -> pd.DataFrame:
    rows = []
    for dataset, dataset_group in df.groupby("dataset", sort=False):
        for cohort in ["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure", "c3_treatment_enriched_copd", "c4_convenience_copd"]:
            subset = dataset_group[dataset_group[cohort]]
            rows.append(
                {
                    "task": task_name,
                    "audit_variant": audit_variant,
                    "dataset": dataset,
                    "cohort_definition": cohort,
                    "n_rows": len(subset),
                    "n_events": int(subset["task_outcome"].sum()) if len(subset) else 0,
                    "event_rate": round(float(subset["task_outcome"].mean()), 6) if len(subset) else None,
                    "median_age": round(float(subset["age"].median()), 2) if len(subset) else None,
                    "female_pct": round(float(subset["sex_female"].mean()) * 100, 2)
                    if len(subset) and "sex_female" in subset
                    else None,
                    "abg_any_pct": round(float(subset["a5_abg_any"].mean()) * 100, 2)
                    if len(subset) and "a5_abg_any" in subset
                    else None,
                    "abg_complete_pct": round(float(subset["a5_abg_complete"].mean()) * 100, 2)
                    if len(subset) and "a5_abg_complete" in subset
                    else None,
                }
            )
    return pd.DataFrame(rows)


def standardized_mean_difference(full: pd.Series, selected: pd.Series) -> float | None:
    full = pd.to_numeric(full, errors="coerce").dropna()
    selected = pd.to_numeric(selected, errors="coerce").dropna()
    if len(full) < 2 or len(selected) < 2:
        return None
    pooled = ((full.var(ddof=1) + selected.var(ddof=1)) / 2) ** 0.5
    if pooled == 0 or pd.isna(pooled):
        return 0.0
    return round(float((selected.mean() - full.mean()) / pooled), 6)


def summarize_a5_shift(a0: pd.DataFrame, a5: pd.DataFrame, task_name: str) -> pd.DataFrame:
    rows = []
    variables = {
        "age": "age",
        "female": "sex_female",
        "task_outcome": "task_outcome",
        "baseline_invasive_vent": "invasive_vent_before_or_at_12h",
        "early_resp_treatment": "early_resp_treatment_before_or_at_12h",
    }
    for dataset in sorted(a0["dataset"].unique()):
        for cohort in ["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure", "c4_convenience_copd"]:
            full = a0[(a0["dataset"].eq(dataset)) & (a0[cohort])]
            selected = a5[(a5["dataset"].eq(dataset)) & (a5[cohort])]
            for label, col in variables.items():
                if col not in full or col not in selected:
                    continue
                rows.append(
                    {
                        "task": task_name,
                        "dataset": dataset,
                        "cohort_definition": cohort,
                        "variable": label,
                        "full_n": len(full),
                        "selected_n": len(selected),
                        "full_mean": round(float(pd.to_numeric(full[col], errors="coerce").mean()), 6)
                        if len(full)
                        else None,
                        "selected_mean": round(float(pd.to_numeric(selected[col], errors="coerce").mean()), 6)
                        if len(selected)
                        else None,
                        "smd_selected_vs_full": standardized_mean_difference(full[col], selected[col]),
                    }
                )
    return pd.DataFrame(rows)


def write_manifest(paths: list[dict[str, object]]) -> None:
    manifest = pd.DataFrame(paths)
    manifest.to_csv(TABLE_ROOT / "copd_model_matrix_manifest.csv", index=False)
    manifest.to_csv(MANUSCRIPT_TABLE_ROOT / "copd_model_matrix_manifest.csv", index=False)


def main() -> int:
    ensure_dirs()
    copd = read_copd_outcomes()
    print(f"Loaded COPD target rows: {len(copd):,}")
    abg = build_abg_availability(copd)
    print(f"Built/loaded ABG availability rows: {len(abg):,}")

    summaries = []
    a5_shift_tables = []
    manifest_rows: list[dict[str, object]] = []

    for variant, path in ICU_FEATURE_VARIANTS.items():
        print(f"Loading ICU feature variant {variant}: {path.name}")
        features = load_icu_feature_matrix(path)
        merged = add_copd_context(features, copd, abg)
        for task_name, spec in TASKS.items():
            task_df = prepare_task_matrix(merged, task_name)
            output_path = OUTPUT_ROOT / f"{spec['output_prefix']}_{variant}_features.csv.gz"
            task_df.to_csv(output_path, index=False, compression="gzip")
            summaries.append(summarize_matrix(task_df, task_name, variant))
            manifest_rows.append(
                {
                    "task": task_name,
                    "audit_variant": variant,
                    "path": str(output_path.relative_to(PROJECT_ROOT)),
                    "n_rows": len(task_df),
                    "n_columns": task_df.shape[1],
                }
            )

            if variant == "A0_clean":
                a5_df = task_df[task_df["a5_abg_complete"]].copy()
                a5_path = OUTPUT_ROOT / f"{spec['output_prefix']}_A5_abg_complete_case_features.csv.gz"
                a5_df.to_csv(a5_path, index=False, compression="gzip")
                summaries.append(summarize_matrix(a5_df, task_name, "A5_abg_complete_case"))
                a5_shift_tables.append(summarize_a5_shift(task_df, a5_df, task_name))
                manifest_rows.append(
                    {
                        "task": task_name,
                        "audit_variant": "A5_abg_complete_case",
                        "path": str(a5_path.relative_to(PROJECT_ROOT)),
                        "n_rows": len(a5_df),
                        "n_columns": a5_df.shape[1],
                    }
                )

                density_df = make_density_only_matrix(task_df)
                density_path = OUTPUT_ROOT / f"{spec['output_prefix']}_A6_density_only_features.csv.gz"
                density_df.to_csv(density_path, index=False, compression="gzip")
                summaries.append(summarize_matrix(density_df, task_name, "A6_density_only"))
                manifest_rows.append(
                    {
                        "task": task_name,
                        "audit_variant": "A6_density_only",
                        "path": str(density_path.relative_to(PROJECT_ROOT)),
                        "n_rows": len(density_df),
                        "n_columns": density_df.shape[1],
                    }
                )

    summary = pd.concat(summaries, ignore_index=True)
    summary.to_csv(TABLE_ROOT / "copd_model_matrix_summary.csv", index=False)
    summary.to_csv(MANUSCRIPT_TABLE_ROOT / "copd_model_matrix_summary.csv", index=False)

    if a5_shift_tables:
        a5_shift = pd.concat(a5_shift_tables, ignore_index=True)
        a5_shift.to_csv(TABLE_ROOT / "copd_a5_abg_target_population_shift.csv", index=False)
        a5_shift.to_csv(
            MANUSCRIPT_TABLE_ROOT / "copd_a5_abg_target_population_shift.csv",
            index=False,
        )

    write_manifest(manifest_rows)

    print("\nCOPD model matrix summary:")
    print(summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
