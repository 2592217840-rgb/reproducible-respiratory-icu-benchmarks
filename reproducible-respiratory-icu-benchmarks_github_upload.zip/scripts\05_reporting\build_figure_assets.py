from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
FIGURE_ROOT = PROJECT_ROOT / "outputs" / "figures"
FIGURE_DATA_ROOT = PROJECT_ROOT / "outputs" / "figure_data"
MANUSCRIPT_FIGURE_ROOT = PROJECT_ROOT / "manuscript" / "figures"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"
MANUSCRIPT_FIGURE_DATA_ROOT = PROJECT_ROOT / "manuscript" / "figure_data"
INTERMEDIATE_ROOT = PROJECT_ROOT / "data_intermediate"

COLORS = {
    "A0_clean": "#1f6f78",
    "A0_respiratory_extended": "#4f8fba",
    "A1_future_window_24h": "#c85a3d",
    "A1_respiratory_extended_24h": "#e08d42",
    "A3_all_proxies": "#7851a9",
    "A5_abg_complete_case": "#5b6d5b",
    "A6_density_only": "#b8902d",
    "A7_composite_convenience": "#932f2f",
    "treat_all": "#777777",
    "treat_none": "#222222",
}


def ensure_dirs() -> None:
    for path in [FIGURE_ROOT, FIGURE_DATA_ROOT, MANUSCRIPT_FIGURE_ROOT, MANUSCRIPT_FIGURE_DATA_ROOT]:
        path.mkdir(parents=True, exist_ok=True)


def esc(text: object) -> str:
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def text(x: float, y: float, content: object, size: int = 12, anchor: str = "start", weight: str = "400") -> str:
    return (
        f'<text x="{x:.1f}" y="{y:.1f}" font-family="Arial, sans-serif" '
        f'font-size="{size}" font-weight="{weight}" text-anchor="{anchor}" fill="#202020">{esc(content)}</text>'
    )


def line(x1: float, y1: float, x2: float, y2: float, color: str = "#333333", width: float = 1.0, dash: str = "") -> str:
    dash_attr = f' stroke-dasharray="{dash}"' if dash else ""
    return f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{color}" stroke-width="{width}"{dash_attr}/>'


def rect(x: float, y: float, w: float, h: float, color: str, stroke: str = "none", opacity: float = 1.0) -> str:
    return (
        f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" '
        f'fill="{color}" stroke="{stroke}" opacity="{opacity}"/>'
    )


def circle(x: float, y: float, r: float, color: str, stroke: str = "#ffffff", width: float = 1.0) -> str:
    return (
        f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r:.1f}" fill="{color}" '
        f'stroke="{stroke}" stroke-width="{width}"/>'
    )


def polyline(points: list[tuple[float, float]], color: str, width: float = 2.0, dash: str = "") -> str:
    p = " ".join(f"{x:.1f},{y:.1f}" for x, y in points)
    dash_attr = f' stroke-dasharray="{dash}"' if dash else ""
    return f'<polyline points="{p}" fill="none" stroke="{color}" stroke-width="{width}"{dash_attr}/>'


def svg_wrap(width: int, height: int, parts: list[str]) -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">\n'
        f'{rect(0, 0, width, height, "#ffffff")}\n'
        + "\n".join(parts)
        + "\n</svg>\n"
    )


def save_svg(name: str, content: str) -> None:
    for root in [FIGURE_ROOT, MANUSCRIPT_FIGURE_ROOT]:
        (root / name).write_text(content, encoding="utf-8")
        print(f"Wrote {root / name}")


def save_figure_data(name: str, df: pd.DataFrame) -> None:
    for root in [FIGURE_DATA_ROOT, MANUSCRIPT_FIGURE_DATA_ROOT]:
        df.to_csv(root / name, index=False)


def scale(value: float, vmin: float, vmax: float, out_min: float, out_max: float) -> float:
    if vmax == vmin:
        return (out_min + out_max) / 2
    return out_min + (value - vmin) / (vmax - vmin) * (out_max - out_min)


def build_failure_phenotype_map() -> None:
    df = pd.read_csv(TABLE_ROOT / "copd_model_family_failure_phenotype.csv")
    df = df[
        df["cohort_definition"].isin(["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"])
        & df["audit_variant"].isin(
            [
                "A0_clean",
                "A0_respiratory_extended",
                "A1_future_window_24h",
                "A1_respiratory_extended_24h",
                "A3_all_proxies",
                "A6_density_only",
                "A7_composite_convenience",
            ]
        )
    ].copy()
    save_figure_data("figure_failure_phenotype_map_source.csv", df)

    width, height = 1100, 620
    left, top, panel_w, panel_h = 85, 90, 450, 400
    gap = 75
    x_min, x_max = 0.0, max(0.32, float(df["internal_external_auroc_gap"].max()) * 1.05)
    y_min, y_max = 0.0, max(1.15, float(df["external_calibration_slope_deviation"].max()) * 1.05)
    parts = [text(40, 35, "Failure phenotype map: internal AUROC optimism vs external calibration failure", 18, weight="700")]
    for panel_idx, task in enumerate(["mortality", "ventilation"]):
        x0 = left + panel_idx * (panel_w + gap)
        y0 = top
        parts += [
            text(x0, y0 - 25, task.capitalize(), 15, weight="700"),
            rect(x0, y0, panel_w, panel_h, "#fbfbfb", "#cccccc"),
            line(x0, y0 + panel_h, x0 + panel_w, y0 + panel_h),
            line(x0, y0, x0, y0 + panel_h),
            line(scale(0.08, x_min, x_max, x0, x0 + panel_w), y0, scale(0.08, x_min, x_max, x0, x0 + panel_w), y0 + panel_h, "#999999", 1, "5,4"),
            line(x0, scale(0.5, y_min, y_max, y0 + panel_h, y0), x0 + panel_w, scale(0.5, y_min, y_max, y0 + panel_h, y0), "#999999", 1, "5,4"),
        ]
        for tick in np.linspace(0, x_max, 5):
            tx = scale(float(tick), x_min, x_max, x0, x0 + panel_w)
            parts += [line(tx, y0 + panel_h, tx, y0 + panel_h + 5), text(tx, y0 + panel_h + 22, f"{tick:.2f}", 10, "middle")]
        for tick in np.linspace(0, y_max, 5):
            ty = scale(float(tick), y_min, y_max, y0 + panel_h, y0)
            parts += [line(x0 - 5, ty, x0, ty), text(x0 - 9, ty + 4, f"{tick:.1f}", 10, "end")]
        task_df = df[df["task"].eq(task)].copy()
        for _, row in task_df.iterrows():
            x = scale(row["internal_external_auroc_gap"], x_min, x_max, x0, x0 + panel_w)
            y = scale(row["external_calibration_slope_deviation"], y_min, y_max, y0 + panel_h, y0)
            color = COLORS.get(row["audit_variant"], "#666666")
            radius = 5.5 if row["model"] == "xgboost" else 4.0
            stroke = "#111111" if row["model"] == "xgboost" else "#ffffff"
            parts.append(circle(x, y, radius, color, stroke, 1.2))
        parts += [
            text(x0 + panel_w / 2, y0 + panel_h + 52, "Internal - external AUROC gap", 12, "middle"),
            text(x0 - 58, y0 + panel_h / 2, "|1 - external calibration slope|", 12, "middle"),
        ]
    legend_x, legend_y = 80, 555
    for i, audit in enumerate(["A0_clean", "A0_respiratory_extended", "A1_future_window_24h", "A1_respiratory_extended_24h", "A3_all_proxies", "A6_density_only", "A7_composite_convenience"]):
        x = legend_x + (i % 4) * 255
        y = legend_y + (i // 4) * 25
        parts += [circle(x, y - 4, 5, COLORS[audit]), text(x + 12, y, audit, 11)]
    save_svg("figure_1_failure_phenotype_map.svg", svg_wrap(width, height, parts))


def build_external_auroc_gap_plot() -> None:
    df = pd.read_csv(TABLE_ROOT / "copd_model_family_failure_phenotype.csv")
    df = df[
        df["cohort_definition"].isin(["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"])
        & df["audit_variant"].isin(["A0_clean", "A1_respiratory_extended_24h", "A3_all_proxies", "A6_density_only", "A7_composite_convenience"])
    ].copy()
    save_figure_data("figure_internal_external_gap_source.csv", df)

    width, height = 1050, 620
    left, top, plot_w, plot_h = 170, 80, 790, 430
    labels = (
        df.assign(label=lambda x: x["task"] + "|" + x["cohort_definition"].str.replace("c1_discharge_icd_copd", "C1").str.replace("c2_copd_acute_respiratory_failure", "C2") + "|" + x["model"])
        ["label"]
        .drop_duplicates()
        .tolist()
    )
    y_positions = {label: top + i * (plot_h / max(1, len(labels) - 1)) for i, label in enumerate(labels)}
    x_min, x_max = 0.35, 0.92
    parts = [text(40, 35, "Internal and external AUROC by audit variant", 18, weight="700")]
    parts += [rect(left, top - 25, plot_w, plot_h + 50, "#fbfbfb", "#cccccc")]
    for tick in np.arange(0.4, 0.95, 0.1):
        tx = scale(float(tick), x_min, x_max, left, left + plot_w)
        parts += [line(tx, top - 25, tx, top + plot_h + 25, "#e0e0e0"), text(tx, top + plot_h + 45, f"{tick:.1f}", 10, "middle")]
    for label in labels:
        y = y_positions[label]
        parts += [line(left, y, left + plot_w, y, "#eeeeee"), text(left - 10, y + 4, label, 10, "end")]
    for _, row in df.iterrows():
        label = f"{row['task']}|{row['cohort_definition'].replace('c1_discharge_icd_copd', 'C1').replace('c2_copd_acute_respiratory_failure', 'C2')}|{row['model']}"
        y = y_positions[label]
        x1 = scale(row["internal_auroc"], x_min, x_max, left, left + plot_w)
        x2 = scale(row["external_auroc"], x_min, x_max, left, left + plot_w)
        color = COLORS.get(row["audit_variant"], "#666666")
        parts += [line(x1, y, x2, y, color, 1.7), circle(x1, y, 4, color, "#111111"), circle(x2, y, 4, "#ffffff", color, 1.7)]
    parts += [text(left + plot_w / 2, height - 38, "AUROC (filled = internal; open = external)", 12, "middle")]
    save_svg("figure_2_internal_external_auroc_gap.svg", svg_wrap(width, height, parts))


def build_a5_shift_plot() -> None:
    df = pd.read_csv(TABLE_ROOT / "copd_a5_abg_target_population_shift.csv")
    df = df[
        df["cohort_definition"].isin(["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"])
        & df["variable"].isin(["task_outcome", "baseline_invasive_vent", "early_resp_treatment", "age", "female"])
    ].copy()
    save_figure_data("figure_a5_abg_target_shift_source.csv", df)
    width, height = 1120, 650
    left, top, plot_w, row_h = 260, 70, 760, 23
    df["label"] = (
        df["task"]
        + " | "
        + df["dataset"]
        + " | "
        + df["cohort_definition"].str.replace("c1_discharge_icd_copd", "C1").str.replace("c2_copd_acute_respiratory_failure", "C2")
        + " | "
        + df["variable"]
    )
    df = df.sort_values(["task", "dataset", "cohort_definition", "variable"]).reset_index(drop=True)
    max_abs = max(0.42, float(df["smd_selected_vs_full"].abs().max()) * 1.1)
    zero_x = scale(0, -max_abs, max_abs, left, left + plot_w)
    parts = [text(40, 35, "A5 ABG complete-case selection shifts the target population", 18, weight="700")]
    parts += [rect(left, top - 20, plot_w, len(df) * row_h + 40, "#fbfbfb", "#cccccc"), line(zero_x, top - 20, zero_x, top + len(df) * row_h + 20, "#333333")]
    for tick in np.linspace(-max_abs, max_abs, 7):
        tx = scale(float(tick), -max_abs, max_abs, left, left + plot_w)
        parts += [line(tx, top - 20, tx, top + len(df) * row_h + 20, "#e5e5e5"), text(tx, top + len(df) * row_h + 38, f"{tick:.2f}", 10, "middle")]
    for i, row in df.iterrows():
        y = top + i * row_h
        value = row["smd_selected_vs_full"]
        x = scale(value, -max_abs, max_abs, left, left + plot_w)
        x0 = min(zero_x, x)
        w = abs(x - zero_x)
        color = "#c85a3d" if abs(value) >= 0.1 else "#4f8fba"
        parts += [text(left - 8, y + 5, row["label"], 9, "end"), rect(x0, y - 7, max(w, 1.0), 12, color, opacity=0.9)]
    parts += [text(left + plot_w / 2, height - 35, "Standardized mean difference: ABG complete-case vs full risk set", 12, "middle")]
    save_svg("figure_3_a5_abg_target_population_shift.svg", svg_wrap(width, height, parts))


def build_dca_plot() -> None:
    dca = pd.read_csv(TABLE_ROOT / "copd_model_family_external_dca_long.csv")
    panels = [
        ("mortality", "c1_discharge_icd_copd", "xgboost", ["A0_clean", "A1_respiratory_extended_24h", "A3_all_proxies", "A7_composite_convenience"]),
        ("ventilation", "c1_discharge_icd_copd", "xgboost", ["A0_clean", "A1_respiratory_extended_24h", "A7_composite_convenience"]),
    ]
    plot_df = []
    for task, cohort, model, audits in panels:
        plot_df.append(dca[(dca["task"].eq(task)) & (dca["cohort_definition"].eq(cohort)) & (dca["model"].eq(model)) & (dca["audit_variant"].isin(audits))])
    source = pd.concat(plot_df, ignore_index=True)
    save_figure_data("figure_threshold_specific_dca_source.csv", source)
    width, height = 1050, 560
    left, top, panel_w, panel_h = 85, 85, 415, 330
    gap = 80
    parts = [text(40, 35, "Threshold-specific external net benefit in eICU", 18, weight="700")]
    for pidx, (task, cohort, model, audits) in enumerate(panels):
        x0 = left + pidx * (panel_w + gap)
        y0 = top
        sub = dca[(dca["task"].eq(task)) & (dca["cohort_definition"].eq(cohort)) & (dca["model"].eq(model)) & (dca["audit_variant"].isin(audits))].copy()
        thresholds = sorted(sub["threshold"].unique())
        y_values = list(sub["net_benefit_model"]) + list(sub["net_benefit_treat_all"]) + [0.0]
        y_min, y_max = min(y_values) - 0.01, max(y_values) + 0.01
        parts += [text(x0, y0 - 25, f"{task.capitalize()} C1 XGBoost", 14, weight="700"), rect(x0, y0, panel_w, panel_h, "#fbfbfb", "#cccccc")]
        zero_y = scale(0, y_min, y_max, y0 + panel_h, y0)
        parts.append(line(x0, zero_y, x0 + panel_w, zero_y, "#777777", 1, "4,3"))
        for tick in thresholds:
            tx = scale(tick, min(thresholds), max(thresholds), x0 + 25, x0 + panel_w - 15)
            parts += [line(tx, y0 + panel_h, tx, y0 + panel_h + 5), text(tx, y0 + panel_h + 22, f"{tick:g}", 10, "middle")]
        for audit in audits:
            rows = sub[sub["audit_variant"].eq(audit)].sort_values("threshold")
            pts = [
                (
                    scale(r["threshold"], min(thresholds), max(thresholds), x0 + 25, x0 + panel_w - 15),
                    scale(r["net_benefit_model"], y_min, y_max, y0 + panel_h, y0),
                )
                for _, r in rows.iterrows()
            ]
            parts.append(polyline(pts, COLORS.get(audit, "#666666"), 2.3))
            for x, y in pts:
                parts.append(circle(x, y, 3.5, COLORS.get(audit, "#666666")))
        treat_all_pts = [
            (
                scale(r["threshold"], min(thresholds), max(thresholds), x0 + 25, x0 + panel_w - 15),
                scale(r["net_benefit_treat_all"], y_min, y_max, y0 + panel_h, y0),
            )
            for _, r in sub.drop_duplicates("threshold").sort_values("threshold").iterrows()
        ]
        parts.append(polyline(treat_all_pts, "#777777", 1.7, "5,4"))
        parts += [text(x0 + panel_w / 2, y0 + panel_h + 48, "Risk threshold", 11, "middle"), text(x0 - 55, y0 + panel_h / 2, "Net benefit", 11, "middle")]
    legend_x, legend_y = 120, 500
    for i, audit in enumerate(["A0_clean", "A1_respiratory_extended_24h", "A3_all_proxies", "A7_composite_convenience"]):
        x = legend_x + i * 220
        parts += [line(x, legend_y - 4, x + 30, legend_y - 4, COLORS[audit], 2.3), text(x + 38, legend_y, audit, 11)]
    parts += [line(legend_x, legend_y + 22, legend_x + 30, legend_y + 22, "#777777", 1.7, "5,4"), text(legend_x + 38, legend_y + 26, "treat_all", 11)]
    save_svg("figure_4_threshold_specific_dca.svg", svg_wrap(width, height, parts))


def build_respiratory_completeness_plot() -> None:
    df = pd.read_csv(TABLE_ROOT / "copd_respiratory_specific_feature_completeness.csv")
    df = df[df["window"].eq("resp0")].copy()
    save_figure_data("figure_respiratory_feature_completeness_source.csv", df)
    features = df["feature"].drop_duplicates().tolist()
    width, height = 1120, 560
    left, top, plot_w, plot_h = 120, 70, 930, 350
    group_w = plot_w / len(features)
    parts = [text(40, 35, "Respiratory-specific predictor availability before the 12h landmark", 18, weight="700")]
    parts += [rect(left, top, plot_w, plot_h, "#fbfbfb", "#cccccc")]
    for tick in range(0, 101, 20):
        y = scale(tick, 0, 100, top + plot_h, top)
        parts += [line(left, y, left + plot_w, y, "#e5e5e5"), text(left - 8, y + 4, f"{tick}%", 10, "end")]
    for i, feature in enumerate(features):
        sub = df[df["feature"].eq(feature)]
        base_x = left + i * group_w + group_w * 0.2
        for j, dataset in enumerate(["MIMIC-IV", "eICU"]):
            value = float(sub[sub["dataset"].eq(dataset)]["observed_pct"].iloc[0]) if not sub[sub["dataset"].eq(dataset)].empty else 0.0
            bar_w = group_w * 0.22
            x = base_x + j * (bar_w + 4)
            y = scale(value, 0, 100, top + plot_h, top)
            color = "#1f6f78" if dataset == "MIMIC-IV" else "#c85a3d"
            parts.append(rect(x, y, bar_w, top + plot_h - y, color))
        parts.append(text(left + i * group_w + group_w / 2, top + plot_h + 28, feature, 9, "middle"))
    parts += [
        rect(left + 20, height - 62, 14, 14, "#1f6f78"),
        text(left + 40, height - 50, "MIMIC-IV", 11),
        rect(left + 125, height - 62, 14, 14, "#c85a3d"),
        text(left + 145, height - 50, "eICU", 11),
    ]
    save_svg("figure_5_respiratory_feature_completeness.svg", svg_wrap(width, height, parts))


def build_a3a_qc() -> None:
    rows = []
    for task, prefix in [
        ("mortality", "copd_mortality_12h"),
        ("ventilation", "copd_new_invasive_ventilation_12h"),
    ]:
        a0 = pd.read_csv(INTERMEDIATE_ROOT / f"{prefix}_A0_clean_features.csv.gz", compression="gzip", nrows=1, low_memory=False)
        a3a = pd.read_csv(INTERMEDIATE_ROOT / f"{prefix}_A3a_time_ambiguous_diagnosis_features.csv.gz", compression="gzip", nrows=1, low_memory=False)
        a0_cols = set(a0.columns)
        a3a_cols = set(a3a.columns)
        added = sorted(a3a_cols - a0_cols)
        diagnostic_like = [
            col
            for col in added
            if any(token in col.lower() for token in ["diag", "diagnosis", "admit", "chief", "problem", "dx"])
        ]
        rows.append(
            {
                "task": task,
                "a0_columns": len(a0_cols),
                "a3a_columns": len(a3a_cols),
                "added_columns": len(added),
                "diagnostic_like_added_columns": len(diagnostic_like),
                "first_added_columns": "; ".join(added[:20]),
                "qc_note": "A3a adds eICU diagnosis-path proxy columns. Treat as time-ambiguous diagnostic descriptors rather than timestamp-verified baseline diagnoses.",
            }
        )
    out = pd.DataFrame(rows)
    out.to_csv(TABLE_ROOT / "copd_a3a_feature_qc.csv", index=False)
    out.to_csv(MANUSCRIPT_TABLE_ROOT / "copd_a3a_feature_qc.csv", index=False)


def build_literature_audit_matrix_plot() -> None:
    full = pd.read_csv(TABLE_ROOT / "copd_literature_scoping_audit_fulltext.csv")
    domains = [
        ("a1_future_window_risk", "A1 time window"),
        ("a3b_admin_discharge_coding_risk", "A3b admin coding"),
        ("a3c_treatment_procedure_proxy_risk", "A3c treatment/procedure"),
        ("a5_complete_case_or_required_test_selection_risk", "A5 selection"),
        ("a6_measurement_process_features_or_missingness_risk", "A6 observation process"),
        ("external_validation", "External validation"),
        ("calibration_reported", "Calibration"),
        ("dca_or_decision_utility_reported", "DCA"),
    ]

    def status(value: str, domain: str) -> tuple[str, str]:
        v = str(value).lower()
        if domain in {"external_validation", "calibration_reported", "dca_or_decision_utility_reported"}:
            if "external" in v or "multi-database" in v or "calibration" in v or "dca" in v:
                return "reported", "#1f6f78"
            if "not prominent" in v or "absent" in v or "no independent" in v:
                return "not_reported", "#d5d5d5"
            return "unclear", "#b8902d"
        if "high-risk" in v:
            return "high_risk", "#932f2f"
        if "unclear" in v or "insufficient" in v or "not assessable" in v:
            return "unclear", "#b8902d"
        if "potential" in v or "task-inherent" in v:
            return "potential", "#e08d42"
        if "clearly addressed" in v or v.startswith("low"):
            return "addressed_or_low", "#4f8fba"
        return "descriptive", "#d5d5d5"

    rows = []
    for _, study in full.iterrows():
        for domain, label in domains:
            category, color = status(study[domain], domain)
            rows.append(
                {
                    "study_id": study["study_id"],
                    "short_citation": study["short_citation"],
                    "domain": domain,
                    "domain_label": label,
                    "classification": category,
                    "color": color,
                }
            )
    source = pd.DataFrame(rows)
    save_figure_data("figure_literature_scoping_audit_matrix_source.csv", source)

    studies = full["short_citation"].tolist()
    width, height = 1180, 610
    left, top, cell_w, cell_h = 250, 110, 100, 30
    parts = [text(40, 35, "Contextual scoping audit of published COPD and respiratory ICU benchmarks", 18, weight="700")]
    for j, (_, label) in enumerate(domains):
        x = left + j * cell_w + cell_w / 2
        parts.append(text(x, top - 18, label, 10, "middle", "700"))
    for i, study in enumerate(studies):
        y = top + i * cell_h
        parts.append(text(left - 10, y + 20, study, 10, "end"))
        for j, (domain, _) in enumerate(domains):
            rec = source[(source["short_citation"].eq(study)) & (source["domain"].eq(domain))].iloc[0]
            x = left + j * cell_w
            parts.append(rect(x, y, cell_w - 3, cell_h - 3, rec["color"], "#ffffff"))
            symbol = {
                "high_risk": "H",
                "potential": "P",
                "unclear": "?",
                "addressed_or_low": "L",
                "reported": "R",
                "not_reported": "-",
                "descriptive": ".",
            }.get(rec["classification"], ".")
            parts.append(text(x + cell_w / 2, y + 19, symbol, 11, "middle", "700"))
    legend = [
        ("H high-risk feature", "#932f2f"),
        ("P potential/context-dependent", "#e08d42"),
        ("? unclear/insufficient", "#b8902d"),
        ("L addressed/low", "#4f8fba"),
        ("R reported", "#1f6f78"),
        ("- not reported", "#d5d5d5"),
    ]
    for k, (label, color) in enumerate(legend):
        x = 70 + (k % 3) * 330
        y = height - 80 + (k // 3) * 28
        parts += [rect(x, y - 13, 18, 18, color, "#ffffff"), text(x + 26, y + 2, label, 11)]
    save_svg("figure_6_published_benchmark_scoping_audit_matrix.svg", svg_wrap(width, height, parts))


def build_key_result_summary() -> None:
    metrics = pd.read_csv(TABLE_ROOT / "copd_model_family_external_metrics.csv")
    boot = pd.read_csv(TABLE_ROOT / "copd_bootstrap_paired_delta_ci.csv")
    selected_metrics = metrics[
        metrics["cohort_definition"].isin(["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"])
        & metrics["model"].eq("xgboost")
        & metrics["audit_variant"].isin(["A0_clean", "A0_respiratory_extended", "A1_respiratory_extended_24h", "A3_all_proxies", "A6_density_only", "A7_composite_convenience"])
    ].copy()
    selected_metrics.to_csv(TABLE_ROOT / "copd_key_xgboost_external_results.csv", index=False)
    selected_metrics.to_csv(MANUSCRIPT_TABLE_ROOT / "copd_key_xgboost_external_results.csv", index=False)
    key_delta = boot[
        boot["model"].eq("xgboost")
        & boot["metric"].eq("auroc")
        & boot["audit_variant"].isin(["A1_respiratory_extended_24h", "A6_density_only", "A7_composite_convenience"])
    ].copy()
    key_delta.to_csv(TABLE_ROOT / "copd_key_bootstrap_auroc_delta_results.csv", index=False)
    key_delta.to_csv(MANUSCRIPT_TABLE_ROOT / "copd_key_bootstrap_auroc_delta_results.csv", index=False)


def build_manifest() -> None:
    rows = []
    for path in sorted(FIGURE_ROOT.glob("*.svg")):
        rows.append({"artifact": path.name, "type": "figure_svg", "path": str(path.relative_to(PROJECT_ROOT))})
    for path in sorted(FIGURE_DATA_ROOT.glob("*.csv")):
        rows.append({"artifact": path.name, "type": "figure_source_data", "path": str(path.relative_to(PROJECT_ROOT))})
    out = pd.DataFrame(rows)
    out.to_csv(TABLE_ROOT / "copd_figure_asset_manifest.csv", index=False)
    out.to_csv(MANUSCRIPT_TABLE_ROOT / "copd_figure_asset_manifest.csv", index=False)


def main() -> int:
    ensure_dirs()
    build_failure_phenotype_map()
    build_external_auroc_gap_plot()
    build_a5_shift_plot()
    build_dca_plot()
    build_respiratory_completeness_plot()
    build_a3a_qc()
    build_literature_audit_matrix_plot()
    build_key_result_summary()
    build_manifest()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
