from __future__ import annotations

import argparse
import re
from pathlib import Path

import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]
INTERMEDIATE_ROOT = PROJECT_ROOT / "data_intermediate"
TABLE_ROOT = PROJECT_ROOT / "outputs" / "tables"
MANUSCRIPT_TABLE_ROOT = PROJECT_ROOT / "manuscript" / "tables"

SEED = 20260426
DEFAULT_N_BOOTSTRAP = 300
COHORTS = ["c1_discharge_icd_copd", "c2_copd_acute_respiratory_failure"]
MODELS = ["logistic", "xgboost"]
COMPARISONS = [
    ("A0_clean", "A1_future_window_24h"),
    ("A0_respiratory_extended", "A1_respiratory_extended_24h"),
    ("A0_clean", "A3_all_proxies"),
    ("A0_clean", "A6_density_only"),
    ("A0_clean", "A7_composite_convenience"),
]
INDIVIDUAL_AUDITS = sorted({audit for pair in COMPARISONS for audit in pair})


def sigmoid(z: np.ndarray) -> np.ndarray:
    z = np.clip(np.asarray(z, dtype=float), -35, 35)
    return 1.0 / (1.0 + np.exp(-z))


def rankdata_average(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(len(values), dtype=float)
    sorted_values = values[order]
    i = 0
    while i < len(values):
        j = i + 1
        while j < len(values) and sorted_values[j] == sorted_values[i]:
            j += 1
        ranks[order[i:j]] = (i + 1 + j) / 2.0
        i = j
    return ranks


def auroc(y: np.ndarray, pred: np.ndarray) -> float:
    y = y.astype(int)
    n_pos = int(y.sum())
    n_neg = len(y) - n_pos
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    ranks = rankdata_average(pred)
    return float((ranks[y == 1].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def auprc(y: np.ndarray, pred: np.ndarray) -> float:
    y = y.astype(int)
    n_pos = int(y.sum())
    if n_pos == 0:
        return float("nan")
    order = np.argsort(-pred, kind="mergesort")
    y_sorted = y[order]
    tp = np.cumsum(y_sorted)
    fp = np.cumsum(1 - y_sorted)
    recall = tp / n_pos
    precision = tp / np.maximum(tp + fp, 1)
    recall = np.r_[0.0, recall]
    precision = np.r_[precision[0] if len(precision) else 0.0, precision]
    return float(np.sum((recall[1:] - recall[:-1]) * precision[1:]))


def fit_logistic_l2(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    n, p = x.shape
    design = np.column_stack([np.ones(n), x])
    beta = np.zeros(p + 1)
    for _ in range(60):
        pred = sigmoid(design @ beta)
        weight = np.clip(pred * (1 - pred), 1e-6, None)
        gradient = design.T @ (pred - y)
        hessian = (design.T * weight) @ design
        try:
            step = np.linalg.solve(hessian, gradient)
        except np.linalg.LinAlgError:
            step = np.linalg.lstsq(hessian, gradient, rcond=None)[0]
        beta -= step
        if float(np.max(np.abs(step))) < 1e-7:
            break
    return beta


def calibration_intercept_slope(y: np.ndarray, pred: np.ndarray) -> tuple[float, float]:
    if len(np.unique(y)) < 2:
        return float("nan"), float("nan")
    p = np.clip(pred, 1e-6, 1 - 1e-6)
    logit_pred = np.log(p / (1 - p)).reshape(-1, 1)
    beta = fit_logistic_l2(logit_pred, y.astype(float))
    return float(beta[0]), float(beta[1])


def ici(y: np.ndarray, pred: np.ndarray, n_bins: int = 10) -> float:
    frame = pd.DataFrame({"y": y, "pred": pred})
    try:
        frame["bin"] = pd.qcut(frame["pred"], q=n_bins, labels=False, duplicates="drop")
    except ValueError:
        frame["bin"] = 0
    grouped = frame.groupby("bin", dropna=False).agg(
        observed=("y", "mean"), predicted=("pred", "mean"), n=("y", "size")
    )
    grouped = grouped[grouped["n"] > 0]
    if grouped.empty:
        return float("nan")
    return float(np.average(np.abs(grouped["observed"] - grouped["predicted"]), weights=grouped["n"]))


def metric_values(y: np.ndarray, pred: np.ndarray) -> dict[str, float]:
    intercept, slope = calibration_intercept_slope(y, pred)
    prevalence = float(np.mean(y))
    ap = auprc(y, pred)
    return {
        "auroc": auroc(y, pred),
        "auprc_prevalence_ratio": ap / prevalence if prevalence > 0 else float("nan"),
        "brier": float(np.mean((y - pred) ** 2)),
        "calibration_intercept": intercept,
        "calibration_slope": slope,
        "ici_eavg": ici(y, pred),
    }


def ci(values: list[float]) -> tuple[float, float]:
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    if len(arr) == 0:
        return float("nan"), float("nan")
    return float(np.quantile(arr, 0.025)), float(np.quantile(arr, 0.975))


def parse_prediction_path(path: Path) -> tuple[str, str, str, str]:
    stem = path.name.replace("_predictions.csv.gz", "")
    match = re.match(r"copd_(mortality|ventilation)_(.+)_(logistic|xgboost)$", stem)
    if not match:
        raise ValueError(f"Unexpected prediction file: {path.name}")
    task = match.group(1)
    rest = match.group(2)
    model = match.group(3)
    cohort = next((value for value in COHORTS if rest.startswith(f"{value}_")), None)
    if cohort is None:
        raise ValueError(f"Could not parse cohort from prediction file: {path.name}")
    audit = rest[len(cohort) + 1 :]
    return task, cohort, audit, model


def build_prediction_index() -> dict[tuple[str, str, str, str], Path]:
    index = {}
    for path in INTERMEDIATE_ROOT.glob("copd_*_predictions.csv.gz"):
        try:
            task, cohort, audit, model = parse_prediction_path(path)
        except ValueError:
            continue
        index[(task, cohort, audit, model)] = path
    return index


def load_external(path: Path) -> pd.DataFrame:
    df = pd.read_csv(
        path,
        compression="gzip",
        low_memory=False,
        dtype={"icu_stay_id": str},
        usecols=["split", "icu_stay_id", "hospital_mortality", "predicted_risk"],
    )
    df = df[df["split"].eq("external_valid")].copy()
    return df.rename(columns={"hospital_mortality": "y"})[["icu_stay_id", "y", "predicted_risk"]]


def bootstrap_single(
    df: pd.DataFrame,
    rng: np.random.Generator,
    n_bootstrap: int,
) -> dict[str, tuple[float, float, float]]:
    y = df["y"].astype(int).to_numpy()
    pred = df["predicted_risk"].astype(float).to_numpy()
    estimate = metric_values(y, pred)
    samples = {metric: [] for metric in estimate}
    n = len(df)
    for _ in range(n_bootstrap):
        idx = rng.integers(0, n, n)
        boot = metric_values(y[idx], pred[idx])
        for metric, value in boot.items():
            samples[metric].append(value)
    return {metric: (estimate[metric], *ci(values)) for metric, values in samples.items()}


def bootstrap_delta(
    base: pd.DataFrame,
    variant: pd.DataFrame,
    rng: np.random.Generator,
    n_bootstrap: int,
) -> tuple[int, int, dict[str, tuple[float, float, float]]]:
    merged = base.merge(variant, on="icu_stay_id", suffixes=("_base", "_variant"), how="inner")
    merged = merged[np.isclose(merged["y_base"], merged["y_variant"])].copy()
    y = merged["y_base"].astype(int).to_numpy()
    pred_base = merged["predicted_risk_base"].astype(float).to_numpy()
    pred_variant = merged["predicted_risk_variant"].astype(float).to_numpy()
    base_estimate = metric_values(y, pred_base)
    variant_estimate = metric_values(y, pred_variant)
    estimate = {metric: variant_estimate[metric] - base_estimate[metric] for metric in base_estimate}
    samples = {metric: [] for metric in estimate}
    n = len(merged)
    for _ in range(n_bootstrap):
        idx = rng.integers(0, n, n)
        b = metric_values(y[idx], pred_base[idx])
        v = metric_values(y[idx], pred_variant[idx])
        for metric in samples:
            samples[metric].append(v[metric] - b[metric])
    return n, int(y.sum()), {metric: (estimate[metric], *ci(values)) for metric, values in samples.items()}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build external bootstrap confidence intervals and paired A0-vs-audit deltas."
    )
    parser.add_argument(
        "--n-bootstrap",
        type=int,
        default=DEFAULT_N_BOOTSTRAP,
        help=f"Number of bootstrap resamples. Default: {DEFAULT_N_BOOTSTRAP}.",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=SEED,
        help=f"Random seed. Default: {SEED}.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.n_bootstrap < 100:
        raise ValueError("--n-bootstrap should be at least 100 for stable interval estimates.")
    rng = np.random.default_rng(args.seed)
    index = build_prediction_index()
    metric_rows = []
    delta_rows = []
    for task in ["mortality", "ventilation"]:
        for cohort in COHORTS:
            for model in MODELS:
                for audit in INDIVIDUAL_AUDITS:
                    path = index.get((task, cohort, audit, model))
                    if path is None:
                        continue
                    df = load_external(path)
                    for metric, (estimate, low, high) in bootstrap_single(df, rng, args.n_bootstrap).items():
                        metric_rows.append(
                            {
                                "task": task,
                                "cohort_definition": cohort,
                                "model": model,
                                "audit_variant": audit,
                                "metric": metric,
                                "estimate": estimate,
                                "ci_lower": low,
                                "ci_upper": high,
                                "n_bootstrap": args.n_bootstrap,
                                "seed": args.seed,
                                "n": int(len(df)),
                                "events": int(df["y"].sum()),
                            }
                        )
                for base_audit, variant_audit in COMPARISONS:
                    base_path = index.get((task, cohort, base_audit, model))
                    variant_path = index.get((task, cohort, variant_audit, model))
                    if base_path is None or variant_path is None:
                        continue
                    n, events, deltas = bootstrap_delta(
                        load_external(base_path),
                        load_external(variant_path),
                        rng,
                        args.n_bootstrap,
                    )
                    for metric, (estimate, low, high) in deltas.items():
                        delta_rows.append(
                            {
                                "task": task,
                                "cohort_definition": cohort,
                                "model": model,
                                "base_audit_variant": base_audit,
                                "audit_variant": variant_audit,
                                "metric": metric,
                                "delta_estimate": estimate,
                                "ci_lower": low,
                                "ci_upper": high,
                                "n_bootstrap": args.n_bootstrap,
                                "seed": args.seed,
                                "paired_n": n,
                                "paired_events": events,
                            }
                        )

    outputs = {
        "copd_bootstrap_external_metric_ci.csv": pd.DataFrame(metric_rows),
        "copd_bootstrap_paired_delta_ci.csv": pd.DataFrame(delta_rows),
    }
    for name, df in outputs.items():
        for col in df.columns:
            if pd.api.types.is_float_dtype(df[col]):
                df[col] = df[col].round(5)
        df.to_csv(TABLE_ROOT / name, index=False)
        df.to_csv(MANUSCRIPT_TABLE_ROOT / name, index=False)
        print(f"Wrote {TABLE_ROOT / name}")
    metadata = pd.DataFrame(
        [
            {
                "n_bootstrap": args.n_bootstrap,
                "seed": args.seed,
                "unit": "ICU stay / patient-level prediction row",
                "interval": "percentile 2.5% to 97.5%",
                "paired_delta": "A0 and audit predictions merged by icu_stay_id before resampling",
            }
        ]
    )
    metadata.to_csv(TABLE_ROOT / "copd_bootstrap_run_metadata.csv", index=False)
    metadata.to_csv(MANUSCRIPT_TABLE_ROOT / "copd_bootstrap_run_metadata.csv", index=False)
    print(f"Wrote {TABLE_ROOT / 'copd_bootstrap_run_metadata.csv'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
